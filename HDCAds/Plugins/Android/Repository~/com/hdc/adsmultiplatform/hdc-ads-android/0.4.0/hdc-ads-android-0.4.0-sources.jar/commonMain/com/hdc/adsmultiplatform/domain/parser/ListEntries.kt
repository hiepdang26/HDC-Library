package com.hdc.adsmultiplatform.domain.parser

/** Separators between the entries of a list sent as one string: ad unit ids, layout names, device hashes. */
internal val ListSeparators = charArrayOf(',', ';', '\n')

/** [ListSeparators] plus a carriage return, as the interstitial, banner and popup SDK calls accept. */
internal val ListSeparatorsWithCarriageReturn = charArrayOf(',', ';', '\n', '\r')

/** Splits a list sent as one string into its trimmed, non-blank entries. */
internal fun String.splitListEntries(separators: CharArray = ListSeparators): List<String> =
    split(*separators).map { it.trim() }.filter { it.isNotEmpty() }
