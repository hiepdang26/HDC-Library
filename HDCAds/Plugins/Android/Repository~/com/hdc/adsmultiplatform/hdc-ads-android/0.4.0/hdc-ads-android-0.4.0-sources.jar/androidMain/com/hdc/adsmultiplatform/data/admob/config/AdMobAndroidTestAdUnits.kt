package com.hdc.adsmultiplatform.data.admob.config

import com.hdc.adsmultiplatform.data.model.AdNetworkTestAdUnits

/** Google's test ad units, used when the app gives no ad unit id. */
internal val AdMobAndroidTestAdUnits = AdNetworkTestAdUnits(
    native = "ca-app-pub-3940256099942544/2247696110",
    nativeVideo = "ca-app-pub-3940256099942544/1044960115",
    interstitial = "ca-app-pub-3940256099942544/1033173712",
)
