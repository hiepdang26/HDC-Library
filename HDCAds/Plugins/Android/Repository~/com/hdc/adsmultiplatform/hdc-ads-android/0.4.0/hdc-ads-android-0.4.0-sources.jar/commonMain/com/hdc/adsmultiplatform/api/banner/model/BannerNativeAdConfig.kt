package com.hdc.adsmultiplatform.api.banner.model

import com.hdc.adsmultiplatform.presentation.banner.layouts.registry.BannerNativeAdLayoutCatalog

data class BannerNativeAdConfig(
    val ids: List<String>,
    val layoutNames: List<String> = BannerNativeAdLayoutCatalog.All,
    val timeReloadSeconds: Int = 0,
    val timeCountdownSeconds: Int = 5,
    val timeCollapseSeconds: Int = 5,
)
