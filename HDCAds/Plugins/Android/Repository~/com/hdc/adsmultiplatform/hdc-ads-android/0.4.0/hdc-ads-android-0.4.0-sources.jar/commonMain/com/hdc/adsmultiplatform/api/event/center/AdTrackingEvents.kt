package com.hdc.adsmultiplatform.api.event.center

import com.hdc.adsmultiplatform.api.event.model.AdTrackingEvent
import kotlin.concurrent.Volatile

/**
 * Impression, click and paid events of every ad format, on both platforms, as the networks report them. The HDCLib
 * Unity bridge listens and forwards them to the game.
 */
internal object AdTrackingEvents {
    @Volatile
    var listener: ((AdTrackingEvent) -> Unit)? = null

    fun emit(event: AdTrackingEvent) {
        if (event.instanceId.isEmpty()) {
            return
        }
        listener?.invoke(event)
    }
}
