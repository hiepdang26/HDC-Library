@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.common.viewmodel.port

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/** How a banner or popup ViewModel loads one ad of an instance and lets it go; a view binds it to a data source. */
@AdsConsoleSupportApi
@HiddenFromObjC
interface AdRuntimeLoader {
    fun load(
        instanceId: String,
        adUnitId: String,
        callback: (NativeAdLoadResult) -> Unit,
    )

    fun destroy(instanceId: String)

    /**
     * What the ad loaded for [instanceId] reports once it is up (impression, click, paid value) goes to [listener]
     * until [destroy]. A binding without events keeps this default.
     */
    fun listen(instanceId: String, listener: (NativeAdEvent) -> Unit) = Unit
}
