package com.hdc.adsmultiplatform.platform.android.view

import android.content.Context
import android.graphics.Color
import android.view.View

/** An invisible view the Compose layout places where an ad asset is drawn, so the host can follow its bounds. */
internal class NativeAdAssetMarkerView(
    context: Context,
    private val onLayoutChanged: (NativeAdAssetMarkerView) -> Unit,
) : View(context) {
    init {
        setBackgroundColor(Color.TRANSPARENT)
        isClickable = false
        isFocusable = false
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        onLayoutChanged(this)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        onLayoutChanged(this)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        onLayoutChanged(this)
    }
}
