package com.hdc.adsmultiplatform.platform.log

import android.util.Log

private const val AdsLogTag = "AdsMultiplatform"

internal actual fun writeAdsLog(isWarning: Boolean, message: String) {
    if (isWarning) {
        Log.w(AdsLogTag, message)
    } else {
        Log.d(AdsLogTag, message)
    }
}
