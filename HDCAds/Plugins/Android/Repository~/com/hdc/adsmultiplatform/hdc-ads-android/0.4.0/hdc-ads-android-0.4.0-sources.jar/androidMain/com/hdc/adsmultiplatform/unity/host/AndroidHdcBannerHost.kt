package com.hdc.adsmultiplatform.unity.host

import com.hdc.adsmultiplatform.api.banner.callback.BannerNativeAdCallback
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdConfig
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdError
import com.hdc.adsmultiplatform.presentation.banner.view.runtime.AndroidBannerRuntimes
import com.hdc.adsmultiplatform.unity.event.HdcNativeStateEvents
import com.hdc.adsmultiplatform.unity.gameplay.HdcUnityActivity
import com.hdc.adsmultiplatform.unity.port.HdcBannerHost

/** Native banners for the bridge, along the bottom of the Unity activity, by the Android banner runtimes. */
internal class AndroidHdcBannerHost(
    private val runtimes: AndroidBannerRuntimes,
) : HdcBannerHost {
    override fun load(id: String, config: BannerNativeAdConfig, events: HdcNativeStateEvents) {
        runtimes.create(id, config)
        runtimes.setCallback(id) { state -> events.onState(state) }
        runtimes.setAdCallbacks(
            id,
            callback = object : BannerNativeAdCallback {
                override fun onFailedToLoad(error: BannerNativeAdError) {
                    events.onLoadFailed(error.adUnitId, error.code, error.message)
                }
            },
            revenueCallback = null,
        )
        runtimes.load(id, HdcUnityActivity.require())
    }

    override fun show(id: String) {
        runtimes.show(id, HdcUnityActivity.require())
    }

    override fun expand(id: String, enableClick: Boolean): Boolean = runtimes.expand(id, enableClick)

    override fun collapse(id: String) {
        runtimes.collapse(id)
    }

    override fun hide(id: String) {
        runtimes.hide(id)
    }

    override fun destroy(id: String) {
        runtimes.destroy(id)
    }
}
