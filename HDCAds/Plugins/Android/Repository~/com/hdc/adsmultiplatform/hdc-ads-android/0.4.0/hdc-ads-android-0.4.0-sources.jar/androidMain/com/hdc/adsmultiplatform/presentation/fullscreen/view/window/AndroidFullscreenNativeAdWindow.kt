package com.hdc.adsmultiplatform.presentation.fullscreen.view.window

import android.app.Activity
import android.content.Context
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.platform.android.thread.runOnMainThread
import com.hdc.adsmultiplatform.platform.android.window.AndroidFullscreenBackBlocker
import com.hdc.adsmultiplatform.platform.android.window.AndroidFullscreenSystemUi
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdLoadPlan
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdShowPlan
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port.FullscreenNativeAdEvents
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port.FullscreenNativeAdOverlays
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port.GameplayPause
import com.hdc.adsmultiplatform.presentation.fullscreen.viewmodel.FullscreenNativeAdViewModel

private const val OverlayTagPrefix = "AdsMultiplatform.FullscreenNativeAdOverlay."

/**
 * Puts the fullscreen native ads of an activity on screen: each one is an overlay on top of the activity content, built
 * by [overlays] (Compose in the library, plain views in the Unity library). [viewModel] decides what a load keeps and
 * what a show draws; the game hears about it through [events], and [gameplay] pauses the game while an ad is on screen.
 */
internal class AndroidFullscreenNativeAdWindow(
    private val viewModel: FullscreenNativeAdViewModel<Context>,
    private val events: FullscreenNativeAdEvents,
    private val gameplay: GameplayPause,
    private val overlays: FullscreenNativeAdOverlays,
) {
    fun load(
        activity: Activity,
        instanceId: String,
        adUnitIdsCsv: String,
        enableReloadAfterShow: Boolean,
    ) {
        activity.runOnUiThread {
            val config = viewModel.loadConfig(adUnitIdsCsv, enableReloadAfterShow)
            if (keepsLoadedOrLoadingAd(activity, instanceId, config)) {
                return@runOnUiThread
            }
            hideNow(activity, instanceId, reloadAfterClose = false)
            viewModel.beginLoad(instanceId, config)
            requestFullscreen(activity, instanceId, config.ids)
        }
    }

    fun show(
        activity: Activity,
        instanceId: String,
        options: FullscreenNativeAdShowOptions,
        fallbackAdUnitId: String,
    ) {
        activity.runOnUiThread {
            hideNow(activity, instanceId, reloadAfterClose = false)
            showFullscreenNow(
                activity = activity,
                instanceId = instanceId,
                options = options,
                fallbackAdUnitId = fallbackAdUnitId,
            )
        }
    }

    fun hide(activity: Activity, instanceId: String?) {
        activity.runOnUiThread {
            hideNow(activity, instanceId)
        }
    }

    /** True while a fullscreen ad is over [activity]'s content: popups wait under it. Main thread only. */
    fun hasOverlay(activity: Activity): Boolean {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return false
        return hasFullscreenNativeAdOverlay(content)
    }

    /** Unity calls this on its own thread; the ad is destroyed on the main thread, where its views use it. */
    fun destroy(instanceId: String) {
        runOnMainThread {
            gameplay.clearOwner(instanceId)
            viewModel.destroy(instanceId)
        }
    }

    /** A repeated load that [viewModel] keeps is reported again, without a new request. */
    private fun keepsLoadedOrLoadingAd(
        activity: Activity,
        instanceId: String,
        config: FullscreenNativeAdConfig,
    ): Boolean {
        val plan = viewModel.keepLoadedOrLoadingAd(instanceId, config) {
            val content = activity.findViewById<ViewGroup>(android.R.id.content)
            content != null && hasFullscreenNativeAdOverlay(content, instanceId)
        }
        return when (plan) {
            FullscreenNativeAdLoadPlan.Request -> false
            FullscreenNativeAdLoadPlan.KeepLoading -> {
                events.onStateChanged(instanceId, NativeAdState.Loading)
                true
            }
            is FullscreenNativeAdLoadPlan.KeepLoaded -> {
                reportLoadResult(
                    instanceId,
                    NativeAdLoadResult(state = NativeAdState.Loaded, adUnitId = plan.adUnitId),
                )
                true
            }
        }
    }

    private fun requestFullscreen(context: Context, instanceId: String, adUnitIds: List<String>) {
        viewModel.request(context, instanceId, adUnitIds) { result -> reportLoadResult(instanceId, result) }
    }

    private fun reportLoadResult(instanceId: String, result: NativeAdLoadResult) {
        events.onLoadResult(instanceId, result)
        events.onStateChanged(instanceId, result.state)
    }

    private fun showFullscreenNow(
        activity: Activity,
        instanceId: String,
        options: FullscreenNativeAdShowOptions,
        fallbackAdUnitId: String,
    ) {
        val plan = viewModel.show(instanceId, options, fallbackAdUnitId)
        if (plan !is FullscreenNativeAdShowPlan.Ready) {
            events.onStateChanged(instanceId, NativeAdState.Failed)
            return
        }
        val tag = overlayTag(instanceId)
        events.onStateChanged(instanceId, NativeAdState.Shown)
        viewModel.displayed(instanceId, plan)
        AndroidFullscreenSystemUi.enter(activity)
        val view = overlays.create(activity, plan) { hide(activity, instanceId) }.apply {
            this.tag = tag
            isFocusable = true
            isFocusableInTouchMode = true
            setOnKeyListener { _, keyCode, event ->
                keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP
            }
        }
        activity.addContentView(
            view,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ),
        )
        view.requestFocus()
        AndroidFullscreenBackBlocker.register(activity, tag)
        if (plan.options.pauseGameplay) {
            gameplay.pause(activity, instanceId)
        }
        events.onDisplayed(instanceId)
    }

    private fun hideNow(
        activity: Activity,
        instanceId: String? = null,
        reloadAfterClose: Boolean = true,
    ) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        for (index in content.childCount - 1 downTo 0) {
            val child = content.getChildAt(index)
            val tag = child.tag as? String
            if (shouldRemoveOverlay(tag, instanceId)) {
                content.removeViewAt(index)
                overlays.release(child)
                AndroidFullscreenBackBlocker.unregister(activity, tag)
                val removedInstanceId = instanceIdFromOverlayTag(tag)
                if (removedInstanceId != null) {
                    gameplay.resume(activity, removedInstanceId)
                    val shouldReloadAfterShow =
                        reloadAfterClose && viewModel.shouldReloadAfterClose(removedInstanceId)
                    viewModel.clearLoaded(removedInstanceId)
                    events.onStateChanged(removedInstanceId, NativeAdState.onClosed)
                    viewModel.closed(removedInstanceId)
                    events.onClosed(removedInstanceId)
                    if (shouldReloadAfterShow) {
                        reloadFullscreenAfterShow(activity, removedInstanceId)
                    }
                }
            }
        }
        if (!hasFullscreenNativeAdOverlay(content)) {
            AndroidFullscreenSystemUi.exit(activity)
        }
    }

    private fun overlayTag(instanceId: String): String =
        "$OverlayTagPrefix$instanceId"

    private fun shouldRemoveOverlay(tag: String?, instanceId: String?): Boolean {
        if (tag?.startsWith(OverlayTagPrefix) != true) {
            return false
        }
        return instanceId == null || tag == overlayTag(instanceId)
    }

    private fun hasFullscreenNativeAdOverlay(content: ViewGroup): Boolean {
        for (index in 0 until content.childCount) {
            val tag = content.getChildAt(index).tag as? String
            if (tag?.startsWith(OverlayTagPrefix) == true) {
                return true
            }
        }
        return false
    }

    private fun hasFullscreenNativeAdOverlay(content: ViewGroup, instanceId: String): Boolean {
        val tag = overlayTag(instanceId)
        for (index in 0 until content.childCount) {
            if (content.getChildAt(index).tag == tag) {
                return true
            }
        }
        return false
    }

    private fun instanceIdFromOverlayTag(tag: String?): String? =
        tag?.takeIf { it.startsWith(OverlayTagPrefix) }
            ?.removePrefix(OverlayTagPrefix)
            ?.takeIf { it.isNotBlank() }

    private fun reloadFullscreenAfterShow(activity: Activity, instanceId: String) {
        val config = viewModel.reloadConfig(instanceId)
        requestFullscreen(activity.applicationContext, instanceId, config.ids)
    }
}
