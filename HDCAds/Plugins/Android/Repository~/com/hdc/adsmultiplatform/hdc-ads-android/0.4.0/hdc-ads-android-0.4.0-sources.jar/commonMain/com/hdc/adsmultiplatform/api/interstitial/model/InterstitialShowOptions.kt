package com.hdc.adsmultiplatform.api.interstitial.model

data class InterstitialShowOptions(
    val immersiveMode: Boolean = true,
)
