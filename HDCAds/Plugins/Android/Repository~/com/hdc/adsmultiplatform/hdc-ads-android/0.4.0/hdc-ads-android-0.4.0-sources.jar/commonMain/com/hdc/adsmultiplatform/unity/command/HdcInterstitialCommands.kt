package com.hdc.adsmultiplatform.unity.command

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.api.interstitial.registry.InterstitialAdRegistry
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.unity.event.HdcEventType
import com.hdc.adsmultiplatform.unity.event.HdcEvents
import com.hdc.adsmultiplatform.unity.event.HdcFormat
import com.hdc.adsmultiplatform.unity.event.HdcInterstitialEvents
import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.port.HdcInterstitialHost
import com.hdc.adsmultiplatform.unity.thread.hdcQueryOnMain
import com.hdc.adsmultiplatform.unity.thread.hdcRunOnMainCatching

/**
 * `interstitial.*` commands.
 *
 * - `load` `{id, adUnitIds:[…], bufferSize?, autoReload?}`: ad units are tried in order.
 * - `show` `{id, immersiveMode?}` returns whether a ready ad started to show.
 * - `isReady` `{id}`, `destroy` `{id}`.
 */
internal object HdcInterstitialCommands {
    private val host: HdcInterstitialHost by lazy { adsGet() }

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val config = InterstitialAdConfig(
            ids = adUnitIds,
            autoReload = args.boolean("autoReload", true),
            preloadBufferSize = args.int("bufferSize", 1).coerceAtLeast(1),
        )
        hdcRunOnMainCatching(
            onError = { error ->
                HdcEvents.emit(
                    id = id,
                    format = HdcFormat.Interstitial,
                    type = HdcEventType.LoadFailed,
                    fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
                )
            },
        ) {
            InterstitialAdRegistry.setCallback(id, HdcInterstitialEvents(id))
            host.load(id, config)
        }
        return true
    }

    fun show(args: HdcArgs): Boolean {
        val id = args.id()
        val options = InterstitialShowOptions(immersiveMode = args.boolean("immersiveMode", true))
        return hdcQueryOnMain(fallback = false) { host.show(id, options) }
    }

    fun isReady(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { host.isReady(id) }
    }

    fun destroy(args: HdcArgs): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { host.destroy(id) }
        return true
    }
}
