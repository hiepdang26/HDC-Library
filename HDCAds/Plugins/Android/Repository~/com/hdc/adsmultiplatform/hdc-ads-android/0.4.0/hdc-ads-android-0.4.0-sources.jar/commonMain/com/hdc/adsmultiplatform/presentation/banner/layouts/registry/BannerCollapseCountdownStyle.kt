package com.hdc.adsmultiplatform.presentation.banner.layouts.registry

enum class BannerCollapseCountdownStyle {
    None,
    Ring,
    Horizontal,
    Segments,
}
