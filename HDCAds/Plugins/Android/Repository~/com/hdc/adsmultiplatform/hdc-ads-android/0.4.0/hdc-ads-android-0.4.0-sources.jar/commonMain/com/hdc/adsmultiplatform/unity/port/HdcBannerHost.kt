package com.hdc.adsmultiplatform.unity.port

import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdConfig
import com.hdc.adsmultiplatform.unity.event.HdcNativeStateEvents

/** Native banners for the bridge. Called on the main thread only. */
internal interface HdcBannerHost {
    /** Loads [config] for [id]; [events] hears its states and the error of each failed load. */
    fun load(id: String, config: BannerNativeAdConfig, events: HdcNativeStateEvents)

    fun show(id: String)

    fun expand(id: String, enableClick: Boolean): Boolean

    fun collapse(id: String)

    fun hide(id: String)

    fun destroy(id: String)
}
