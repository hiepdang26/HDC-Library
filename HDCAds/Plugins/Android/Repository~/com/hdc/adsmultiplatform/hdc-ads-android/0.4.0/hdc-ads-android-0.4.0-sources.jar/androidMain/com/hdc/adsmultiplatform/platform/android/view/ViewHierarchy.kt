package com.hdc.adsmultiplatform.platform.android.view

import android.view.View
import android.view.ViewGroup

/** Visible, laid out with a size, and somewhere inside [parentView]. */
internal fun View.isAttachedAndSizedInside(parentView: ViewGroup): Boolean =
    visibility == View.VISIBLE &&
        width > 0 &&
        height > 0 &&
        isDescendantOf(parentView)

internal fun View.isDescendantOf(parentView: ViewGroup): Boolean {
    var current: View? = this
    while (current != null) {
        if (current === parentView) {
            return true
        }
        current = current.parent as? View
    }
    return false
}
