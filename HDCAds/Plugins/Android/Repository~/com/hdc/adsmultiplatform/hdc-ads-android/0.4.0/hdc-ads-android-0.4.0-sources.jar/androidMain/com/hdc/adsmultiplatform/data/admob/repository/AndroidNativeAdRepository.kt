package com.hdc.adsmultiplatform.data.admob.repository

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdapterResponseInfo
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.NativeAd
import com.hdc.adsmultiplatform.api.event.center.AdTrackingEvents
import com.hdc.adsmultiplatform.api.event.model.AdTrackingEvent
import com.hdc.adsmultiplatform.api.event.model.AdTrackingEventNames
import com.hdc.adsmultiplatform.data.admob.config.AdMobAndroidTestAdUnits
import com.hdc.adsmultiplatform.data.admob.model.AndroidNativeAdSlot
import com.hdc.adsmultiplatform.data.model.LoadedNativeAdInfo
import com.hdc.adsmultiplatform.data.port.NativeAdEventListener
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.domain.model.AdPaidValue
import com.hdc.adsmultiplatform.domain.model.AdResponseInfo
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdFormat
import com.hdc.adsmultiplatform.domain.model.NativeAdFormats
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdPlacement
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.domain.model.NativeAdUnitWaterfall
import com.hdc.adsmultiplatform.domain.policy.NoAdUnitConfiguredMessage
import com.hdc.adsmultiplatform.domain.policy.resolveAdUnitIds
import com.hdc.adsmultiplatform.domain.repository.FullscreenAdInteractions
import com.hdc.adsmultiplatform.domain.repository.LoadedNativeAds
import com.hdc.adsmultiplatform.platform.android.thread.runOnMainThread
import com.hdc.adsmultiplatform.platform.build.DevelopmentBuild
import com.hdc.adsmultiplatform.platform.log.AdsLog
import java.util.concurrent.ConcurrentHashMap

/** AdMob (Google Mobile Ads) native ads: one slot per format and instance, each loading its waterfall in order. */
internal class AndroidNativeAdRepository(
    private val fullscreenEvents: NativeAdEventListener,
    private val fullscreenInteractions: FullscreenAdInteractions,
) : AndroidNativeAdSource, LoadedNativeAds<NativeAd> {
    private val slots = ConcurrentHashMap<NativeAdPlacement, AndroidNativeAdSlot>()
    private val eventListeners = ConcurrentHashMap<NativeAdPlacement, (NativeAdEvent) -> Unit>()
    private val handler = Handler(Looper.getMainLooper())

    override fun loadWithResult(
        format: NativeAdFormat,
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        retryOnFailure: Boolean,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        DevelopmentBuild.learn(context)
        val waterfall = NativeAdUnitWaterfall.fromList(
            resolveAdUnitIds(adUnitIds, AdMobAndroidTestAdUnits.native, isDevelopment = DevelopmentBuild.isDevelopment != false),
        )
        val placement = placement(format, instanceId)
        val slot = slots.getOrPut(placement) { AndroidNativeAdSlot() }
        val version = slot.requestVersion + 1
        slot.requestVersion = version
        slot.retryRunnable?.let(handler::removeCallbacks)
        slot.retryRunnable = null
        slot.reloadPolicy.resetAfterLoaded()
        slot.nativeAd?.destroy()
        slot.nativeAd = null
        slot.loadedAdUnitId = null
        slot.requestedAdUnitIds = adUnitIds
        slot.isLoading = true
        if (waterfall.ids.isEmpty()) {
            slot.isLoading = false
            AdsLog.warn("Android native ad not loaded: format=${format.key} instance=$instanceId reason=no_ad_unit_configured")
            callback(NativeAdLoadResult(state = NativeAdState.Failed, message = NoAdUnitConfiguredMessage))
            return
        }
        callback(NativeAdLoadResult(state = NativeAdState.Loading, adUnitId = waterfall.ids.firstOrNull().orEmpty()))

        MobileAds.initialize(context.applicationContext)
        loadNext(context, placement, waterfall.ids, index = 0, version = version, retryOnFailure = retryOnFailure, callback = callback)
    }

    override fun loadedAd(format: NativeAdFormat, instanceId: String): NativeAd? =
        slots[placement(format, instanceId)]?.nativeAd

    override fun hasLoadedAd(format: NativeAdFormat, instanceId: String): Boolean =
        loadedAd(format, instanceId) != null

    override fun loadedAdUnitId(format: NativeAdFormat, instanceId: String): String? =
        slots[placement(format, instanceId)]?.loadedAdUnitId

    override fun loadedAdInfo(format: NativeAdFormat, instanceId: String): LoadedNativeAdInfo? {
        val ad = loadedAd(format, instanceId) ?: return null
        val responseInfo = ad.responseInfo
        val adapter = responseInfo?.loadedAdapterResponseInfo
        return LoadedNativeAdInfo(
            headline = ad.headline,
            body = ad.body,
            callToAction = ad.callToAction,
            advertiser = ad.advertiser,
            store = ad.store,
            price = ad.price,
            mediationAdapter = adapter?.adapterClassName,
            responseId = responseInfo?.responseId,
            adSource = adapter?.adSourceName,
            adSourceId = adapter?.adSourceId,
        )
    }

    override fun requestedAdUnitIds(instanceId: String): List<String> =
        slots[placement(NativeAdFormats.Fullscreen, instanceId)]?.requestedAdUnitIds.orEmpty()

    override fun isLoading(instanceId: String): Boolean =
        slots[placement(NativeAdFormats.Fullscreen, instanceId)]?.isLoading == true

    override fun loadedAdAgeMillis(instanceId: String): Long? {
        val slot = slots[placement(NativeAdFormats.Fullscreen, instanceId)] ?: return null
        if (slot.nativeAd == null) return null
        return SystemClock.elapsedRealtime() - slot.loadedAtElapsedMillis
    }

    override fun clearLoaded(format: NativeAdFormat, instanceId: String) {
        slots[placement(format, instanceId)]?.let { slot ->
            slot.nativeAd?.destroy()
            slot.nativeAd = null
            slot.loadedAdUnitId = null
        }
    }

    override fun setEventListener(format: NativeAdFormat, instanceId: String, listener: ((NativeAdEvent) -> Unit)?) {
        val placement = placement(format, instanceId)
        if (listener == null) {
            eventListeners.remove(placement)
        } else {
            eventListeners[placement] = listener
        }
    }

    override fun destroy(format: NativeAdFormat, instanceId: String) {
        eventListeners.remove(placement(format, instanceId))
        slots.remove(placement(format, instanceId))?.let { slot ->
            slot.retryRunnable?.let(handler::removeCallbacks)
            slot.nativeAd?.destroy()
        }
    }

    private fun loadNext(
        context: Context,
        placement: NativeAdPlacement,
        adUnitIds: List<String>,
        index: Int,
        version: Int,
        retryOnFailure: Boolean,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        val slot = slots[placement] ?: return
        val adUnitId = adUnitIds.getOrNull(index)
        if (adUnitId == null) {
            slot.isLoading = false
            callback(
                NativeAdLoadResult(
                    state = NativeAdState.Failed,
                    code = NativeAdLoadResult.NoErrorCode,
                    message = "No native ad unit id available",
                ),
            )
            return
        }

        AdLoader.Builder(context, adUnitId)
            .forNativeAd { ad ->
                if (version != slot.requestVersion) {
                    ad.destroy()
                    return@forNativeAd
                }
                slot.retryRunnable?.let(handler::removeCallbacks)
                slot.retryRunnable = null
                slot.reloadPolicy.resetAfterLoaded()
                slot.nativeAd = ad
                slot.loadedAdUnitId = adUnitId
                slot.isLoading = false
                slot.loadedAtElapsedMillis = SystemClock.elapsedRealtime()
                ad.setOnPaidEventListener { adValue ->
                    val response = ad.responseInfo
                    val adapter = response?.loadedAdapterResponseInfo
                    emitEvent(
                        placement,
                        NativeAdEvent.Paid(
                            value = AdPaidValue(
                                valueMicros = adValue.valueMicros,
                                currencyCode = adValue.currencyCode,
                                precision = adValue.precisionType,
                            ),
                            response = AdResponseInfo(
                                mediationAdapter = adapter?.adapterClassName,
                                adSource = adapter?.adSourceName,
                                responseId = response?.responseId,
                            ),
                        ),
                    )
                }
                logLoadedNativeAd(placement, adUnitId, ad)
                val source = ad.responseInfo?.loadedAdapterResponseInfo
                callback(
                    NativeAdLoadResult(
                        state = NativeAdState.Loaded,
                        adUnitId = adUnitId,
                        adSourceId = source?.adSourceId.orEmpty(),
                        adSourceName = source?.adSourceName.orEmpty(),
                    ),
                )
            }
            .withAdListener(
                object : AdListener() {
                    override fun onAdImpression() {
                        emitEvent(placement, NativeAdEvent.Impression)
                    }

                    override fun onAdClicked() {
                        logNativeAdClickEvent("clicked", placement, slot.nativeAd)
                        markFullscreenAdInteraction(placement)
                        emitEvent(placement, NativeAdEvent.Clicked)
                    }

                    override fun onAdOpened() {
                        logNativeAdClickEvent("opened", placement, slot.nativeAd)
                        markFullscreenAdInteraction(placement)
                        emitEvent(placement, NativeAdEvent.Opened)
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        if (version != slot.requestVersion) {
                            return
                        }
                        val hasNextAdUnit = index + 1 < adUnitIds.size
                        if (!hasNextAdUnit) {
                            slot.isLoading = false
                        }
                        callback(
                            NativeAdLoadResult(
                                state = NativeAdState.Failed,
                                adUnitId = adUnitId,
                                code = error.code,
                                message = error.message,
                            ),
                        )
                        if (hasNextAdUnit) {
                            callback(
                                NativeAdLoadResult(
                                    state = NativeAdState.Loading,
                                    adUnitId = adUnitIds.getOrNull(index + 1).orEmpty(),
                                ),
                            )
                            loadNext(context, placement, adUnitIds, index + 1, version, retryOnFailure, callback)
                        } else if (retryOnFailure && placement.format == NativeAdFormats.Fullscreen) {
                            scheduleRetry(context, placement, adUnitIds, version, callback)
                        }
                    }
                },
            )
            .build()
            .loadAd(AdRequest.Builder().build())
    }

    private fun scheduleRetry(
        context: Context,
        placement: NativeAdPlacement,
        adUnitIds: List<String>,
        version: Int,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        val slot = slots[placement] ?: return
        val delayMillis = slot.reloadPolicy.nextFailureRetryDelayMillis()
        val retry = Runnable {
            val activeSlot = slots[placement] ?: return@Runnable
            if (version != activeSlot.requestVersion) {
                return@Runnable
            }
            activeSlot.isLoading = true
            callback(NativeAdLoadResult(state = NativeAdState.Loading, adUnitId = adUnitIds.firstOrNull().orEmpty()))
            loadNext(context, placement, adUnitIds, index = 0, version = version, retryOnFailure = true, callback = callback)
        }
        slot.retryRunnable = retry
        handler.postDelayed(retry, delayMillis)
    }

    private fun emitEvent(placement: NativeAdPlacement, event: NativeAdEvent) {
        track(placement, event)
        if (placement.format == NativeAdFormats.Fullscreen) {
            fullscreenEvents.onAdEvent(placement.instanceId, event)
        }
        // GMA reports paid values on a background thread; the listeners (ViewModels) live on the main thread.
        runOnMainThread { eventListeners[placement]?.invoke(event) }
    }

    // Impression, click and paid events of every format go to the tracking stream too, for the HDCLib bridge.
    private fun track(placement: NativeAdPlacement, event: NativeAdEvent) {
        val name = when (event) {
            NativeAdEvent.Impression -> AdTrackingEventNames.Impression
            NativeAdEvent.Clicked -> AdTrackingEventNames.Clicked
            is NativeAdEvent.Paid -> AdTrackingEventNames.Paid
            NativeAdEvent.Opened -> return
        }
        val slot = slots[placement]
        val response = slot?.nativeAd?.responseInfo
        val paid = event as? NativeAdEvent.Paid
        AdTrackingEvents.emit(
            AdTrackingEvent(
                instanceId = placement.hostAlias(),
                format = placement.format.key,
                name = name,
                adUnitId = slot?.loadedAdUnitId.orEmpty(),
                valueMicros = paid?.value?.valueMicros ?: 0L,
                currencyCode = paid?.value?.currencyCode.orEmpty(),
                precision = paid?.value?.precision ?: 0,
                adSourceName = paid?.response?.adSource ?: response?.loadedAdapterResponseInfo?.adSourceName.orEmpty(),
                mediationAdapter = paid?.response?.mediationAdapter ?: response?.mediationAdapterClassName.orEmpty(),
                responseId = paid?.response?.responseId ?: response?.responseId.orEmpty(),
            ),
        )
    }

    private fun placement(format: NativeAdFormat, instanceId: String): NativeAdPlacement =
        NativeAdPlacement(format, instanceId)

    private fun markFullscreenAdInteraction(placement: NativeAdPlacement) {
        if (placement.format == NativeAdFormats.Fullscreen) {
            fullscreenInteractions.markInteraction(placement.instanceId)
        }
    }

    @Suppress("DEPRECATION")
    private fun logLoadedNativeAd(
        placement: NativeAdPlacement,
        adUnitId: String,
        ad: NativeAd,
    ) {
        if (!AdsLog.isDebugEnabled) {
            return
        }
        runCatching {
            val media = ad.mediaContent
            val videoController = media?.videoController
            val responseInfo = ad.responseInfo
            AdsLog.debug(
                "Android native ad loaded detail basic: " +
                    "format=${placement.format} instance=${placement.instanceId} adUnitId=$adUnitId " +
                    "responseId=${responseInfo?.responseId.orNullLabel()} " +
                    "mediationAdapter=${responseInfo?.mediationAdapterClassName.orNullLabel()} " +
                    "headline=${ad.headline.debugValue()} cta=${ad.callToAction.debugValue()} " +
                    "body=${ad.body.debugValue()} advertiser=${ad.advertiser.debugValue()} " +
                    "store=${ad.store.debugValue()} price=${ad.price.debugValue()} starRating=${ad.starRating?.toString().orNullLabel()} " +
                    "icon=${ad.icon.debugImageValue()} images=${ad.images.debugImagesValue()} " +
                    "adChoices=${ad.adChoicesInfo?.text?.toString().debugValue()} " +
                    "adChoicesImages=${ad.adChoicesInfo?.images.debugImagesValue()}",
            )
            AdsLog.debug(
                "Android native ad loaded detail media: " +
                    "format=${placement.format} instance=${placement.instanceId} responseId=${responseInfo?.responseId.orNullLabel()} " +
                    "mediaHasVideo=${media?.hasVideoContent().orFalseLabel()} " +
                    "mediaAspectRatio=${media?.aspectRatio?.toString().orNullLabel()} " +
                    "mediaDuration=${media?.duration?.toString().orNullLabel()} " +
                    "mediaCurrentTime=${media?.currentTime?.toString().orNullLabel()} " +
                    "mediaMainImage=${(media?.mainImage != null)} " +
                    "videoMuted=${videoController?.isMuted?.toString().orNullLabel()} " +
                    "videoPlaybackState=${videoController?.playbackState?.toString().orNullLabel()} " +
                    "videoCustomControls=${videoController?.isCustomControlsEnabled?.toString().orNullLabel()} " +
                    "videoClickToExpand=${videoController?.isClickToExpandEnabled?.toString().orNullLabel()} " +
                    "customClickGesture=${ad.isCustomClickGestureEnabled} customMute=${ad.isCustomMuteThisAdEnabled}",
            )
            AdsLog.debug(
                "Android native ad loaded detail response: " +
                    "format=${placement.format} instance=${placement.instanceId} responseId=${responseInfo?.responseId.orNullLabel()} " +
                    "extras=${ad.extras.debugBundleValue()} " +
                    "responseExtras=${responseInfo?.responseExtras.debugBundleValue()} " +
                    "loadedAdapter=${responseInfo?.loadedAdapterResponseInfo.debugAdapterValue()}",
            )
            logLongAndroidNativeAdDetail(
                "Android native ad loaded responseInfo: " +
                    "format=${placement.format} instance=${placement.instanceId} responseId=${responseInfo?.responseId.orNullLabel()} ",
                responseInfo.debugObjectValue(maxLength = 6_000),
            )
            responseInfo?.adapterResponses.orEmpty().forEachIndexed { adapterIndex, adapter ->
                AdsLog.debug(
                    "Android native ad loaded adapter[$adapterIndex]: " +
                        "format=${placement.format} instance=${placement.instanceId} " +
                        adapter.debugAdapterValue(),
                )
            }
        }.onFailure { error ->
            AdsLog.warn(
                "Android native ad loaded detail failed: format=${placement.format} " +
                    "instance=${placement.instanceId} adUnitId=$adUnitId error=${error.message}",
            )
        }
    }

    private fun logNativeAdClickEvent(
        event: String,
        placement: NativeAdPlacement,
        ad: NativeAd?,
    ) {
        val responseInfo = ad?.responseInfo
        AdsLog.debug(
            "Android native ad $event: format=${placement.format} instance=${placement.instanceId} " +
                "responseId=${responseInfo?.responseId.orNullLabel()} " +
                "loadedAdapter=${responseInfo?.loadedAdapterResponseInfo.debugAdapterValue()}",
        )
    }
}

private fun String?.debugValue(maxLength: Int = 180): String =
    orNullLabel()
        .replace("\n", "\\n")
        .let { if (it.length > maxLength) it.take(maxLength) + "..." else it }

private fun String?.orNullLabel(): String =
    this ?: "null"

private fun Boolean?.orFalseLabel(): String =
    this?.toString() ?: "null"

@Suppress("DEPRECATION")
private fun Bundle?.debugBundleValue(maxLength: Int = 700): String =
    if (this == null) {
        "null"
    } else {
        keySet()
            .sorted()
            .joinToString(prefix = "{", postfix = "}") { key -> "$key=${get(key)}" }
            .replace("\n", "\\n")
            .let { if (it.length > maxLength) it.take(maxLength) + "..." else it }
    }

private fun Any?.debugObjectValue(maxLength: Int = 900): String =
    if (this == null) {
        "null"
    } else {
        toString()
            .replace("\n", "\\n")
            .let { if (it.length > maxLength) it.take(maxLength) + "..." else it }
    }

private fun NativeAd.Image?.debugImageValue(): String =
    if (this == null) {
        "null"
    } else {
        "uri=${uri?.toString().orNullLabel()},scale=$scale," +
            "drawable=${drawable?.intrinsicWidth ?: 0}x${drawable?.intrinsicHeight ?: 0}"
    }

private fun List<NativeAd.Image>?.debugImagesValue(maxItems: Int = 4): String =
    if (this == null) {
        "null"
    } else {
        take(maxItems)
            .mapIndexed { index, image -> "$index(${image.debugImageValue()})" }
            .joinToString(prefix = "[size=$size ", postfix = "]")
    }

private fun AdapterResponseInfo?.debugAdapterValue(): String =
    if (this == null) {
        "null"
    } else {
        "adapterClass=${adapterClassName.orNullLabel()} " +
            "latencyMs=$latencyMillis " +
            "adSourceName=${adSourceName.orNullLabel()} " +
            "adSourceId=${adSourceId.orNullLabel()} " +
            "adSourceInstanceName=${adSourceInstanceName.orNullLabel()} " +
            "adSourceInstanceId=${adSourceInstanceId.orNullLabel()} " +
            "error=${adError?.toString().orNullLabel()} " +
            "credentials=${credentials.debugBundleValue()}"
    }

private fun logLongAndroidNativeAdDetail(prefix: String, value: String) {
    val chunkSize = 2_500
    value.chunked(chunkSize).forEachIndexed { index, chunk ->
        AdsLog.debug("$prefix chunk=$index $chunk")
    }
}
