package com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port

import android.app.Activity

/** Pauses the game while a fullscreen ad covers it; [owner] is the ad that asked for the pause. */
internal interface GameplayPause {
    fun pause(activity: Activity, owner: String)

    fun resume(activity: Activity, owner: String)

    fun clearOwner(owner: String)
}
