package com.hdc.adsmultiplatform.unity.thread

import android.os.Handler
import android.os.Looper
import com.hdc.adsmultiplatform.unity.gameplay.HdcUnityActivity
import com.hdc.adsmultiplatform.unity.log.HdcLog

private const val MainQueryTimeoutMillis = 2_000L

private val mainHandler: Handler by lazy { Handler(Looper.getMainLooper()) }

private val isMainThread: Boolean
    get() = Looper.myLooper() == Looper.getMainLooper()

private val mainQueries = HdcMainQueries(post = { mainHandler.post(it) }, timeoutMillis = MainQueryTimeoutMillis)

private val unityPauseWatch = HdcUnityPauseWatch(mainQueries, HdcUnityActivity::current) { mainHandler.post(it) }

internal actual fun hdcRunOnMain(block: () -> Unit) {
    if (isMainThread) {
        block()
    } else {
        mainHandler.post(block)
    }
}

internal actual fun hdcPostToMain(block: () -> Unit) {
    mainHandler.post(block)
}

internal actual fun hdcIsMainThread(): Boolean = isMainThread

internal actual fun <T> hdcQueryOnMain(fallback: T, block: () -> T): T {
    if (isMainThread) {
        return block()
    }
    unityPauseWatch.ensureStarted()
    val answer = mainQueries.query(fallback, block)
    when (answer.outcome) {
        HdcMainQueries.Outcome.TimedOut -> HdcLog.warn("main thread query timed out")
        HdcMainQueries.Outcome.Pausing -> HdcLog.debug("main thread is pausing Unity: answered without waiting")
        HdcMainQueries.Outcome.Answered -> Unit
    }
    return answer.value
}

/** Starts telling the main-thread queries when Unity's activity pauses; the bridge calls it when the SDK starts. */
internal fun hdcWatchUnityPause() {
    unityPauseWatch.ensureStarted()
}
