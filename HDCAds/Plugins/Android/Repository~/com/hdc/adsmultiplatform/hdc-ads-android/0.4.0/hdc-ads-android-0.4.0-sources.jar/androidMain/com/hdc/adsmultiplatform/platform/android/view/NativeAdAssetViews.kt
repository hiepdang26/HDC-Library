package com.hdc.adsmultiplatform.platform.android.view

import android.graphics.Rect
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout

/** The part of this view that lies inside [container], in [container]'s coordinates. Empty when none does. */
internal fun View.visibleBoundsIn(container: View): Rect {
    val containerLocation = IntArray(2)
    val location = IntArray(2)
    container.getLocationOnScreen(containerLocation)
    getLocationOnScreen(location)
    val left = (location[0] - containerLocation[0]).coerceIn(0, container.width.coerceAtLeast(0))
    val top = (location[1] - containerLocation[1]).coerceIn(0, container.height.coerceAtLeast(0))
    val visibleWidth = width.coerceAtMost((container.width - left).coerceAtLeast(0))
    val visibleHeight = height.coerceAtMost((container.height - top).coerceAtLeast(0))
    return Rect(left, top, left + visibleWidth, top + visibleHeight)
}

/** Places this view at the given frame inside its FrameLayout parent, keeping layout params that already match. */
internal fun View.placeAt(left: Int, top: Int, width: Int, height: Int) {
    val currentParams = layoutParams as? FrameLayout.LayoutParams
    if (
        currentParams == null ||
        currentParams.width != width ||
        currentParams.height != height ||
        currentParams.leftMargin != left ||
        currentParams.topMargin != top
    ) {
        layoutParams = FrameLayout.LayoutParams(width, height).apply {
            leftMargin = left
            topMargin = top
        }
    }
}

internal fun View.applyAssetClickState(enabled: Boolean) {
    isClickable = enabled
    isFocusable = enabled
    setOnTouchListener(null)
}

/** This view, taken out of its current parent so that an AndroidView factory can add it again. */
internal fun <T : View> T.detachedFromParent(): T {
    (parent as? ViewGroup)?.removeView(this)
    return this
}
