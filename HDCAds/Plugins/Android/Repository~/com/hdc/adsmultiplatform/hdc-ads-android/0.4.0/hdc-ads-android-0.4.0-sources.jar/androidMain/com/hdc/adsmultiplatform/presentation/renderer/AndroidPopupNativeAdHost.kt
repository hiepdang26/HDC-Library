package com.hdc.adsmultiplatform.presentation.renderer

import android.view.View
import com.hdc.adsmultiplatform.domain.model.NativeAdState

/** A popup ad Unity shows without Compose: the popup runtime places [view] and passes it each popup state. */
internal interface AndroidPopupNativeAdHost {
    val view: View

    fun render(
        instanceId: String,
        fallbackAdUnitId: String,
        layoutName: String,
        closeSecondsRemaining: Int,
        showClose: Boolean,
        enableCtrOverlay: Boolean,
        onStateChanged: (NativeAdState) -> Unit,
        onCloseClick: () -> Unit,
    )

    fun release()
}
