package com.hdc.adsmultiplatform.presentation.admob.fullscreen.touch

import android.content.Context
import android.view.MotionEvent
import android.widget.TextView

internal class RoutedAdAssetTextView(context: Context) : TextView(context) {
    var touchRouteProvider: ((MotionEvent) -> AdAssetTouchRoute)? = null
    private var activeRoute: AdAssetTouchRoute? = null

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        val route = when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchRouteProvider?.invoke(event).also { activeRoute = it }
            }
            else -> activeRoute
        } ?: AdAssetTouchRoute.Self

        val handled = when {
            route.consumeOnly -> true
            route.target != null -> {
                val dispatched = dispatchTouchBetweenViews(event, this, route.target)
                if (!dispatched && event.actionMasked == MotionEvent.ACTION_UP) {
                    route.target.performClick()
                }
                true
            }
            else -> super.dispatchTouchEvent(event)
        }

        if (
            event.actionMasked == MotionEvent.ACTION_UP ||
            event.actionMasked == MotionEvent.ACTION_CANCEL
        ) {
            activeRoute = null
        }
        return handled
    }

    override fun performClick(): Boolean =
        super.performClick()
}
