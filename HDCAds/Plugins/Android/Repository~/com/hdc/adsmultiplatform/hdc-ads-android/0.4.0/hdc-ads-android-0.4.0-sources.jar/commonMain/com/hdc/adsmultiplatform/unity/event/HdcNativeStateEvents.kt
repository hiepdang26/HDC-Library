package com.hdc.adsmultiplatform.unity.event

import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.unity.thread.hdcPostToMain

/**
 * Turns the state stream of a native banner or popup into events. Repeated states are dropped (a banner reports its
 * state on every countdown tick). A failure is reported one main loop later, and only if nothing moved on in between:
 * loading goes on to the next ad unit right after a failure.
 */
internal class HdcNativeStateEvents(
    private val id: String,
    private val format: String,
    private val shownFields: () -> Map<String, Any?> = { emptyMap() },
) {
    private var lastState: NativeAdState? = null
    private var failurePending = false
    private var showRequested = false
    private var lastFailure: NativeAdLoadResult? = null

    fun onShowRequested() {
        showRequested = true
    }

    /** The error of the latest failed load, which the Failed state that follows reports. */
    fun onLoadFailed(adUnitId: String, code: Int, message: String) {
        lastFailure = NativeAdLoadResult(state = NativeAdState.Failed, adUnitId = adUnitId, code = code, message = message)
    }

    fun onState(state: NativeAdState) {
        if (state == lastState) {
            return
        }
        lastState = state
        when (state) {
            NativeAdState.Loading, NativeAdState.Idle -> failurePending = false
            NativeAdState.Loaded -> {
                failurePending = false
                emit(HdcEventType.Loaded)
            }
            NativeAdState.Shown -> {
                showRequested = false
                emit(HdcEventType.Shown, shownFields())
            }
            NativeAdState.onClosed -> {
                showRequested = false
                emit(HdcEventType.Closed)
            }
            NativeAdState.Failed -> onFailed()
        }
    }

    private fun onFailed() {
        if (showRequested) {
            showRequested = false
            lastFailure = null
            emit(HdcEventType.ShowFailed, HdcEvents.error(NativeAdLoadResult.NoErrorCode, "Show failed"))
            return
        }
        failurePending = true
        hdcPostToMain {
            if (failurePending && lastState == NativeAdState.Failed) {
                failurePending = false
                val failure = lastFailure
                lastFailure = null
                val fields = if (failure == null) {
                    HdcEvents.error(NativeAdLoadResult.NoErrorCode, "No ad loaded")
                } else {
                    mapOf("adUnitId" to failure.adUnitId) + HdcEvents.error(failure.code, failure.message)
                }
                emit(HdcEventType.LoadFailed, fields)
            }
        }
    }

    private fun emit(type: String, fields: Map<String, Any?> = emptyMap()) {
        HdcEvents.emit(id = id, format = format, type = type, fields = fields)
    }
}
