package com.hdc.adsmultiplatform.presentation.interstitial.viewmodel.port

import com.hdc.adsmultiplatform.api.interstitial.callback.InterstitialAdCallback
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult

interface InterstitialAdLoader {
    fun configure(alias: String, config: InterstitialAdConfig)
    fun setCallback(alias: String, callback: InterstitialAdCallback?)
    fun load(
        alias: String,
        onResult: (NativeAdLoadResult) -> Unit,
    )

    fun load(
        alias: String,
        bufferSize: Int,
        onResult: (NativeAdLoadResult) -> Unit,
    )

    fun show(
        alias: String,
        options: InterstitialShowOptions = InterstitialShowOptions(),
    ): Boolean

    fun hide(alias: String) = Unit
    fun destroy(alias: String)
    fun isReady(alias: String): Boolean
}
