package com.hdc.adsmultiplatform.platform.log

import com.hdc.adsmultiplatform.platform.build.AdsSdkVersion
import com.hdc.adsmultiplatform.platform.build.DevelopmentBuild
import kotlin.concurrent.Volatile

/**
 * The library's log: Logcat with the tag `AdsMultiplatform` on Android, the unified log on iOS. Warnings always go
 * out; debug messages only in a development build ([DevelopmentBuild]), unless the app picked a [level].
 */
internal object AdsLog {
    const val Off = 0
    const val Warn = 1
    const val Debug = 2

    /** The level the app picked ([Off], [Warn] or [Debug]); null keeps the default of the build. */
    @Volatile
    var level: Int? = null

    /** Whether [debug] writes anything; check it before building a costly message. */
    val isDebugEnabled: Boolean
        get() = threshold() >= Debug

    @Volatile
    private var versionLogged = false

    fun debug(message: String) {
        if (isDebugEnabled) {
            write(isWarning = false, message = message)
        }
    }

    fun warn(message: String) {
        if (threshold() >= Warn) {
            write(isWarning = true, message = message)
        }
    }

    // The first line says which version of the library the app runs.
    private fun write(isWarning: Boolean, message: String) {
        if (!versionLogged) {
            versionLogged = true
            writeAdsLog(isWarning = false, message = "AdsMultiplatform $AdsSdkVersion")
        }
        writeAdsLog(isWarning = isWarning, message = message)
    }

    // Debug until a build is known to be a release one: Android learns it from the first context the library sees.
    fun threshold(): Int = level ?: if (DevelopmentBuild.isDevelopment == false) Warn else Debug
}

/** Writes one line to the platform log. */
internal expect fun writeAdsLog(isWarning: Boolean, message: String)
