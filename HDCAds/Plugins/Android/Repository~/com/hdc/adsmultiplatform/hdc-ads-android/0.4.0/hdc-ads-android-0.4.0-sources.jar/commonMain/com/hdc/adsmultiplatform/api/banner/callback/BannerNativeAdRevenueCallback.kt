package com.hdc.adsmultiplatform.api.banner.callback

import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdInfo
import com.hdc.adsmultiplatform.api.common.model.NativeAdPaidInfo

/**
 * Impressions and paid impressions of the banner native ads of an alias, for revenue reporting. It is apart from
 * [BannerNativeAdCallback] so code that implements that callback keeps working: on iOS every method of an exported
 * callback is required.
 */
interface BannerNativeAdRevenueCallback {
    fun onImpression(ad: BannerNativeAdInfo) = Unit

    fun onPaidImpression(ad: BannerNativeAdInfo, paidInfo: NativeAdPaidInfo) = Unit
}
