package com.hdc.adsmultiplatform.platform.android.window

internal data class AndroidSystemUiSnapshot(
    val systemUiVisibility: Int,
    val statusBarColor: Int,
    val navigationBarColor: Int,
)
