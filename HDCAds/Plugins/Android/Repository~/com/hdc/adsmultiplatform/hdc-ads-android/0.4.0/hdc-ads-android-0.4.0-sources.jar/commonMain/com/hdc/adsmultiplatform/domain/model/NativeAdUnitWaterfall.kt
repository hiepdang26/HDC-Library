package com.hdc.adsmultiplatform.domain.model

import com.hdc.adsmultiplatform.domain.parser.splitListEntries

internal class NativeAdUnitWaterfall private constructor(
    val ids: List<String>,
) {
    companion object {
        fun fromCsv(raw: String): NativeAdUnitWaterfall =
            fromList(raw.splitListEntries())

        fun fromList(raw: List<String>): NativeAdUnitWaterfall =
            NativeAdUnitWaterfall(raw.map { it.trim() }.filter { it.isNotEmpty() })
    }

    fun withFallback(fallbackAdUnitId: String): NativeAdUnitWaterfall =
        if (ids.isEmpty()) {
            fromList(listOf(fallbackAdUnitId))
        } else {
            this
        }
}
