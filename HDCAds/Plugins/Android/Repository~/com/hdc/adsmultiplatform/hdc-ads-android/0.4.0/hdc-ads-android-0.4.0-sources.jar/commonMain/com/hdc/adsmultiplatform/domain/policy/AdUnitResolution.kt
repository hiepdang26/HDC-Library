package com.hdc.adsmultiplatform.domain.policy

/** What a load reports when no ad unit is configured and the build is a release one. */
internal const val NoAdUnitConfiguredMessage = "No ad unit id configured"

/**
 * The ad units to request for [adUnitIds], blank ones dropped. When none is left, a development build gets the
 * network's [testAdUnitId] and a release build an empty list, for which the load fails with
 * [NoAdUnitConfiguredMessage] instead of showing test ads.
 */
internal fun resolveAdUnitIds(
    adUnitIds: List<String>,
    testAdUnitId: String,
    isDevelopment: Boolean,
): List<String> {
    val configured = adUnitIds.map { it.trim() }.filter { it.isNotEmpty() }
    return configured.ifEmpty { if (isDevelopment) listOf(testAdUnitId) else emptyList() }
}
