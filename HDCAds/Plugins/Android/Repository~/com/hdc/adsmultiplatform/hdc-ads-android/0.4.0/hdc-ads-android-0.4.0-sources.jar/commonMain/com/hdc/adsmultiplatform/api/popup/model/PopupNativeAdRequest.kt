package com.hdc.adsmultiplatform.api.popup.model

import com.hdc.adsmultiplatform.api.popup.defaults.DefaultPopupNativeAdInstanceId

data class PopupNativeAdRequest(
    val instanceId: String = DefaultPopupNativeAdInstanceId,
    val adUnitIds: List<String>,
)
