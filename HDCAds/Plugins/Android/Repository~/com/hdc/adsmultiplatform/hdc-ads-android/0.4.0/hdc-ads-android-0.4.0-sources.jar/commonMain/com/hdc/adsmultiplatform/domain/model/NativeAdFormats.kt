package com.hdc.adsmultiplatform.domain.model

internal object NativeAdFormats {
    val Fullscreen = NativeAdFormat("fullscreen")
    val Banner = NativeAdFormat("banner")
    val Popup = NativeAdFormat("popup")
}
