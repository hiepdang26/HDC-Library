@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.common.viewmodel.port

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/**
 * What the ads a loader loaded report once they are up. The Compose banner and popup loaders offer it apart from
 * their own interface, which iOS exports with every method required.
 */
@AdsConsoleSupportApi
@HiddenFromObjC
fun interface AdRuntimeEventFeed {
    /** What the ad loaded for [instanceId] reports goes to [listener] until the instance is destroyed. */
    fun listen(instanceId: String, listener: (NativeAdEvent) -> Unit)
}
