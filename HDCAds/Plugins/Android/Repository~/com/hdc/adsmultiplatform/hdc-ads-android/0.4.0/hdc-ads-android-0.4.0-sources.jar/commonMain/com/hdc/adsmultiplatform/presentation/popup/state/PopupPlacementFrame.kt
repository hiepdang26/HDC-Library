package com.hdc.adsmultiplatform.presentation.popup.state

/** Where a popup sits in its viewport, in dp (points on iOS), from the top-left corner. */
internal data class PopupPlacementFrame(
    val x: Double,
    val y: Double,
    val width: Double,
    val height: Double,
    val viewportWidth: Double,
    val viewportHeight: Double,
)
