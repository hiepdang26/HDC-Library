package com.hdc.adsmultiplatform.data.source

import android.content.Context
import com.hdc.adsmultiplatform.data.model.LoadedNativeAdInfo
import com.hdc.adsmultiplatform.domain.defaults.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdFormat
import com.hdc.adsmultiplatform.domain.model.NativeAdFormats
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.domain.repository.FullscreenNativeAdRepository

/** Loads native ads per format and instance, and keeps the loaded one until it is shown, cleared or destroyed. */
internal interface AndroidNativeAdSource : FullscreenNativeAdRepository<Context> {
    /**
     * Loads [adUnitIds] in order until one fills. [retryOnFailure] retries the whole waterfall in the background
     * after it fails; a host that decides itself when to load (Unity) turns it off.
     */
    fun loadWithResult(
        format: NativeAdFormat,
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        retryOnFailure: Boolean,
        callback: (NativeAdLoadResult) -> Unit,
    )

    fun hasLoadedAd(format: NativeAdFormat, instanceId: String): Boolean

    fun loadedAdUnitId(format: NativeAdFormat, instanceId: String): String?

    fun loadedAdInfo(format: NativeAdFormat, instanceId: String): LoadedNativeAdInfo?

    /** Ad unit ids the latest fullscreen request for [instanceId] was made with. */
    override fun requestedAdUnitIds(instanceId: String): List<String>

    /** A fullscreen request for [instanceId] is waiting for its result. */
    override fun isLoading(instanceId: String): Boolean

    /** Milliseconds since the loaded fullscreen ad of [instanceId] arrived, or null without one. */
    fun loadedAdAgeMillis(instanceId: String): Long?

    fun clearLoaded(format: NativeAdFormat, instanceId: String)

    fun destroy(format: NativeAdFormat, instanceId: String)

    /** What the ad of [format] and [instanceId] reports once it is up goes to [listener]; null stops it. */
    fun setEventListener(format: NativeAdFormat, instanceId: String, listener: ((NativeAdEvent) -> Unit)?)

    fun load(context: Context, adUnitId: String, callback: (NativeAdState) -> Unit) {
        load(DefaultNativeAdInstanceId, context, listOf(adUnitId), callback)
    }

    fun loadWithResult(
        context: Context,
        adUnitId: String,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        loadWithResult(DefaultNativeAdInstanceId, context, listOf(adUnitId), callback)
    }

    fun load(
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdState) -> Unit,
    ) {
        loadWithResult(NativeAdFormats.Fullscreen, instanceId, context, adUnitIds) { result ->
            callback(result.state)
        }
    }

    fun loadWithResult(
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        loadWithResult(NativeAdFormats.Fullscreen, instanceId, context, adUnitIds, callback)
    }

    fun load(
        format: NativeAdFormat,
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdState) -> Unit,
    ) {
        loadWithResult(format, instanceId, context, adUnitIds) { result ->
            callback(result.state)
        }
    }

    fun loadWithResult(
        format: NativeAdFormat,
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        loadWithResult(format, instanceId, context, adUnitIds, retryOnFailure = format == NativeAdFormats.Fullscreen, callback = callback)
    }

    override fun hasLoadedAd(instanceId: String): Boolean =
        hasLoadedAd(NativeAdFormats.Fullscreen, instanceId)

    override fun loadedAdUnitId(instanceId: String): String? =
        loadedAdUnitId(NativeAdFormats.Fullscreen, instanceId)

    override fun clearLoaded(instanceId: String) {
        clearLoaded(NativeAdFormats.Fullscreen, instanceId)
    }

    override fun destroy(instanceId: String) {
        destroy(NativeAdFormats.Fullscreen, instanceId)
    }

    override fun loadFullscreen(
        host: Context,
        instanceId: String,
        adUnitIds: List<String>,
        retryOnFailure: Boolean,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        loadWithResult(NativeAdFormats.Fullscreen, instanceId, host, adUnitIds, retryOnFailure, callback)
    }

    override fun loadedAdAgeSeconds(instanceId: String): Double? =
        loadedAdAgeMillis(instanceId)?.let { it / 1_000.0 }
}
