package com.hdc.adsmultiplatform.unity.event

import com.hdc.adsmultiplatform.api.interstitial.callback.InterstitialAdCallback
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdInfo

/**
 * Forwards one interstitial instance's lifecycle callbacks to Unity. Impression, click and paid events come
 * from the shared tracking stream instead (HdcTracking), like every other format's.
 */
internal class HdcInterstitialEvents(private val id: String) : InterstitialAdCallback {
    override fun onInterstitialLoaded(ad: InterstitialAdInfo) = emit(HdcEventType.Loaded, ad.fields())

    override fun onInterstitialDisplayed(ad: InterstitialAdInfo) = emit(HdcEventType.Shown, ad.fields())

    override fun onInterstitialClosed(ad: InterstitialAdInfo) = emit(HdcEventType.Closed, ad.fields())

    override fun onInterstitialFailedToLoad(adUnit: String, errorCode: Int, error: String) =
        emit(HdcEventType.LoadFailed, mapOf("adUnitId" to adUnit) + HdcEvents.error(errorCode, error))

    override fun onInterstitialFailedToShow(adUnit: String, errorCode: Int, error: String) =
        emit(HdcEventType.ShowFailed, mapOf("adUnitId" to adUnit) + HdcEvents.error(errorCode, error))

    private fun emit(type: String, fields: Map<String, Any?>) {
        HdcEvents.emit(id = id, format = HdcFormat.Interstitial, type = type, fields = fields)
    }

    private fun InterstitialAdInfo.fields(): Map<String, Any?> =
        mapOf(
            "adUnitId" to adUnitId,
            "adapter" to mediationAdapter,
            "adSource" to adSource.orEmpty(),
            "responseId" to responseId,
        )
}
