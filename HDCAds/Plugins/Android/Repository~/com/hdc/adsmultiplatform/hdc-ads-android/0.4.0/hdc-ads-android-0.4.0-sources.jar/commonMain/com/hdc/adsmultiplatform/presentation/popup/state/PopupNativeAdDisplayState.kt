@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.popup.state

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
enum class PopupNativeAdDisplayState {
    NotLoaded,
    Loading,
    Loaded,
    Displayable,
    Showing,
    Closed,
    Failed,
    Destroyed,
}
