@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.domain.model

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/** The value of a paid impression. */
@AdsConsoleSupportApi
@HiddenFromObjC
data class AdPaidValue(
    val valueMicros: Long,
    val currencyCode: String,
    /** How exact the value is, as the network says: 0 unknown, 1 estimated, 2 publisher provided, 3 precise. */
    val precision: Int = 0,
)
