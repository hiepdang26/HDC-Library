package com.hdc.adsmultiplatform.presentation.admob.fullscreen.touch

import android.view.MotionEvent
import android.view.View

internal fun dispatchTouchBetweenViews(event: MotionEvent, source: View, target: View): Boolean {
    val sourceLocation = IntArray(2)
    val targetLocation = IntArray(2)
    source.getLocationOnScreen(sourceLocation)
    target.getLocationOnScreen(targetLocation)
    val copy = MotionEvent.obtain(event)
    copy.offsetLocation(
        (sourceLocation[0] - targetLocation[0]).toFloat(),
        (sourceLocation[1] - targetLocation[1]).toFloat(),
    )
    return try {
        target.dispatchTouchEvent(copy)
    } finally {
        copy.recycle()
    }
}

internal fun View.containsTouchFrom(source: View, event: MotionEvent): Boolean {
    val sourceLocation = IntArray(2)
    val targetLocation = IntArray(2)
    source.getLocationOnScreen(sourceLocation)
    getLocationOnScreen(targetLocation)
    val x = sourceLocation[0] + event.x
    val y = sourceLocation[1] + event.y
    return x >= targetLocation[0] &&
        x < targetLocation[0] + width &&
        y >= targetLocation[1] &&
        y < targetLocation[1] + height
}
