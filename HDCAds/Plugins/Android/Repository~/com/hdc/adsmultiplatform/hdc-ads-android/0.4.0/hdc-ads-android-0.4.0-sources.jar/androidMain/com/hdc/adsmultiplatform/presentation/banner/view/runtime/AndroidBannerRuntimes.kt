package com.hdc.adsmultiplatform.presentation.banner.view.runtime

import android.app.Activity
import com.hdc.adsmultiplatform.api.banner.callback.BannerNativeAdCallback
import com.hdc.adsmultiplatform.api.banner.callback.BannerNativeAdRevenueCallback
import com.hdc.adsmultiplatform.api.banner.defaults.DefaultBannerNativeAdInstanceId
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdConfig
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.renderer.AndroidNativeAdViewHosts

/**
 * The native banners Unity shows without Compose, along the bottom of an activity's content, by alias: the Android
 * side of the iOS banner runtimes. Call on the main thread.
 */
internal class AndroidBannerRuntimes(
    private val nativeAds: AndroidNativeAdSource,
    private val hosts: AndroidNativeAdViewHosts,
) {
    private val runtimes = mutableMapOf<String, AndroidBannerRuntime>()

    fun create(alias: String, config: BannerNativeAdConfig) {
        runtime(alias).configure(config)
    }

    fun setCallback(alias: String, callback: (NativeAdState) -> Unit) {
        runtime(alias).stateCallback = callback
    }

    /** What the banners of [alias] report: loads, failures and clicks to [callback], impressions and paid values to [revenueCallback]. */
    fun setAdCallbacks(alias: String, callback: BannerNativeAdCallback?, revenueCallback: BannerNativeAdRevenueCallback?) {
        runtime(alias).callbacks.apply {
            this.callback = callback
            this.revenueCallback = revenueCallback
        }
    }

    fun load(alias: String, activity: Activity) {
        runtime(alias).apply {
            this.activity = activity
            controller.load()
        }
    }

    fun show(alias: String, activity: Activity) {
        runtime(alias).apply {
            this.activity = activity
            ensurePresented()
            controller.show()
        }
    }

    fun expand(alias: String, enableClick: Boolean): Boolean =
        runtimes[key(alias)]?.controller?.expand(enableClick) == true

    fun collapse(alias: String) {
        runtimes[key(alias)]?.controller?.collapse()
    }

    fun hide(alias: String) {
        runtimes[key(alias)]?.controller?.hide()
    }

    fun destroy(alias: String) {
        runtimes.remove(key(alias))?.destroy()
    }

    private fun runtime(alias: String): AndroidBannerRuntime =
        runtimes.getOrPut(key(alias)) { AndroidBannerRuntime(key(alias), nativeAds, hosts) }

    private fun key(alias: String): String = alias.ifBlank { DefaultBannerNativeAdInstanceId }
}
