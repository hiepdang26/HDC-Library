package com.hdc.adsmultiplatform.unity.command

import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.port.HdcMetaTestHost
import com.hdc.adsmultiplatform.unity.thread.hdcQueryOnMain
import com.hdc.adsmultiplatform.unity.thread.hdcRunOnMainCatching

/**
 * `meta.*` commands for Meta Audience Network test ads. Call `enableTestMode` before ads load: ads loaded
 * earlier are not test ads. Meta keeps test devices across launches until `disableTestMode`.
 *
 * - `enableTestMode` `{deviceHashes?:[…], testAdType?}` returns whether it is on; `disableTestMode` `{}`.
 * - `isTestMode` returns a boolean; `deviceHash` returns this device's hash.
 */
internal object HdcMetaCommands {
    private val host: HdcMetaTestHost by lazy { adsGet() }

    fun enableTestMode(args: HdcArgs): Boolean {
        val deviceHashes = args.stringList("deviceHashes")
        val testAdType = args.int("testAdType", 0)
        return hdcQueryOnMain(fallback = false) { host.enable(deviceHashes, testAdType) }
    }

    fun disableTestMode(): Boolean {
        hdcRunOnMainCatching(onError = {}) { host.disable() }
        return true
    }

    fun isTestMode(): Boolean = hdcQueryOnMain(fallback = false) { host.isEnabled() }

    fun deviceHash(): String = hdcQueryOnMain(fallback = "") { host.deviceHash() }
}
