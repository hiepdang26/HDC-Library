package com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy

import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.presentation.popup.layouts.registry.PopupNativeAdLayoutCatalog
import com.hdc.adsmultiplatform.presentation.popup.state.PopupPlacementFrame

/**
 * Where the popup goes in a [viewportWidth] x [viewportHeight] viewport (dp, or points on iOS). A position with both
 * values in 0..1 is a normalized center (y measured from the bottom); anything else is the top-left corner. The size
 * keeps the layout minimums and is clamped, like the position, to the viewport. Null when the viewport or the config
 * has no usable size.
 */
internal fun PopupNativeAdConfig.placementFrame(viewportWidth: Double, viewportHeight: Double): PopupPlacementFrame? {
    if (!viewportWidth.isFinite() || !viewportHeight.isFinite() || viewportWidth <= 0.0 || viewportHeight <= 0.0) {
        return null
    }
    if (!listOf(xDp, yDp, adWidthDp, adHeightDp).all { it.isFinite() }) {
        return null
    }

    val minWidth = PopupNativeAdLayoutCatalog.MinWidthDp.toDouble().coerceAtMost(viewportWidth)
    val minHeight = minLayoutHeightDp().toDouble().coerceAtMost(viewportHeight)
    val width = adWidthDp.toDouble().coerceAtLeast(minWidth).coerceAtMost(viewportWidth)
    val height = adHeightDp.toDouble().coerceAtLeast(minHeight).coerceAtMost(viewportHeight)
    val requestedX = xDp.toDouble()
    val requestedY = yDp.toDouble()
    val isNormalizedCenter = requestedX in 0.0..1.0 && requestedY in 0.0..1.0
    val rawX = if (isNormalizedCenter) requestedX * viewportWidth - width * 0.5 else requestedX
    val rawY = if (isNormalizedCenter) (1.0 - requestedY) * viewportHeight - height * 0.5 else requestedY
    return PopupPlacementFrame(
        x = rawX.coerceIn(0.0, (viewportWidth - width).coerceAtLeast(0.0)),
        y = rawY.coerceIn(0.0, (viewportHeight - height).coerceAtLeast(0.0)),
        width = width,
        height = height,
        viewportWidth = viewportWidth,
        viewportHeight = viewportHeight,
    )
}
