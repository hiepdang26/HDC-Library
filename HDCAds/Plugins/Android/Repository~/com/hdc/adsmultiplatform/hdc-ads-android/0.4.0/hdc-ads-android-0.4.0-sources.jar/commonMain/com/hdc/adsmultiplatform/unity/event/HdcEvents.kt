package com.hdc.adsmultiplatform.unity.event

import com.hdc.adsmultiplatform.unity.bridge.HdcUnityBridge
import com.hdc.adsmultiplatform.unity.json.HdcJson

/** Sends one event to Unity: `{"id":…,"format":…,"type":…}` plus [fields]. */
internal object HdcEvents {
    fun emit(
        id: String,
        format: String,
        type: String,
        fields: Map<String, Any?> = emptyMap(),
    ) {
        val event = LinkedHashMap<String, Any?>(fields.size + 3)
        event["id"] = id
        event["format"] = format
        event["type"] = type
        event.putAll(fields)
        HdcUnityBridge.emit(HdcJson.write(event))
    }

    fun error(code: Int, message: String): Map<String, Any?> =
        mapOf("code" to code, "message" to message)
}
