package com.hdc.adsmultiplatform.unity.event

import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port.FullscreenNativeAdEvents
import com.hdc.adsmultiplatform.unity.callback.FullscreenNativeAdUnityCallbacks

private const val UnityCallbackGameObject = "AdsMultiplatformCallbacks"

private const val UnityCallbackMethod = "OnNativeAdEvent"

/** Reports the fullscreen flow to Unity: `UnitySendMessage` for state changes, the C# proxy for the rest. */
internal class UnityFullscreenNativeAdEvents(
    private val callbacks: FullscreenNativeAdUnityCallbacks,
) : FullscreenNativeAdEvents {
    /** False once the HDCLib bridge starts: its games hear states through the bridge and have no callback object. */
    @Volatile
    var sendsStateMessages = true

    override fun onStateChanged(instanceId: String, state: NativeAdState) {
        if (!sendsStateMessages) {
            return
        }
        try {
            val unityPlayer = Class.forName("com.unity3d.player.UnityPlayer")
            val unitySendMessage = unityPlayer.getMethod(
                "UnitySendMessage",
                String::class.java,
                String::class.java,
                String::class.java,
            )
            unitySendMessage.invoke(null, UnityCallbackGameObject, UnityCallbackMethod, "$instanceId|${state.name}")
        } catch (_: Throwable) {
            // Unity classes are not available when this module runs outside a Unity player.
        }
    }

    override fun onLoadResult(instanceId: String, result: NativeAdLoadResult) {
        callbacks.onLoadResult(instanceId, result)
    }

    override fun onDisplayed(instanceId: String) {
        callbacks.onDisplayed(instanceId)
    }

    override fun onClosed(instanceId: String) {
        callbacks.onClosed(instanceId)
    }
}
