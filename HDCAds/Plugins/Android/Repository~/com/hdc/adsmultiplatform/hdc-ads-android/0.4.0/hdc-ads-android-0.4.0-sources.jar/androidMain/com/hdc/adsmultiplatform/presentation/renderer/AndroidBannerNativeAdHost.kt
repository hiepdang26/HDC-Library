package com.hdc.adsmultiplatform.presentation.renderer

import android.view.View
import com.hdc.adsmultiplatform.domain.model.NativeAdState

/** A banner ad Unity shows without Compose: the banner runtime places [view] and passes it each banner state. */
internal interface AndroidBannerNativeAdHost {
    val view: View

    fun render(
        instanceId: String,
        fallbackAdUnitId: String,
        layoutName: String,
        isExpanded: Boolean,
        showInternalExpandedClose: Boolean,
        enableExpandedCloseOverlay: Boolean,
        collapseCountdownSecondsRemaining: Int,
        collapseCountdownProgress: Float,
        showCollapsedClose: Boolean,
        onStateChanged: (NativeAdState) -> Unit,
        onCollapsedCloseClick: () -> Unit,
        onCollapseClick: () -> Unit,
    )

    fun release()
}
