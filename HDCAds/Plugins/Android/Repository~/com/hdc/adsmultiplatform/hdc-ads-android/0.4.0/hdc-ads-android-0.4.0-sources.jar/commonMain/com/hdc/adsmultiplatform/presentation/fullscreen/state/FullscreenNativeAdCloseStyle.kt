package com.hdc.adsmultiplatform.presentation.fullscreen.state

enum class FullscreenNativeAdCloseStyle {
    STANDARD,
    CLS,
    NAV,
    PGRS,
    PGRS_CLS,
    LOOP,
}
