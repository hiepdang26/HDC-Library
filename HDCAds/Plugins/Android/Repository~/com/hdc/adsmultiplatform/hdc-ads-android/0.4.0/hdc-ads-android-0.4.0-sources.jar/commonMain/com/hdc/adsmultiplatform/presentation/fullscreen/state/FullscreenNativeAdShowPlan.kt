package com.hdc.adsmultiplatform.presentation.fullscreen.state

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeAdShowOptions

/** The screen a show of a fullscreen native ad builds. [options] are the show options after the reference library's mode routing. */
internal sealed interface FullscreenNativeAdShowPlan {
    val options: FullscreenNativeAdShowOptions

    /** The ad is gone; the failure was already reported to the registry. */
    data class NoLoadedAd(override val options: FullscreenNativeAdShowOptions) : FullscreenNativeAdShowPlan

    /** [screen] is what the overlay draws, [adUnitId] the ad unit that filled. */
    data class Ready(
        override val options: FullscreenNativeAdShowOptions,
        val screen: NativeAdShowOptions,
        val adUnitId: String,
    ) : FullscreenNativeAdShowPlan
}
