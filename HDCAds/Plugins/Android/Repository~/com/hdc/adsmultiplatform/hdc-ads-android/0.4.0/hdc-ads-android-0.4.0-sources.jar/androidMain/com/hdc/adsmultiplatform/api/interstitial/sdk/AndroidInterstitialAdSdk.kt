package com.hdc.adsmultiplatform.api.interstitial.sdk

import android.app.Activity
import com.hdc.adsmultiplatform.api.interstitial.callback.InterstitialAdCallback
import com.hdc.adsmultiplatform.api.interstitial.defaults.DefaultInterstitialAdInstanceId
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.api.interstitial.registry.InterstitialAdRegistry
import com.hdc.adsmultiplatform.data.source.AndroidInterstitialAdSource
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.parser.ListSeparatorsWithCarriageReturn
import com.hdc.adsmultiplatform.domain.parser.splitListEntries

object AndroidInterstitialAdSdk {
    @JvmStatic
    @JvmOverloads
    fun create(
        alias: String = DefaultInterstitialAdInstanceId,
        adUnitIdsCsv: String = UnconfiguredAdUnitId,
        preloadBufferSize: Int = 1,
        autoReload: Boolean = true,
    ) {
        InterstitialAdRegistry.create(
            alias = alias,
            config = InterstitialAdConfig(
                ids = parseInterstitialCsv(adUnitIdsCsv),
                autoReload = autoReload,
                preloadBufferSize = preloadBufferSize,
            ),
        )
        adsGet<AndroidInterstitialAdSource>().configure(alias, InterstitialAdRegistry.configFor(alias))
    }

    @JvmStatic
    fun setCallback(alias: String, callback: InterstitialAdCallback?) {
        InterstitialAdRegistry.setCallback(alias, callback)
    }

    @JvmStatic
    @JvmOverloads
    fun load(activity: Activity, alias: String = DefaultInterstitialAdInstanceId) {
        val config = InterstitialAdRegistry.configFor(alias)
        adsGet<AndroidInterstitialAdSource>().loadWithResult(activity, alias, config.preloadBufferSize) {}
    }

    @JvmStatic
    fun load(activity: Activity, alias: String, bufferSize: Int) {
        adsGet<AndroidInterstitialAdSource>().loadWithResult(activity, alias, bufferSize) {}
    }

    @JvmStatic
    @JvmOverloads
    fun show(
        activity: Activity,
        alias: String = DefaultInterstitialAdInstanceId,
        options: InterstitialShowOptions = InterstitialShowOptions(),
    ): Boolean =
        adsGet<AndroidInterstitialAdSource>().show(activity, alias, options)

    @JvmStatic
    @JvmOverloads
    fun destroy(alias: String = DefaultInterstitialAdInstanceId) {
        adsGet<AndroidInterstitialAdSource>().destroy(alias)
        InterstitialAdRegistry.destroy(alias)
    }

    @JvmStatic
    @JvmOverloads
    fun isReady(alias: String = DefaultInterstitialAdInstanceId): Boolean =
        adsGet<AndroidInterstitialAdSource>().isReady(alias)
}

private fun parseInterstitialCsv(value: String): List<String> =
    value.splitListEntries(ListSeparatorsWithCarriageReturn)
