@file:OptIn(ExperimentalObjCName::class)

package com.hdc.adsmultiplatform.unity.bridge

import com.hdc.adsmultiplatform.unity.callback.HdcUnityListener
import com.hdc.adsmultiplatform.unity.command.HdcCommands
import com.hdc.adsmultiplatform.unity.event.HdcTracking
import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.json.HdcJson
import com.hdc.adsmultiplatform.unity.log.HdcLog
import kotlin.concurrent.Volatile
import kotlin.experimental.ExperimentalObjCName
import kotlin.jvm.JvmStatic
import kotlin.native.ObjCName

/**
 * The single entry point for Unity: [call] runs a command and the listener receives ad events.
 *
 * A command is `"<format>.<action>"`, for example `"interstitial.load"`, with a JSON object of arguments.
 * The result is a JSON object: `{"ok":true,"value":…}`, or `{"ok":false,"error":"…"}` when it fails.
 * Commands can be called from any thread; ad work runs on the main thread, and so do events.
 */
@ObjCName("HDCUnityBridge", exact = true)
object HdcUnityBridge {
    @Volatile
    private var listener: HdcUnityListener? = null

    init {
        HdcTracking.start()
    }

    @JvmStatic
    fun setListener(listener: HdcUnityListener?) {
        this.listener = listener
    }

    /** [setListener] for Objective-C callers, which pass a block. */
    fun setEventHandler(handler: ((String) -> Unit)?) {
        listener = handler?.let { HdcUnityListener(it) }
    }

    @JvmStatic
    fun call(method: String, argsJson: String): String =
        try {
            val value = HdcCommands.execute(method.trim(), HdcArgs.parse(argsJson))
            HdcJson.write(mapOf("ok" to true, "value" to value))
        } catch (error: Throwable) {
            HdcLog.warn("$method failed: ${error.message}")
            HdcJson.write(mapOf("ok" to false, "error" to (error.message ?: error::class.simpleName.orEmpty())))
        }

    internal fun emit(eventJson: String) {
        HdcLog.debug("event $eventJson")
        listener?.onEvent(eventJson)
    }
}
