package com.hdc.adsmultiplatform.unity.host

import com.hdc.adsmultiplatform.data.source.AndroidMobileAdsStarter
import com.hdc.adsmultiplatform.unity.event.UnityFullscreenNativeAdEvents
import com.hdc.adsmultiplatform.unity.gameplay.HdcUnityActivity
import com.hdc.adsmultiplatform.unity.port.HdcSdkHost
import com.hdc.adsmultiplatform.unity.thread.hdcRunOnMain
import com.hdc.adsmultiplatform.unity.thread.hdcWatchUnityPause

/**
 * Starts the ads SDK for the bridge, with the Unity activity's application context. The fullscreen states then reach
 * Unity through the bridge only: HDCLib games have no `AdsMultiplatformCallbacks` object for `UnitySendMessage`.
 */
internal class AndroidHdcSdkHost(
    private val starter: AndroidMobileAdsStarter,
    private val fullscreenEvents: UnityFullscreenNativeAdEvents,
) : HdcSdkHost {
    override fun initialize(onComplete: () -> Unit) {
        fullscreenEvents.sendsStateMessages = false
        hdcWatchUnityPause()
        val context = HdcUnityActivity.require().applicationContext
        starter.start(context) { hdcRunOnMain(onComplete) }
    }
}
