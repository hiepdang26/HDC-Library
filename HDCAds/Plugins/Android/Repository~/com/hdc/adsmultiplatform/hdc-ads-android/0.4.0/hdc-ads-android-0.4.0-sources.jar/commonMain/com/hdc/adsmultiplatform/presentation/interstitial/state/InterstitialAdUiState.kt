@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.interstitial.state

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
data class InterstitialAdUiState(
    val state: NativeAdState = NativeAdState.Idle,
    val activeAdUnitId: String? = null,
    val responseId: String = "",
    val mediationAdapter: String = "",
    val adSource: String? = null,
    val loadedAdUnitIds: Set<String> = emptySet(),
    val loadingAdUnitIds: Set<String> = emptySet(),
    val preloadBufferSize: Int = 1,
    val isShowing: Boolean = false,
)
