package com.hdc.adsmultiplatform.api.fullscreen.model

data class FullscreenNativeAdInfo(
    val alias: String,
    val adUnitId: String,
    val layoutName: String = "",
    /** The ad source (mediation network) that filled the ad, when the network tells. */
    val adSourceId: String = "",
    val adSourceName: String = "",
)
