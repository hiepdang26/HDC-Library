package com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port

import android.app.Activity
import android.view.View
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdShowPlan

/** The view a fullscreen show puts over the activity's content: Compose in the library, plain views in the Unity library. */
internal interface FullscreenNativeAdOverlays {
    fun create(activity: Activity, plan: FullscreenNativeAdShowPlan.Ready, onClose: () -> Unit): View

    /** Called after [view] left the activity. */
    fun release(view: View)
}
