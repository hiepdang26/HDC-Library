package com.hdc.adsmultiplatform.api.interstitial.defaults

const val DefaultInterstitialAdInstanceId = "interstitial"
