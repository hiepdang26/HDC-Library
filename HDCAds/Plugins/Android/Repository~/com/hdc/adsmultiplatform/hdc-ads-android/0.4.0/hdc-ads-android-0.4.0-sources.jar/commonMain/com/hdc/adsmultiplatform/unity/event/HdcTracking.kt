package com.hdc.adsmultiplatform.unity.event

import com.hdc.adsmultiplatform.api.event.center.AdTrackingEvents
import com.hdc.adsmultiplatform.api.event.model.AdTrackingEventNames

/** Forwards impression, click and paid events of every format to Unity. */
internal object HdcTracking {
    fun start() {
        AdTrackingEvents.listener = { event ->
            val fields = LinkedHashMap<String, Any?>()
            fields["adUnitId"] = event.adUnitId
            fields["adapter"] = event.mediationAdapter
            fields["adSource"] = event.adSourceName
            fields["responseId"] = event.responseId
            if (event.name == AdTrackingEventNames.Paid) {
                fields["valueMicros"] = event.valueMicros
                fields["currency"] = event.currencyCode
                fields["precision"] = event.precision
            }
            HdcEvents.emit(id = event.instanceId, format = event.format, type = event.name, fields = fields)
        }
    }
}
