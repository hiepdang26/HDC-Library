package com.hdc.adsmultiplatform.api.popup.model

/** The popup layout [layoutName] for ads filled by one of [adSourceIds] (AdMob ad source ids). */
data class PopupNativeAdSourceLayout(
    val adSourceIds: List<String>,
    val layoutName: String,
)
