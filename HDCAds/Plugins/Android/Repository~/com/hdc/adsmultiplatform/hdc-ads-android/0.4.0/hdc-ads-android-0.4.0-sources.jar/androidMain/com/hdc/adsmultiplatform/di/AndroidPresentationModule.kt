package com.hdc.adsmultiplatform.di

import android.content.Context
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.presentation.banner.view.runtime.AndroidBannerRuntimes
import com.hdc.adsmultiplatform.presentation.fullscreen.state.interaction.FullscreenNativeAdInteractionRegistry
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.AndroidFullscreenNativeAdWindow
import com.hdc.adsmultiplatform.presentation.fullscreen.viewmodel.FullscreenNativeAdViewModel
import com.hdc.adsmultiplatform.presentation.popup.view.runtime.AndroidPopupRuntimes
import com.hdc.adsmultiplatform.unity.event.UnityFullscreenNativeAdEvents
import com.hdc.adsmultiplatform.unity.gameplay.UnityGameplayController
import org.koin.core.module.Module
import org.koin.dsl.module

/** What Unity drives: the fullscreen ViewModel and the window that puts the ads on screen, the banner and popup runtimes. */
internal val androidPresentationModule: Module = module {
    single { FullscreenNativeAdInteractionRegistry() }
    single { FullscreenNativeAdViewModel<Context>(ads = get<AndroidNativeAdSource>()) }
    single {
        AndroidFullscreenNativeAdWindow(
            viewModel = get(),
            events = get<UnityFullscreenNativeAdEvents>(),
            gameplay = UnityGameplayController,
            overlays = get(),
        )
    }
    single { AndroidBannerRuntimes(nativeAds = get(), hosts = get()) }
    single { AndroidPopupRuntimes(nativeAds = get(), hosts = get(), fullscreen = get()) }
}
