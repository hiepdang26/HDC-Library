package com.hdc.adsmultiplatform.api.log.sdk

import com.hdc.adsmultiplatform.api.log.model.AdsLogLevel
import com.hdc.adsmultiplatform.platform.log.AdsLog
import kotlin.jvm.JvmStatic

/**
 * How much the library logs. By default a development build (a debuggable Android app, an iOS app run from Xcode or
 * built with the debug framework) logs everything and a release build only warnings.
 */
object AdsLogging {
    /** Picks [level]; null goes back to the default of the build. */
    @JvmStatic
    fun setLevel(level: AdsLogLevel?) {
        AdsLog.level = when (level) {
            null -> null
            AdsLogLevel.Off -> AdsLog.Off
            AdsLogLevel.Warn -> AdsLog.Warn
            AdsLogLevel.Debug -> AdsLog.Debug
        }
    }

    /** For Unity: "off", "warn", "debug", or "" for the default of the build. False, and no change, for another name. */
    @JvmStatic
    fun setLevelName(name: String): Boolean {
        val level = when (name.trim().lowercase()) {
            "" -> null
            "off" -> AdsLogLevel.Off
            "warn" -> AdsLogLevel.Warn
            "debug" -> AdsLogLevel.Debug
            else -> return false
        }
        setLevel(level)
        return true
    }

    /** The level the library logs at now. */
    @JvmStatic
    fun currentLevel(): AdsLogLevel =
        when (AdsLog.threshold()) {
            AdsLog.Off -> AdsLogLevel.Off
            AdsLog.Warn -> AdsLogLevel.Warn
            else -> AdsLogLevel.Debug
        }
}
