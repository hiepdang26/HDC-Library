package com.hdc.adsmultiplatform.presentation.admob.fullscreen.model

import android.view.View

internal data class AdAssetClickTarget(
    val view: View,
    val clickable: Boolean,
)
