@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.popup.state

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.popup.layouts.registry.PopupNativeAdLayoutCatalog
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
data class PopupNativeAdUiState(
    val state: NativeAdState = NativeAdState.Idle,
    val displayState: PopupNativeAdDisplayState = PopupNativeAdDisplayState.NotLoaded,
    val isVisible: Boolean = false,
    val activeInstanceId: String? = null,
    val activeAdUnitId: String? = null,
    val activeAdSourceId: String = "",
    val activeAdSourceName: String = "",
    val layoutName: String = PopupNativeAdLayoutCatalog.Default,
    val enableCtrOverlay: Boolean = false,
    val closeSecondsRemaining: Int = 0,
    val canClose: Boolean = true,
)
