package com.hdc.adsmultiplatform.unity.host

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.domain.model.NativeAdFormats
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.AndroidFullscreenNativeAdWindow
import com.hdc.adsmultiplatform.unity.gameplay.HdcUnityActivity
import com.hdc.adsmultiplatform.unity.port.HdcFullscreenHost

/** Fullscreen native ads for the bridge, over the Unity activity through the fullscreen window. */
internal class AndroidHdcFullscreenHost(
    private val window: AndroidFullscreenNativeAdWindow,
    private val ads: AndroidNativeAdSource,
) : HdcFullscreenHost {
    override fun load(id: String, adUnitIds: List<String>, reloadAfterShow: Boolean) {
        window.load(
            activity = HdcUnityActivity.require(),
            instanceId = id,
            adUnitIdsCsv = adUnitIds.joinToString(","),
            enableReloadAfterShow = reloadAfterShow,
        )
    }

    override fun show(id: String, options: FullscreenNativeAdShowOptions): Boolean {
        // The window reports a missing ad as a failed load, which a show's caller would not hear as a failed show.
        if (!ads.hasLoadedAd(NativeAdFormats.Fullscreen, id)) {
            return false
        }
        window.show(
            activity = HdcUnityActivity.require(),
            instanceId = id,
            options = options,
            fallbackAdUnitId = "",
        )
        return true
    }

    override fun hide(id: String) {
        window.hide(HdcUnityActivity.require(), id)
    }

    override fun destroy(id: String) {
        HdcUnityActivity.current()?.let { window.hide(it, id) }
        window.destroy(id)
    }
}
