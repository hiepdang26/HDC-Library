package com.hdc.adsmultiplatform.presentation.admob.popup.model

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAdView

internal data class PopupNativeXmlBinding(
    val adView: NativeAdView,
    val mediaView: MediaView?,
    val iconView: ImageView?,
    val callToActionView: TextView?,
    val headlineView: TextView?,
    val bodyView: TextView?,
    val advertiserView: TextView?,
    val adChoicesView: AdChoicesView?,
    val demoImageView: ImageView?,
    val closeButtonView: View?,
    val closeTimerView: View?,
)
