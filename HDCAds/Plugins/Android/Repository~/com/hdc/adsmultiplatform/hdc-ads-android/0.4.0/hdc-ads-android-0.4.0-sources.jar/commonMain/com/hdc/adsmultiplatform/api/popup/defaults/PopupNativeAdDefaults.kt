package com.hdc.adsmultiplatform.api.popup.defaults

const val DefaultPopupNativeAdInstanceId = "popup_native_default"
