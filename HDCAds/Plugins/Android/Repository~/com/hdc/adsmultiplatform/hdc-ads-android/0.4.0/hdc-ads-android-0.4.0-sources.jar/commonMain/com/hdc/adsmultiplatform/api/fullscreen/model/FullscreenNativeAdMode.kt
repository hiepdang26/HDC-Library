package com.hdc.adsmultiplatform.api.fullscreen.model

import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog

enum class FullscreenNativeAdMode {
    SINGLE,
    TRANSPARENT,
    CTR,
    MULTIPLE,
    SEQUENCE,
    OVERLAY,
    OVERLAY_TRANSPARENT,
    OVERLAY_CTR,
    OVERLAY_CLS,
    OVERLAY_NAV,
    OVERLAY_PGRS,
    OVERLAY_PGRS_CLS,
    LOOP,
    ;

    val keepsDuplicateLayouts: Boolean
        get() = this == MULTIPLE || this == SEQUENCE

    val isProgressOverlay: Boolean
        get() = this == OVERLAY_PGRS || this == OVERLAY_PGRS_CLS

    val alwaysPausesGameplay: Boolean
        get() = when (this) {
            OVERLAY,
            OVERLAY_TRANSPARENT,
            OVERLAY_CLS,
            OVERLAY_NAV,
            OVERLAY_PGRS,
            OVERLAY_PGRS_CLS,
            LOOP,
            -> true

            else -> false
        }

    companion object {
        fun fromName(value: String?): FullscreenNativeAdMode {
            val normalized = value?.trim()?.uppercase().orEmpty()
            val alias = when (normalized) {
                "CLS" -> "OVERLAY_CLS"
                "NAV" -> "OVERLAY_NAV"
                "OVERLAY_PRGS" -> "OVERLAY_PGRS"
                "OVERLAY_PRGS_CLS" -> "OVERLAY_PGRS_CLS"
                else -> normalized
            }
            return entries.firstOrNull { it.name == alias } ?: SINGLE
        }
    }
}

internal fun FullscreenNativeAdMode.withLayoutInferredOverlay(layoutNames: List<String>): FullscreenNativeAdMode {
    if (keepsDuplicateLayouts) {
        return this
    }

    val normalized = layoutNames.map { FullscreenLayoutCatalog.normalize(it) }
    return when {
        normalized.any { it in FullscreenLayoutCatalog.AarLoopLayouts } ->
            FullscreenNativeAdMode.LOOP
        normalized.any { it in FullscreenLayoutCatalog.AarProgressClsLayouts } ->
            FullscreenNativeAdMode.OVERLAY_PGRS_CLS
        normalized.any { it in FullscreenLayoutCatalog.AarProgressLayouts } ->
            FullscreenNativeAdMode.OVERLAY_PGRS
        normalized.any { it in FullscreenLayoutCatalog.AarClsLayouts } ->
            FullscreenNativeAdMode.OVERLAY_CLS
        normalized.any { it in FullscreenLayoutCatalog.AarNavLayouts } ->
            FullscreenNativeAdMode.OVERLAY_NAV
        else -> this
    }
}
