package com.hdc.adsmultiplatform.presentation.admob.renderer

import android.content.Context
import com.google.android.gms.ads.nativead.NativeAd
import com.hdc.adsmultiplatform.domain.repository.LoadedNativeAds
import com.hdc.adsmultiplatform.presentation.admob.banner.host.AndroidBannerNativeXmlAdHost
import com.hdc.adsmultiplatform.presentation.admob.fullscreen.host.AndroidFullscreenNativeXmlAdHost
import com.hdc.adsmultiplatform.presentation.admob.popup.host.AndroidPopupNativeXmlAdHost
import com.hdc.adsmultiplatform.presentation.renderer.AndroidBannerNativeAdHost
import com.hdc.adsmultiplatform.presentation.renderer.AndroidFullscreenNativeAdHost
import com.hdc.adsmultiplatform.presentation.renderer.AndroidNativeAdViewHosts
import com.hdc.adsmultiplatform.presentation.renderer.AndroidPopupNativeAdHost

/** The AdMob views drawn from the XML designs, for the screens Unity shows without Compose. */
internal class AdMobAndroidViewHosts(
    private val ads: LoadedNativeAds<NativeAd>,
) : AndroidNativeAdViewHosts {
    override fun createFullscreenHost(context: Context): AndroidFullscreenNativeAdHost =
        AndroidFullscreenNativeXmlAdHost(context, ads)

    override fun createBannerHost(context: Context): AndroidBannerNativeAdHost =
        AndroidBannerNativeXmlAdHost(context, ads)

    override fun createPopupHost(context: Context): AndroidPopupNativeAdHost =
        AndroidPopupNativeXmlAdHost(context, ads)
}
