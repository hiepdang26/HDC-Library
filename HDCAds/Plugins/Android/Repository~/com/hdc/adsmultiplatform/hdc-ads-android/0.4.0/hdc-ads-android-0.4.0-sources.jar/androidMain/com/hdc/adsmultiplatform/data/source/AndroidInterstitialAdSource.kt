package com.hdc.adsmultiplatform.data.source

import android.app.Activity
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult

/** Interstitial ads per alias, with a buffer of loaded ads to show from. */
internal interface AndroidInterstitialAdSource {
    fun configure(alias: String, config: InterstitialAdConfig)

    fun loadWithResult(
        activity: Activity,
        alias: String,
        bufferSize: Int,
        callback: (NativeAdLoadResult) -> Unit,
    )

    fun show(activity: Activity, alias: String, options: InterstitialShowOptions): Boolean

    fun destroy(alias: String)

    fun isReady(alias: String): Boolean
}
