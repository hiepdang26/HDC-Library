package com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry

object NativeAdLayoutNames {
    const val Default = FullscreenLayoutCatalog.SingleDefault
    val All: List<String> = FullscreenLayoutCatalog.AllLayouts

    fun default(): String = Default

    fun normalize(layoutName: String?): String =
        FullscreenLayoutCatalog.normalize(layoutName)
}
