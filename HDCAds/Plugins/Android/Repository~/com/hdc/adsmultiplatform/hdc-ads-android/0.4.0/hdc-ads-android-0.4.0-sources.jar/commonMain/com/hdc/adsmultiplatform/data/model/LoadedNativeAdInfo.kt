package com.hdc.adsmultiplatform.data.model

/** What the library reports about a loaded native ad (to Unity, in events), read from the network that loaded it. */
internal data class LoadedNativeAdInfo(
    val headline: String?,
    val body: String?,
    val callToAction: String?,
    val advertiser: String?,
    val store: String?,
    val price: String?,
    val mediationAdapter: String?,
    val responseId: String?,
    val adSource: String?,
    val adSourceId: String?,
)
