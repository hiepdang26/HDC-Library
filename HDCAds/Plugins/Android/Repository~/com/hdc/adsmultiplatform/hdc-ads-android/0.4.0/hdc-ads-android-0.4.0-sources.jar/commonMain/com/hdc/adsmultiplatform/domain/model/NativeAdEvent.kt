@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.domain.model

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/** What a loaded native ad reports once it is up, in network-neutral terms. */
@AdsConsoleSupportApi
@HiddenFromObjC
sealed interface NativeAdEvent {
    /** The network counted an impression. */
    object Impression : NativeAdEvent

    object Clicked : NativeAdEvent

    /** The ad opened a page over the app after a click. */
    object Opened : NativeAdEvent

    /** The network valued the impression at [value]; [response] says who served it. */
    class Paid(val value: AdPaidValue, val response: AdResponseInfo = AdResponseInfo()) : NativeAdEvent
}
