package com.hdc.adsmultiplatform.di

import com.hdc.adsmultiplatform.data.admob.config.AdMobAndroidTestAdUnits
import com.hdc.adsmultiplatform.data.admob.initializer.AdMobAndroidMobileAdsStarter
import com.hdc.adsmultiplatform.data.admob.repository.AndroidInterstitialAdRepository
import com.hdc.adsmultiplatform.data.admob.repository.AndroidNativeAdRepository
import com.hdc.adsmultiplatform.data.model.AdNetworkTestAdUnits
import com.hdc.adsmultiplatform.data.source.AndroidInterstitialAdSource
import com.hdc.adsmultiplatform.data.source.AndroidMobileAdsStarter
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.presentation.admob.renderer.AdMobAndroidViewHosts
import com.hdc.adsmultiplatform.presentation.fullscreen.state.interaction.FullscreenNativeAdInteractionRegistry
import com.hdc.adsmultiplatform.presentation.renderer.AndroidNativeAdViewHosts
import com.hdc.adsmultiplatform.unity.callback.FullscreenNativeAdUnityCallbacks
import org.koin.core.module.Module
import org.koin.dsl.module

/**
 * The AdMob plug-in: where ads come from (repositories), how the SDK starts, and the views that draw ads without
 * Compose. Its Compose renderers are in [androidComposeModule]. Another ad network is another module that binds the
 * same contracts, listed in [adsModules] instead of this one.
 */
internal val adMobAndroidModule: Module = module {
    single<AdNetworkTestAdUnits> { AdMobAndroidTestAdUnits }
    single {
        AndroidNativeAdRepository(
            fullscreenEvents = { instanceId, event -> get<FullscreenNativeAdUnityCallbacks>().onAdEvent(instanceId, event) },
            fullscreenInteractions = get<FullscreenNativeAdInteractionRegistry>(),
        )
    }
    single<AndroidNativeAdSource> { get<AndroidNativeAdRepository>() }
    single<AndroidInterstitialAdSource> { AndroidInterstitialAdRepository() }
    single<AndroidMobileAdsStarter> { AdMobAndroidMobileAdsStarter() }
    single<AndroidNativeAdViewHosts> { AdMobAndroidViewHosts(get<AndroidNativeAdRepository>()) }
}
