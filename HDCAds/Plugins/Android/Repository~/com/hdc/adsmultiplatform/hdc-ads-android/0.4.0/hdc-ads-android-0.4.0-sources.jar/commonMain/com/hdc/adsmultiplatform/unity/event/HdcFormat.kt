package com.hdc.adsmultiplatform.unity.event

/** The `format` of a bridge event. */
internal object HdcFormat {
    const val Sdk = "sdk"
    const val Interstitial = "interstitial"
    const val Fullscreen = "fullscreen"
    const val Banner = "banner"
    const val Popup = "popup"
}
