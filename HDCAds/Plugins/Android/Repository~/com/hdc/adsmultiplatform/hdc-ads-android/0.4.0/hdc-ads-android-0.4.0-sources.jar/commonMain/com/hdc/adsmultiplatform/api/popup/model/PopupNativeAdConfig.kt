package com.hdc.adsmultiplatform.api.popup.model

import com.hdc.adsmultiplatform.presentation.popup.layouts.registry.PopupNativeAdLayoutCatalog

data class PopupNativeAdConfig(
    val ids: List<String>,
    val layoutName: String = PopupNativeAdLayoutCatalog.Default,
    val timeShowSeconds: Int = 5,
    val timeReloadSeconds: Int = 0,
    val xDp: Float = 16f,
    val yDp: Float = 96f,
    val adWidthDp: Float = 320f,
    val adHeightDp: Float = 280f,
    val autoClose: Boolean = false,
    val enableCtrOverlay: Boolean = false,
    /** Layouts for ads from given ad sources; an ad from any other source shows [layoutName]. */
    val adSourceLayouts: List<PopupNativeAdSourceLayout> = emptyList(),
)
