package com.hdc.adsmultiplatform.unity.host

import com.hdc.adsmultiplatform.api.popup.callback.PopupNativeAdCallback
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdError
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdShown
import com.hdc.adsmultiplatform.presentation.popup.view.runtime.AndroidPopupRuntimes
import com.hdc.adsmultiplatform.unity.event.HdcNativeStateEvents
import com.hdc.adsmultiplatform.unity.gameplay.HdcUnityActivity
import com.hdc.adsmultiplatform.unity.port.HdcPopupHost

/** Native popups for the bridge, placed over the Unity activity by the Android popup runtimes. */
internal class AndroidHdcPopupHost(
    private val runtimes: AndroidPopupRuntimes,
) : HdcPopupHost {
    override fun load(id: String, config: PopupNativeAdConfig, events: HdcNativeStateEvents) {
        runtimes.create(id, config)
        runtimes.setCallback(id) { state -> events.onState(state) }
        runtimes.setAdCallbacks(
            id,
            callback = object : PopupNativeAdCallback {
                override fun onFailedToLoad(error: PopupNativeAdError) {
                    events.onLoadFailed(error.adUnitId, error.code, error.message)
                }
            },
            revenueCallback = null,
        )
        runtimes.load(id, HdcUnityActivity.require())
    }

    override fun updatePlacement(id: String, xDp: Float, yDp: Float, widthDp: Float, heightDp: Float) {
        runtimes.updatePlacement(id, xDp, yDp, widthDp, heightDp)
    }

    override fun show(id: String) {
        runtimes.show(id, HdcUnityActivity.current())
    }

    override fun close(id: String) {
        runtimes.close(id)
    }

    override fun hide(id: String) {
        runtimes.hide(id)
    }

    override fun stop(id: String) {
        runtimes.stop(id)
    }

    override fun destroy(id: String) {
        runtimes.destroy(id)
    }

    override fun isReady(id: String): Boolean = runtimes.isReady(id)

    override fun isDisplayable(id: String): Boolean = runtimes.isDisplayable(id)

    override fun state(id: String): String = runtimes.stateFor(id)

    override fun shown(id: String): PopupNativeAdShown? = runtimes.shownAd(id)
}
