package com.hdc.adsmultiplatform.presentation.popup.state

/** The layout and ad source of the popup on screen, or of the last one shown. */
internal data class PopupNativeAdShown(
    val layoutName: String,
    val adSourceId: String,
    val adSourceName: String,
)
