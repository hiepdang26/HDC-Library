package com.hdc.adsmultiplatform.api.fullscreen.model

data class FullscreenNativeAdError(
    val alias: String,
    val adUnitId: String,
    val code: Int = -1,
    val message: String,
)
