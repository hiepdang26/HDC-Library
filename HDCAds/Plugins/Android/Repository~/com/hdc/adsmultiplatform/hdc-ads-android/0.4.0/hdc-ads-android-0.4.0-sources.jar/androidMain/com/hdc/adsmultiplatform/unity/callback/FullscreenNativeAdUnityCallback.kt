package com.hdc.adsmultiplatform.unity.callback

import com.hdc.adsmultiplatform.api.fullscreen.callback.FullscreenNativeAdCallback
import com.hdc.adsmultiplatform.unity.model.FullscreenNativeAdUnityInfo
import com.hdc.adsmultiplatform.unity.model.FullscreenNativeAdUnityPaidInfo

/**
 * Fullscreen native callback with the methods of the reference library's `FullscreenNativeAdCallback`.
 * The reference library's Unity `FSNACallback` proxy works with this library once its interface name is changed to this one.
 */
interface FullscreenNativeAdUnityCallback {
    fun onFSNALoaded(ad: FullscreenNativeAdUnityInfo)
    fun onFSNADisplayed(ad: FullscreenNativeAdUnityInfo)
    fun onFSNAOpened(ad: FullscreenNativeAdUnityInfo)
    fun onFSNAClosed(ad: FullscreenNativeAdUnityInfo)
    fun onFSNAClicked(ad: FullscreenNativeAdUnityInfo)
    fun onFSNAFailedToLoad(adUnit: String, errorCode: Int, error: String)
    fun onFSNAPaidImpression(ad: FullscreenNativeAdUnityInfo, paidInfo: FullscreenNativeAdUnityPaidInfo)
    fun onFSNADisplayable()
}
