package com.hdc.adsmultiplatform.api.interstitial.registry

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.domain.model.NativeAdState

internal data class InterstitialAdEntry(
    val config: InterstitialAdConfig,
    val state: NativeAdState = NativeAdState.Idle,
    val loadedAdUnitId: String? = null,
)
