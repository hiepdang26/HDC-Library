package com.hdc.adsmultiplatform.presentation.renderer

import android.content.Context

/**
 * Draws the native ads of a network with plain Android views, for the screens Unity shows without Compose: one host
 * per ad on screen. The Compose twin is [AndroidNativeAdRenderers].
 */
internal interface AndroidNativeAdViewHosts {
    fun createFullscreenHost(context: Context): AndroidFullscreenNativeAdHost

    fun createBannerHost(context: Context): AndroidBannerNativeAdHost

    fun createPopupHost(context: Context): AndroidPopupNativeAdHost
}
