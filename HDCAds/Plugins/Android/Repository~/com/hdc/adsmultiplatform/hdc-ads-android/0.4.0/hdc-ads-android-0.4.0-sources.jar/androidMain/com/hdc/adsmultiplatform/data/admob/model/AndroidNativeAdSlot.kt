package com.hdc.adsmultiplatform.data.admob.model

import com.google.android.gms.ads.nativead.NativeAd
import com.hdc.adsmultiplatform.domain.policy.FailureBackoffPolicy

internal data class AndroidNativeAdSlot(
    var nativeAd: NativeAd? = null,
    var loadedAdUnitId: String? = null,
    var requestVersion: Int = 0,
    val reloadPolicy: FailureBackoffPolicy = FailureBackoffPolicy(),
    var retryRunnable: Runnable? = null,
    // Ad unit ids of the latest request, and whether it is still waiting for a result (a pending retry does not count).
    var requestedAdUnitIds: List<String> = emptyList(),
    var isLoading: Boolean = false,
    var loadedAtElapsedMillis: Long = 0L,
)
