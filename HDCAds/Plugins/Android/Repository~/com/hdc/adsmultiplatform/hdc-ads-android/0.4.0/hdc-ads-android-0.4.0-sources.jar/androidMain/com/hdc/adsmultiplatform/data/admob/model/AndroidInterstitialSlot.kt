package com.hdc.adsmultiplatform.data.admob.model

import com.hdc.adsmultiplatform.data.admob.config.AdMobAndroidTestAdUnits
import com.hdc.adsmultiplatform.data.common.buffer.InterstitialAdBuffer

internal class AndroidInterstitialSlot : InterstitialAdBuffer<AndroidLoadedInterstitialAd>(
    defaultAdUnitId = AdMobAndroidTestAdUnits.interstitial,
)
