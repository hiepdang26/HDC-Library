package com.hdc.adsmultiplatform.api.fullscreen.registry

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.domain.model.NativeAdState

internal data class FullscreenNativeAdEntry(
    val config: FullscreenNativeAdConfig,
    val state: NativeAdState = NativeAdState.Idle,
    val loadedAdUnitId: String? = null,
    val displayedLayoutName: String = "",
)
