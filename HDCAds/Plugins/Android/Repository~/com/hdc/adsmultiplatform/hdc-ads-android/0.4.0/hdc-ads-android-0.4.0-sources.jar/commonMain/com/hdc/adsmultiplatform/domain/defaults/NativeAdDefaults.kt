package com.hdc.adsmultiplatform.domain.defaults

const val DefaultNativeAdInstanceId = "fullscreen_native_default"
