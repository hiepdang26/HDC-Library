package com.hdc.adsmultiplatform.data.admob.initializer

import android.content.Context
import com.google.android.gms.ads.MobileAds
import com.hdc.adsmultiplatform.data.source.AndroidMobileAdsStarter
import kotlin.concurrent.thread

/** Starts Google Mobile Ads off the main thread, as Google recommends, so SDK start-up cannot stall the UI. */
internal class AdMobAndroidMobileAdsStarter : AndroidMobileAdsStarter {
    override fun start(context: Context, onStarted: () -> Unit) {
        val appContext = context.applicationContext
        thread(name = "hdc-ads-init") {
            MobileAds.initialize(appContext) { onStarted() }
        }
    }
}
