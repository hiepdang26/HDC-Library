@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.data.mediation.meta.parser

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.domain.parser.splitListEntries
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
fun metaTestDeviceIdsFor(
    hashesText: String,
    currentDeviceHash: String,
): List<String> =
    (parseMetaTestDeviceHashes(hashesText) + currentDeviceHash)
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .distinct()

internal fun parseMetaTestDeviceHashes(hashesText: String): List<String> =
    hashesText
        .splitListEntries()
        .distinct()
