package com.hdc.adsmultiplatform.presentation.popup.view.runtime

import com.hdc.adsmultiplatform.api.common.model.NativeAdPaidInfo
import com.hdc.adsmultiplatform.api.popup.callback.PopupNativeAdCallback
import com.hdc.adsmultiplatform.api.popup.callback.PopupNativeAdRevenueCallback
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdError
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdInfo

/**
 * The callbacks a popup runtime gives its ViewModel, passed on to the ones set later ([callback], [revenueCallback]):
 * the ViewModel takes its callbacks when it is created, and the game sets them after.
 */
internal class PopupNativeAdCallbackRelay : PopupNativeAdCallback, PopupNativeAdRevenueCallback {
    var callback: PopupNativeAdCallback? = null
    var revenueCallback: PopupNativeAdRevenueCallback? = null

    override fun onLoaded(ad: PopupNativeAdInfo) {
        callback?.onLoaded(ad)
    }

    override fun onDisplayable(alias: String) {
        callback?.onDisplayable(alias)
    }

    override fun onDisplayed(ad: PopupNativeAdInfo) {
        callback?.onDisplayed(ad)
    }

    override fun onOpened(ad: PopupNativeAdInfo) {
        callback?.onOpened(ad)
    }

    override fun onClosed(ad: PopupNativeAdInfo) {
        callback?.onClosed(ad)
    }

    override fun onClicked(ad: PopupNativeAdInfo) {
        callback?.onClicked(ad)
    }

    override fun onFailedToLoad(error: PopupNativeAdError) {
        callback?.onFailedToLoad(error)
    }

    override fun onImpression(ad: PopupNativeAdInfo) {
        revenueCallback?.onImpression(ad)
    }

    override fun onPaidImpression(ad: PopupNativeAdInfo, paidInfo: NativeAdPaidInfo) {
        revenueCallback?.onPaidImpression(ad, paidInfo)
    }
}
