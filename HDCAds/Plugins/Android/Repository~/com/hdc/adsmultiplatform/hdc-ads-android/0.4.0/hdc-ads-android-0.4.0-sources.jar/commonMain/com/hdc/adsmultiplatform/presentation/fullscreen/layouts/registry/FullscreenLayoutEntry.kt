package com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry

/**
 * One fullscreen layout name and its family. A name whose family has its own designs is drawn by its design in the
 * family folder (`layouts/<family>/…LayoutDesigns.kt`); the others (transparent, ctr, multi, sequence) are accepted by
 * the AAR-compatible catalog but drawn as `fs_single_universal_01`.
 */
internal class FullscreenLayoutEntry(
    val name: String,
    val family: FullscreenLayoutFamily,
)
