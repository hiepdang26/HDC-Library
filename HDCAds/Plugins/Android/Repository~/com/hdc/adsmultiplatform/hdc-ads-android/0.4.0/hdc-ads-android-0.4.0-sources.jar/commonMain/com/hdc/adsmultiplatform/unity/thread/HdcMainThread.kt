package com.hdc.adsmultiplatform.unity.thread

import com.hdc.adsmultiplatform.unity.log.HdcLog

/** Runs [block] on the main thread: right away when already on it, otherwise posted. */
internal expect fun hdcRunOnMain(block: () -> Unit)

/** Posts [block] to the main thread, to run after the current main loop work. */
internal expect fun hdcPostToMain(block: () -> Unit)

/**
 * Runs [block] on the main thread and waits for its result. When the main thread does not start [block] in time, or is
 * pausing Unity, the answer is [fallback] and [block] never runs.
 */
internal expect fun <T> hdcQueryOnMain(fallback: T, block: () -> T): T

/** True on the main thread, where the hosts run. Unity calls arrive there on iOS, and on another thread on Android. */
internal expect fun hdcIsMainThread(): Boolean

/**
 * Starts a show that a check on the main thread allowed. On the main thread it runs now, and its result is the
 * answer. Elsewhere it is posted and the answer is true: a show can keep the main thread busy longer than
 * [hdcQueryOnMain] waits, and the caller would then hear "not shown" while the ad shows. A posted show that does not
 * start reports why through [onNotStarted], for the caller to hear as an event.
 */
internal fun hdcStartShow(onNotStarted: (String) -> Unit, show: () -> Boolean): Boolean {
    if (hdcIsMainThread()) {
        return show()
    }
    hdcPostToMain {
        val reason = try {
            if (show()) null else "it did not start"
        } catch (error: Throwable) {
            HdcLog.warn("show failed: ${error.message}")
            error.message ?: error::class.simpleName.orEmpty()
        }
        reason?.let(onNotStarted)
    }
    return true
}

/** Runs [block] on the main thread; a failure goes to [onError] instead of crashing the host app. */
internal fun hdcRunOnMainCatching(onError: (Throwable) -> Unit, block: () -> Unit) {
    hdcRunOnMain {
        try {
            block()
        } catch (error: Throwable) {
            HdcLog.warn("main thread task failed: ${error.message}")
            onError(error)
        }
    }
}
