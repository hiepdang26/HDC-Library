package com.hdc.adsmultiplatform.unity.port

import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.unity.event.HdcNativeStateEvents
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdShown

/** Native popups for the bridge. Called on the main thread only. */
internal interface HdcPopupHost {
    /** Loads [config] for [id]; [events] hears its states and the error of each failed load. */
    fun load(id: String, config: PopupNativeAdConfig, events: HdcNativeStateEvents)

    fun updatePlacement(id: String, xDp: Float, yDp: Float, widthDp: Float, heightDp: Float)

    fun show(id: String)

    fun close(id: String)

    fun hide(id: String)

    fun stop(id: String)

    fun destroy(id: String)

    fun isReady(id: String): Boolean

    fun isDisplayable(id: String): Boolean

    fun state(id: String): String

    /** The layout and ad source of the popup on screen, or of the last one shown. */
    fun shown(id: String): PopupNativeAdShown?
}
