package com.hdc.adsmultiplatform.unity.port

/** Meta Audience Network test mode: test devices get Meta test ads. Called on the main thread only. */
internal interface HdcMetaTestHost {
    /** This device's Meta test device hash. */
    fun deviceHash(): String

    /**
     * Registers this device and [extraDeviceHashes] as test devices with the test creative [testAdType]
     * (0 is the default creative). Returns whether Meta accepted them.
     */
    fun enable(extraDeviceHashes: List<String>, testAdType: Int): Boolean

    fun disable()

    fun isEnabled(): Boolean
}
