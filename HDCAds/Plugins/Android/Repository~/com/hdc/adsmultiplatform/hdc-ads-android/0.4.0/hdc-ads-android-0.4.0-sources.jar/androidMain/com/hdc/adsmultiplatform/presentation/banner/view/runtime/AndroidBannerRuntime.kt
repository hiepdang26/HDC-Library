package com.hdc.adsmultiplatform.presentation.banner.view.runtime

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdConfig
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdFormats
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.banner.layouts.registry.BannerNativeAdSizing
import com.hdc.adsmultiplatform.presentation.banner.state.BannerNativeAdUiState
import com.hdc.adsmultiplatform.presentation.banner.viewmodel.BannerNativeAdViewModel
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeCancellation
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeLoader
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeScheduler
import com.hdc.adsmultiplatform.presentation.renderer.AndroidBannerNativeAdHost
import com.hdc.adsmultiplatform.presentation.renderer.AndroidNativeAdViewHosts
import kotlin.math.roundToInt

/** One alias's native banner along the bottom of an activity's content, drawn by a view host. */
internal class AndroidBannerRuntime(
    alias: String,
    private val nativeAds: AndroidNativeAdSource,
    private val hosts: AndroidNativeAdViewHosts,
) {
    private val handler = Handler(Looper.getMainLooper())
    var activity: Activity? = null
    var stateCallback: (NativeAdState) -> Unit = {}
    private var snapshot = BannerNativeAdUiState()
    private var hostView: AndroidBannerNativeAdHost? = null

    private val loader = object : AdRuntimeLoader {
        override fun load(instanceId: String, adUnitId: String, callback: (NativeAdLoadResult) -> Unit) {
            val context = activity ?: return callback(
                NativeAdLoadResult(
                    state = NativeAdState.Failed,
                    adUnitId = adUnitId,
                    code = NativeAdLoadResult.NoErrorCode,
                    message = "Missing activity",
                ),
            )
            nativeAds.loadWithResult(
                format = NativeAdFormats.Banner,
                instanceId = instanceId,
                context = context,
                adUnitIds = listOf(adUnitId),
                callback = callback,
            )
        }

        override fun destroy(instanceId: String) {
            nativeAds.destroy(NativeAdFormats.Banner, instanceId)
        }

        override fun listen(instanceId: String, listener: (NativeAdEvent) -> Unit) {
            nativeAds.setEventListener(NativeAdFormats.Banner, instanceId, listener)
        }
    }

    private val scheduler = AdRuntimeScheduler { delayMillis, block ->
        val runnable = Runnable(block)
        handler.postDelayed(runnable, delayMillis)
        AdRuntimeCancellation { handler.removeCallbacks(runnable) }
    }

    /** What the banners report, passed on to the callbacks the bridge sets. */
    val callbacks = BannerNativeAdCallbackRelay()

    val controller = BannerNativeAdViewModel(
        alias = alias,
        loader = loader,
        scheduler = scheduler,
        callback = callbacks,
        revenueCallback = callbacks,
        onSnapshotChanged = { next ->
            snapshot = next
            stateCallback(next.state)
            if (next.isVisible) {
                ensurePresented()
                render(next)
            } else if (next.state == NativeAdState.onClosed) {
                dismiss()
            }
        },
    )

    fun configure(config: BannerNativeAdConfig) {
        controller.configure(config)
    }

    fun ensurePresented() {
        val activity = activity ?: return
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val current = hostView
        if (current != null && current.view.parent === content) {
            layoutBanner()
            return
        }
        if (current != null) {
            dismiss()
        }
        val host = hosts.createBannerHost(activity)
        content.addView(
            host.view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1, Gravity.BOTTOM),
        )
        hostView = host
        layoutBanner()
    }

    fun destroy() {
        controller.destroy()
        dismiss()
    }

    private fun render(current: BannerNativeAdUiState) {
        val host = hostView ?: return
        val instanceId = current.activeInstanceId ?: return
        layoutBanner()
        host.view.bringToFront()
        host.render(
            instanceId = instanceId,
            fallbackAdUnitId = current.activeAdUnitId.orEmpty(),
            layoutName = current.activeLayoutName,
            isExpanded = current.isExpanded,
            showInternalExpandedClose = current.isExpanded && current.canCollapseExpanded,
            enableExpandedCloseOverlay = current.expandedCloseClickEnabled,
            collapseCountdownSecondsRemaining = current.collapseCountdownSecondsRemaining,
            collapseCountdownProgress = current.collapseCountdownProgress,
            showCollapsedClose = current.canCloseCollapsed,
            onStateChanged = stateCallback,
            onCollapsedCloseClick = { controller.hide() },
            onCollapseClick = { controller.collapse() },
        )
    }

    // The banner spans the width; its height is a share of the content height, larger while expanded, as on iOS.
    private fun layoutBanner() {
        val host = hostView ?: return
        val content = host.view.parent as? ViewGroup ?: return
        val metrics = content.resources.displayMetrics
        val widthPx = if (content.width > 0) content.width else metrics.widthPixels
        val heightPx = if (content.height > 0) content.height else metrics.heightPixels
        val bannerHeightDp = BannerNativeAdSizing.overlayHeight(
            isExpanded = snapshot.isExpanded,
            viewportHeight = heightPx / metrics.density.toDouble(),
            isLandscape = widthPx > heightPx,
        )
        val params = host.view.layoutParams as? FrameLayout.LayoutParams ?: return
        val bannerHeightPx = (bannerHeightDp * metrics.density).roundToInt()
        if (params.height != bannerHeightPx || params.gravity != Gravity.BOTTOM) {
            params.height = bannerHeightPx
            params.gravity = Gravity.BOTTOM
            host.view.layoutParams = params
        }
    }

    private fun dismiss() {
        val host = hostView ?: return
        hostView = null
        host.release()
        (host.view.parent as? ViewGroup)?.removeView(host.view)
    }
}
