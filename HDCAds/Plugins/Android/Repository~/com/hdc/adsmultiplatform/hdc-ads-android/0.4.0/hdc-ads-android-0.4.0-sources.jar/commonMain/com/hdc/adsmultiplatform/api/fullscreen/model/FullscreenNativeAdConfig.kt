package com.hdc.adsmultiplatform.api.fullscreen.model

data class FullscreenNativeAdConfig(
    val ids: List<String>,
    val preloadBufferSize: Int = 1,
    val enableReloadAfterShow: Boolean = true,
)
