package com.hdc.adsmultiplatform.unity.host

import com.hdc.adsmultiplatform.data.mediation.meta.parser.metaTestDeviceIdsFor
import com.hdc.adsmultiplatform.data.mediation.meta.sdk.AndroidMetaTestDeviceSdk
import com.hdc.adsmultiplatform.unity.gameplay.HdcUnityActivity
import com.hdc.adsmultiplatform.unity.port.HdcMetaTestHost

/** Meta Audience Network test mode for the bridge; nothing happens when the game has no Meta SDK. */
internal class AndroidHdcMetaTestHost : HdcMetaTestHost {
    override fun deviceHash(): String =
        AndroidMetaTestDeviceSdk.getCurrentMetaTestDeviceHash(HdcUnityActivity.require().applicationContext)

    override fun enable(extraDeviceHashes: List<String>, testAdType: Int): Boolean {
        val deviceIds = metaTestDeviceIdsFor(extraDeviceHashes.joinToString(","), deviceHash())
        val enabled = AndroidMetaTestDeviceSdk.enableMetaTestMode(deviceIds).isSuccess
        if (enabled) {
            AndroidMetaTestDeviceSdk.setTestAdType(testAdType)
        }
        return enabled
    }

    override fun disable() {
        AndroidMetaTestDeviceSdk.disableMetaTestMode()
    }

    override fun isEnabled(): Boolean =
        AndroidMetaTestDeviceSdk.isTestModeEnabled(HdcUnityActivity.require().applicationContext)
}
