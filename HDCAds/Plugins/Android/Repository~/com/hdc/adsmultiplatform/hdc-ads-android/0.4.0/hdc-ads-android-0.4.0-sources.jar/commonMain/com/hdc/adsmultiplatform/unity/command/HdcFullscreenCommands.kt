package com.hdc.adsmultiplatform.unity.command

import com.hdc.adsmultiplatform.api.fullscreen.registry.FullscreenNativeAdRegistry
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.unity.event.HdcEventType
import com.hdc.adsmultiplatform.unity.event.HdcEvents
import com.hdc.adsmultiplatform.unity.event.HdcFormat
import com.hdc.adsmultiplatform.unity.event.HdcFullscreenEvents
import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.json.HdcFullscreenOptions
import com.hdc.adsmultiplatform.unity.port.HdcFullscreenHost
import com.hdc.adsmultiplatform.unity.thread.hdcQueryOnMain
import com.hdc.adsmultiplatform.unity.thread.hdcRunOnMainCatching
import com.hdc.adsmultiplatform.unity.thread.hdcStartShow

/**
 * `fullscreen.*` commands for native ads that cover the screen.
 *
 * - `load` `{id, adUnitIds:[…], reloadAfterShow?}`: ad units are tried in order.
 * - `show` `{id, mode?, layoutNames?, duration?, durations?, orientation?, autoClose?, pauseGameplay?,
 *   enableAdComeback?, showTCD?, delay?, timeUpC?, clickAssets?{…}, assetVisibility?{…}}` returns whether
 *   a loaded ad starts to show. A show that cannot start after all reports ShowFailed.
 * - `hide`, `isReady`, `destroy` `{id}`.
 */
internal object HdcFullscreenCommands {
    private val host: HdcFullscreenHost by lazy { adsGet() }

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val reloadAfterShow = args.boolean("reloadAfterShow", true)
        hdcRunOnMainCatching(onError = { error -> loadFailed(id, error) }) {
            FullscreenNativeAdRegistry.setCallback(id, HdcFullscreenEvents(id))
            host.load(id, adUnitIds, reloadAfterShow)
        }
        return true
    }

    fun show(args: HdcArgs): Boolean {
        val id = args.id()
        val options = HdcFullscreenOptions.parse(args)
        val ready = hdcQueryOnMain(fallback = false) {
            FullscreenNativeAdRegistry.isReady(id).also { ready ->
                if (!ready) showFailed(id, "Fullscreen native ad not ready. Load first")
            }
        }
        val notShown = { reason: String -> showFailed(id, "Fullscreen native ad did not show: $reason") }
        return ready && hdcStartShow(notShown) { host.show(id, options) }
    }

    fun hide(args: HdcArgs): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { host.hide(id) }
        return true
    }

    fun isReady(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { FullscreenNativeAdRegistry.isReady(id) }
    }

    fun destroy(args: HdcArgs): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { host.destroy(id) }
        return true
    }

    private fun loadFailed(id: String, error: Throwable) {
        HdcEvents.emit(
            id = id,
            format = HdcFormat.Fullscreen,
            type = HdcEventType.LoadFailed,
            fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
        )
    }

    private fun showFailed(id: String, message: String) {
        HdcEvents.emit(
            id = id,
            format = HdcFormat.Fullscreen,
            type = HdcEventType.ShowFailed,
            fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, message),
        )
    }
}
