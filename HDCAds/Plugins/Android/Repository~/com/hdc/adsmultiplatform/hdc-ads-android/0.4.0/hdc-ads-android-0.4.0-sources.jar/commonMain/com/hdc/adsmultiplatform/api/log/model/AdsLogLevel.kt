package com.hdc.adsmultiplatform.api.log.model

/** How much the library logs: nothing, warnings, or everything including each load and show step. */
enum class AdsLogLevel {
    Off,
    Warn,
    Debug,
}
