package com.hdc.adsmultiplatform.unity.json

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdMode
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeAssetVisibilityOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeClickAssetOptions
import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog

/** Fullscreen show options from the bridge's arguments, with the same field names as the ads config JSON. */
internal object HdcFullscreenOptions {
    fun parse(args: HdcArgs): FullscreenNativeAdShowOptions {
        val defaults = FullscreenNativeAdShowOptions()
        val layoutNames = args.stringList("layoutNames")
        val click = args.obj("clickAssets")
        val visible = args.obj("assetVisibility")
        return FullscreenNativeAdShowOptions(
            layoutName = layoutNames.firstOrNull() ?: FullscreenLayoutCatalog.SingleDefault,
            durationSeconds = args.double("duration", defaults.durationSeconds),
            autoClose = args.boolean("autoClose", defaults.autoClose),
            pauseGameplay = args.boolean("pauseGameplay", defaults.pauseGameplay),
            mode = FullscreenNativeAdMode.fromName(args.string("mode")),
            layoutNames = layoutNames,
            durationsSeconds = args.doubleList("durations"),
            orientation = args.string("orientation").ifBlank { defaults.orientation },
            enableAdComeback = args.boolean("enableAdComeback", defaults.enableAdComeback),
            showTCD = args.boolean("showTCD", defaults.showTCD),
            delaySeconds = args.double("delay", defaults.delaySeconds),
            timeUpCSeconds = args.int("timeUpC", defaults.timeUpCSeconds),
            clickAssets = NativeClickAssetOptions(
                cta = click.boolean("cta", true),
                headline = click.boolean("headline", true),
                body = click.boolean("body", true),
                description = click.boolean("description", true),
                icon = click.boolean("icon", true),
                advertiser = click.boolean("advertiser", true),
                media = click.boolean("media", true),
                mediaImage = click.boolean("mediaImage", true),
                mediaVideo = click.boolean("mediaVideo", true),
            ),
            assetVisibility = NativeAssetVisibilityOptions(
                cta = visible.boolean("cta", true),
                headline = visible.boolean("headline", true),
                body = visible.boolean("body", true),
                description = visible.boolean("description", true),
                icon = visible.boolean("icon", true),
                advertiser = visible.boolean("advertiser", true),
                media = visible.boolean("media", true),
                mediaImage = visible.boolean("mediaImage", true),
                mediaVideo = visible.boolean("mediaVideo", true),
                price = visible.boolean("price", true),
                store = visible.boolean("store", true),
                starRating = visible.boolean("starRating", true),
            ),
        )
    }
}
