package com.hdc.adsmultiplatform.domain.model

enum class NativeAdState {
    Idle,
    Loading,
    Loaded,
    Failed,
    Shown,
    onClosed,
}
