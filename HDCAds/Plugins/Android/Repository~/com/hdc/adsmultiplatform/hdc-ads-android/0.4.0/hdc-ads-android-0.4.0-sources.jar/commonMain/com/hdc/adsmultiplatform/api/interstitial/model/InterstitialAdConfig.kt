package com.hdc.adsmultiplatform.api.interstitial.model

data class InterstitialAdConfig(
    val ids: List<String> = emptyList(),
    val autoReload: Boolean = true,
    val preloadBufferSize: Int = 1,
)
