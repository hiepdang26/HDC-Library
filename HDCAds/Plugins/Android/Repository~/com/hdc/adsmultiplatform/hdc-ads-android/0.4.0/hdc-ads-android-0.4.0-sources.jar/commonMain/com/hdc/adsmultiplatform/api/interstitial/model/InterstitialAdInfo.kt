package com.hdc.adsmultiplatform.api.interstitial.model

data class InterstitialAdInfo(
    val adUnitId: String,
    val mediationAdapter: String = "",
    val responseId: String = "",
    val adSource: String? = null,
)
