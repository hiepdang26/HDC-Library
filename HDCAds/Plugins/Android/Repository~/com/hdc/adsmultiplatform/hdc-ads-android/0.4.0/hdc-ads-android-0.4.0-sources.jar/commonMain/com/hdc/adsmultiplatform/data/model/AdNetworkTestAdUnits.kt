package com.hdc.adsmultiplatform.data.model

/** The test ad units of a network, used when the app gives no ad unit id. */
internal data class AdNetworkTestAdUnits(
    val native: String,
    val nativeVideo: String,
    val interstitial: String,
)
