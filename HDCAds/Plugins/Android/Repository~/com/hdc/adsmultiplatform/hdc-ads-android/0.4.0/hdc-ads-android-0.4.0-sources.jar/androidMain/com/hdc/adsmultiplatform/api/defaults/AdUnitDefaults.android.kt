package com.hdc.adsmultiplatform.api.defaults

import com.hdc.adsmultiplatform.data.model.AdNetworkTestAdUnits
import com.hdc.adsmultiplatform.di.adsGet

actual fun defaultNativeAdUnitId(): String = adsGet<AdNetworkTestAdUnits>().native

actual fun defaultNativeVideoAdUnitId(): String = adsGet<AdNetworkTestAdUnits>().nativeVideo
