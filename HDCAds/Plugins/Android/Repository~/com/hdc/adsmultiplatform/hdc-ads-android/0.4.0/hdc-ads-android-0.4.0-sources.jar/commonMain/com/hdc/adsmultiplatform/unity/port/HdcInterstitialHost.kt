package com.hdc.adsmultiplatform.unity.port

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions

/** Interstitial ads for the bridge. Called on the main thread only. */
internal interface HdcInterstitialHost {
    fun load(id: String, config: InterstitialAdConfig)

    fun show(id: String, options: InterstitialShowOptions): Boolean

    fun isReady(id: String): Boolean

    fun destroy(id: String)
}
