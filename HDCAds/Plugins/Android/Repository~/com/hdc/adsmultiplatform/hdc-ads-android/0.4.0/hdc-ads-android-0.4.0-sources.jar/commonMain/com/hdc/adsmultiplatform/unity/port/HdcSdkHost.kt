package com.hdc.adsmultiplatform.unity.port

/** Starts the ad network SDK for the bridge's `init`. */
internal fun interface HdcSdkHost {
    /** Starts the SDK; [onComplete] runs on the main thread once it is ready. */
    fun initialize(onComplete: () -> Unit)
}
