package com.hdc.adsmultiplatform.presentation.popup.view.runtime

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdFormats
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.platform.log.AdsLog
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeCancellation
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeLoader
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeScheduler
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.AndroidFullscreenNativeAdWindow
import com.hdc.adsmultiplatform.presentation.popup.layouts.registry.PopupNativeAdLayoutCatalog
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdDisplayState
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdUiState
import com.hdc.adsmultiplatform.presentation.popup.state.PopupPlacementFrame
import com.hdc.adsmultiplatform.presentation.popup.viewmodel.PopupNativeAdViewModel
import com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy.minLayoutHeightDp
import com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy.normalizedForPopupRuntime
import com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy.placementFrame
import com.hdc.adsmultiplatform.presentation.renderer.AndroidNativeAdViewHosts
import com.hdc.adsmultiplatform.presentation.renderer.AndroidPopupNativeAdHost
import kotlin.math.roundToInt

/** How often a waiting show checks again whether the popup can be on screen. */
private const val PopupShowRetryMillis = 150L

/**
 * One alias's native popup over an activity's content, drawn by a view host. A show that cannot be on screen yet waits
 * instead of being dropped, as on iOS: it comes up once the game's activity has focus again (no interstitial, store
 * page or dialog over it) and no fullscreen ad is over the game.
 */
internal class AndroidPopupRuntime(
    private val alias: String,
    private val nativeAds: AndroidNativeAdSource,
    private val hosts: AndroidNativeAdViewHosts,
    private val fullscreen: AndroidFullscreenNativeAdWindow,
) {
    private val handler = Handler(Looper.getMainLooper())
    var activity: Activity? = null
    var stateCallback: (NativeAdState) -> Unit = {}
    private var config = PopupNativeAdConfig(ids = listOf(UnconfiguredAdUnitId))
    private var hostView: AndroidPopupNativeAdHost? = null
    private var isShowWaiting = false
    private var showWaitingFor: String? = null
    private var showWaitStartMillis = 0L
    private val showRetry = Runnable { showWhenPossible() }

    /** What the popups report, passed on to the callbacks the bridge sets. */
    val callbacks = PopupNativeAdCallbackRelay()

    private val loader = object : AdRuntimeLoader {
        override fun load(instanceId: String, adUnitId: String, callback: (NativeAdLoadResult) -> Unit) {
            val context = activity ?: return callback(
                NativeAdLoadResult(
                    state = NativeAdState.Failed,
                    adUnitId = adUnitId,
                    code = NativeAdLoadResult.NoErrorCode,
                    message = "Missing activity",
                ),
            )
            nativeAds.loadWithResult(
                format = NativeAdFormats.Popup,
                instanceId = instanceId,
                context = context,
                adUnitIds = listOf(adUnitId),
                callback = callback,
            )
        }

        override fun destroy(instanceId: String) {
            nativeAds.destroy(NativeAdFormats.Popup, instanceId)
        }

        override fun listen(instanceId: String, listener: (NativeAdEvent) -> Unit) {
            nativeAds.setEventListener(NativeAdFormats.Popup, instanceId, listener)
        }
    }

    private val scheduler = AdRuntimeScheduler { delayMillis, block ->
        val runnable = Runnable(block)
        handler.postDelayed(runnable, delayMillis)
        AdRuntimeCancellation { handler.removeCallbacks(runnable) }
    }

    val controller = PopupNativeAdViewModel(
        alias = alias,
        loader = loader,
        scheduler = scheduler,
        callback = callbacks,
        revenueCallback = callbacks,
        onSnapshotChanged = { next ->
            notifyState(next.state)
            if (next.isVisible) {
                try {
                    if (ensurePresented()) {
                        render(next)
                    }
                } catch (t: Throwable) {
                    fail("render failed alias=$alias", t)
                }
            } else if (next.state == NativeAdState.onClosed) {
                dismiss()
            }
        },
    )

    fun configure(nextConfig: PopupNativeAdConfig) {
        config = nextConfig.normalizedForPopupRuntime()
        controller.configure(config)
    }

    fun load(activity: Activity) {
        this.activity = activity
        controller.load()
    }

    fun show() {
        if (!isShowWaiting) {
            isShowWaiting = true
            showWaitingFor = null
            showWaitStartMillis = SystemClock.uptimeMillis()
        }
        showWhenPossible()
    }

    fun close() {
        cancelShowWait(reason = "close")
        controller.close()
    }

    fun hide() {
        cancelShowWait(reason = "hide")
        controller.hide()
    }

    fun stop() {
        cancelShowWait(reason = "stop")
        controller.stop()
    }

    fun isReady(): Boolean = controller.isReady()

    fun isDisplayable(): Boolean =
        controller.isDisplayable() && hasLoadedDisplayableAd() && config.hasValidPopupDimensions()

    fun isShowing(): Boolean = controller.isShowing()

    fun stateName(): String {
        val state = controller.stateName()
        return if (state == PopupNativeAdDisplayState.Displayable.name && !isDisplayable()) {
            PopupNativeAdDisplayState.Loaded.name
        } else {
            state
        }
    }

    fun updatePlacement(xDp: Float, yDp: Float, adWidthDp: Float, adHeightDp: Float) {
        if (!listOf(xDp, yDp, adWidthDp, adHeightDp).all { it.isFinite() }) {
            fail("placement update failed alias=$alias reason=non_finite", null)
            return
        }
        config = config.copy(
            xDp = xDp,
            yDp = yDp,
            adWidthDp = adWidthDp.coerceAtLeast(PopupNativeAdLayoutCatalog.MinWidthDp),
            adHeightDp = adHeightDp.coerceAtLeast(config.minLayoutHeightDp()),
        )
        applyPlacement()
    }

    fun destroy() {
        cancelShowWait(reason = "destroy")
        controller.destroy()
        dismiss()
    }

    private fun showWhenPossible() {
        handler.removeCallbacks(showRetry)
        if (!isShowWaiting) {
            return
        }
        if (!config.hasValidPopupDimensions()) {
            stopShowWait()
            fail("show failed alias=$alias reason=invalid_layout_config", null)
            return
        }
        val activity = activity
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            stopShowWait()
            fail("show failed alias=$alias reason=${if (activity == null) "missing_activity" else "activity_finishing"}", null)
            return
        }
        val waitReason = showWaitReason(activity)
        if (waitReason != null) {
            if (waitReason != showWaitingFor) {
                showWaitingFor = waitReason
                popupLog("show waiting alias=$alias reason=$waitReason")
            }
            handler.postDelayed(showRetry, PopupShowRetryMillis)
            return
        }
        val waitedFor = showWaitingFor
        val waitedMillis = SystemClock.uptimeMillis() - showWaitStartMillis
        stopShowWait()
        if (waitedFor != null) {
            popupLog("shown after waiting alias=$alias waitedMs=$waitedMillis lastReason=$waitedFor")
        }
        if (!ensurePresented()) {
            return
        }
        controller.show()
    }

    /** Why the popup cannot be on screen yet, or null when it can be shown now. */
    private fun showWaitReason(activity: Activity): String? {
        if (!activity.hasWindowFocus()) {
            return "activity_not_focused"
        }
        if (fullscreen.hasOverlay(activity)) {
            return "fullscreen_ad_over_game"
        }
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return "missing_content_view"
        if (placementFrame(content) == null) {
            return "content_without_size"
        }
        if (!hasLoadedDisplayableAd()) {
            // The game shows after it heard Loaded, but a reload or a retry can be running: wait for its ad.
            if (!controller.isLoading()) {
                popupLog("show loads alias=$alias reason=no_loaded_ad state=${controller.stateName()}")
                controller.load()
            }
            return "ad_loading_state=${controller.stateName()}"
        }
        return null
    }

    private fun cancelShowWait(reason: String) {
        if (!isShowWaiting) {
            return
        }
        val waitedMillis = SystemClock.uptimeMillis() - showWaitStartMillis
        popupLog("show wait cancelled alias=$alias by=$reason waitedMs=$waitedMillis lastReason=$showWaitingFor")
        stopShowWait()
    }

    private fun stopShowWait() {
        isShowWaiting = false
        showWaitingFor = null
        handler.removeCallbacks(showRetry)
    }

    private fun ensurePresented(): Boolean {
        if (hostView != null) {
            return true
        }
        val activity = activity ?: return false
        val content = activity.findViewById<ViewGroup>(android.R.id.content)
        if (content == null) {
            fail("attach skipped alias=$alias reason=missing_content_view", null)
            return false
        }
        val frame = placementFrame(content)
        if (frame == null) {
            fail("attach skipped alias=$alias reason=invalid_content_bounds", null)
            return false
        }
        val host = hosts.createPopupHost(activity)
        content.addView(host.view, frame.toLayoutParams(content.resources.displayMetrics.density))
        hostView = host
        return true
    }

    private fun render(current: PopupNativeAdUiState) {
        val host = hostView ?: return
        val instanceId = current.activeInstanceId ?: return
        applyPlacement()
        host.view.visibility = View.VISIBLE
        host.view.bringToFront()
        host.render(
            instanceId = instanceId,
            fallbackAdUnitId = current.activeAdUnitId.orEmpty(),
            layoutName = current.layoutName,
            closeSecondsRemaining = current.closeSecondsRemaining,
            showClose = current.canClose,
            enableCtrOverlay = config.enableCtrOverlay,
            // The host reports Loaded each time it binds the ad it shows: after Shown, it is not news.
            onStateChanged = { state -> if (state != NativeAdState.Loaded) notifyState(state) },
            onCloseClick = {
                runCatching { controller.close() }.onFailure { fail("close click failed alias=$alias", it) }
            },
        )
    }

    private fun dismiss() {
        val host = hostView ?: return
        hostView = null
        host.release()
        (host.view.parent as? ViewGroup)?.removeView(host.view)
    }

    private fun fail(message: String, throwable: Throwable?) {
        popupLog(if (throwable == null) message else "$message throwable=${throwable.message.orEmpty()}")
        stopShowWait()
        controller.markShowFailed(message)
        dismiss()
    }

    private fun applyPlacement() {
        val host = hostView ?: return
        val content = host.view.parent as? ViewGroup ?: return
        val frame = placementFrame(content) ?: return
        host.view.layoutParams = frame.toLayoutParams(content.resources.displayMetrics.density)
    }

    private fun placementFrame(content: View): PopupPlacementFrame? {
        val density = content.resources.displayMetrics.density
        return config.placementFrame(
            viewportWidth = content.width / density.toDouble(),
            viewportHeight = content.height / density.toDouble(),
        )
    }

    private fun hasLoadedDisplayableAd(): Boolean {
        val instanceId = controller.displayableInstanceId() ?: return false
        return nativeAds.hasLoadedAd(NativeAdFormats.Popup, instanceId)
    }

    private fun notifyState(state: NativeAdState) {
        try {
            stateCallback(state)
        } catch (t: Throwable) {
            popupLog("state callback failed alias=$alias state=${state.name} message=${t.message.orEmpty()}")
        }
    }

    private fun popupLog(message: String) {
        AdsLog.debug("AdsMultiplatform Android popup $message")
    }
}

private fun PopupNativeAdConfig.hasValidPopupDimensions(): Boolean =
    listOf(xDp, yDp, adWidthDp, adHeightDp).all { it.isFinite() } && adWidthDp > 0f && adHeightDp > 0f

private fun PopupPlacementFrame.toLayoutParams(density: Float): FrameLayout.LayoutParams =
    FrameLayout.LayoutParams((width * density).roundToInt(), (height * density).roundToInt()).apply {
        gravity = Gravity.TOP or Gravity.START
        leftMargin = (x * density).roundToInt()
        topMargin = (y * density).roundToInt()
    }
