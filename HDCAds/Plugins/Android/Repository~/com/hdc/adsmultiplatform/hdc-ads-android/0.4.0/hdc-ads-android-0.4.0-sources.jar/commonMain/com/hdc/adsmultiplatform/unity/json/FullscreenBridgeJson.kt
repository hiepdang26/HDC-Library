package com.hdc.adsmultiplatform.unity.json

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdMode
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeAssetVisibilityOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeClickAssetOptions
import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog

/**
 * Reads the JSON the reference library's Unity glue sends for a fullscreen native ad: the `AndroidNAConfig` passed to
 * `create("FULLSCREEN", ...)` and the `FullscreenShowOptions` passed to `show(activity, alias, json)`.
 */
internal fun parseFullscreenAdConfigJson(configJson: String, fallbackAdUnitId: String): FullscreenNativeAdConfig {
    val root = BridgeJsonReader(configJson).readRoot() as? Map<*, *>
        ?: throw IllegalArgumentException("Invalid fullscreen native config JSON")
    val ids = (root["ids"] as? List<*>).orEmpty()
        .mapNotNull { (it as? String)?.trim() }
        .filter { it.isNotEmpty() }
        .distinct()
    return FullscreenNativeAdConfig(
        ids = ids.ifEmpty { listOf(fallbackAdUnitId) },
        enableReloadAfterShow = root.boolean("autoReload", defaultValue = true),
    )
}

internal fun parseFullscreenShowOptionsJson(optionsJson: String?): FullscreenNativeAdShowOptions {
    if (optionsJson.isNullOrBlank()) return FullscreenNativeAdShowOptions()
    val root = BridgeJsonReader(optionsJson).readRoot() as? Map<*, *>
        ?: throw IllegalArgumentException("Invalid fullscreen native show options JSON")
    val layoutNames = (root["layoutNames"] as? List<*>).orEmpty()
        .mapNotNull { (it as? String)?.trim() }
        .filter { it.isNotEmpty() }
    val clickAssets = root["clickAssets"] as? Map<*, *>
    val assetVisibility = root["assetVisibility"] as? Map<*, *>
    val defaultClickAssets = NativeClickAssetOptions()
    val defaultVisibility = NativeAssetVisibilityOptions()
    return FullscreenNativeAdShowOptions(
        layoutName = layoutNames.firstOrNull() ?: FullscreenLayoutCatalog.SingleDefault,
        durationSeconds = root.number("duration") ?: 0.0,
        // The reference library has no auto close option; its Unity glue never asks for it.
        autoClose = false,
        pauseGameplay = root.boolean("pauseGameplay", defaultValue = true),
        mode = FullscreenNativeAdMode.fromName(root["mode"] as? String),
        layoutNames = layoutNames,
        durationsSeconds = (root["durations"] as? List<*>).orEmpty().mapNotNull { (it as? Number)?.toDouble() },
        orientation = (root["orientation"] as? String)?.takeIf { it.isNotBlank() } ?: "auto",
        enableAdComeback = root.boolean("enableAdComeback", defaultValue = true),
        showTCD = root.boolean("showTCD", defaultValue = true),
        delaySeconds = root.number("delay") ?: 0.0,
        timeUpCSeconds = root.number("timeUpC")?.toInt() ?: 0,
        clickAssets = NativeClickAssetOptions(
            cta = clickAssets.boolean("cta", defaultClickAssets.cta),
            headline = clickAssets.boolean("headline", defaultClickAssets.headline),
            body = clickAssets.boolean("body", defaultClickAssets.body),
            description = clickAssets.boolean("description", defaultClickAssets.description),
            icon = clickAssets.boolean("icon", defaultClickAssets.icon),
            advertiser = clickAssets.boolean("advertiser", defaultClickAssets.advertiser),
            media = clickAssets.boolean("media", defaultClickAssets.media),
            mediaImage = clickAssets.boolean("mediaImage", defaultClickAssets.mediaImage),
            mediaVideo = clickAssets.boolean("mediaVideo", defaultClickAssets.mediaVideo),
        ),
        assetVisibility = NativeAssetVisibilityOptions(
            cta = assetVisibility.boolean("cta", defaultVisibility.cta),
            headline = assetVisibility.boolean("headline", defaultVisibility.headline),
            body = assetVisibility.boolean("body", defaultVisibility.body),
            description = assetVisibility.boolean("description", defaultVisibility.description),
            icon = assetVisibility.boolean("icon", defaultVisibility.icon),
            advertiser = assetVisibility.boolean("advertiser", defaultVisibility.advertiser),
            media = assetVisibility.boolean("media", defaultVisibility.media),
            mediaImage = assetVisibility.boolean("mediaImage", defaultVisibility.mediaImage),
            mediaVideo = assetVisibility.boolean("mediaVideo", defaultVisibility.mediaVideo),
            price = assetVisibility.boolean("price", defaultVisibility.price),
            store = assetVisibility.boolean("store", defaultVisibility.store),
            starRating = assetVisibility.boolean("starRating", defaultVisibility.starRating),
        ),
    )
}

private fun Map<*, *>?.boolean(name: String, defaultValue: Boolean): Boolean =
    this?.get(name) as? Boolean ?: defaultValue

internal fun Map<*, *>.number(name: String): Double? =
    (this[name] as? Number)?.toDouble()
