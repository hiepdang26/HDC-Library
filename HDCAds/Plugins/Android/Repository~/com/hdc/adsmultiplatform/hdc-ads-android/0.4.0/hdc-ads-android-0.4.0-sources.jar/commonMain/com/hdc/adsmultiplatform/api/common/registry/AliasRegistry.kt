package com.hdc.adsmultiplatform.api.common.registry

import com.hdc.adsmultiplatform.platform.lock.AdsLock

/**
 * The entries and callbacks of a registry, per alias. [keyOf] maps an alias to the key it is stored under, e.g. a
 * blank alias to the default one. It can be used from any thread: on Android, Unity creates and queries from its own
 * thread while the ads report on the main thread. Entries are immutable and replaced whole by [update], so a reader
 * never sees half of a change; the registries call their callbacks after the change, outside the lock.
 */
internal class AliasRegistry<Entry : Any, Callback : Any>(
    private val newEntry: () -> Entry,
    private val keyOf: (String) -> String = { it },
) {
    private val lock = AdsLock()
    private val entries = mutableMapOf<String, Entry>()
    private val callbacks = mutableMapOf<String, Callback>()

    operator fun get(alias: String): Entry? = lock.locked { entries[keyOf(alias)] }

    operator fun set(alias: String, entry: Entry) {
        lock.locked { entries[keyOf(alias)] = entry }
    }

    /** The entry of [alias], a new one when there is none. */
    fun entry(alias: String): Entry = lock.locked { entries.getOrPut(keyOf(alias), newEntry) }

    /** The entry of [alias], made by [create] when there is none. */
    fun getOrPut(alias: String, create: () -> Entry): Entry =
        lock.locked { entries.getOrPut(keyOf(alias), create) }

    /** Replaces the entry of [alias] (a new one when there is none) with [transform] of it; returns the new entry. */
    fun update(alias: String, transform: (Entry) -> Entry): Entry =
        lock.locked {
            val key = keyOf(alias)
            transform(entries.getOrPut(key, newEntry)).also { entries[key] = it }
        }

    /** Like [update], only for an alias that has an entry; null otherwise. */
    fun updateIfPresent(alias: String, transform: (Entry) -> Entry): Entry? =
        lock.locked {
            val key = keyOf(alias)
            val current = entries[key] ?: return@locked null
            transform(current).also { entries[key] = it }
        }

    fun callback(alias: String): Callback? = lock.locked { callbacks[keyOf(alias)] }

    fun setCallback(alias: String, callback: Callback?) {
        lock.locked {
            val key = keyOf(alias)
            if (callback == null) callbacks.remove(key) else callbacks[key] = callback
        }
    }

    fun remove(alias: String) {
        lock.locked {
            val key = keyOf(alias)
            entries.remove(key)
            callbacks.remove(key)
        }
    }
}
