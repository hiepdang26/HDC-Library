@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.popup.viewmodel

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.api.popup.callback.PopupNativeAdCallback
import com.hdc.adsmultiplatform.api.popup.callback.PopupNativeAdRevenueCallback
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdError
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdInfo
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.common.viewmodel.NativeAdRotation
import com.hdc.adsmultiplatform.presentation.common.viewmodel.mapper.toPaidInfo
import com.hdc.adsmultiplatform.presentation.common.viewmodel.model.LoadedNativeAdTurn
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeCancellation
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeLoader
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeScheduler
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdDisplayState
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdShown
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdUiState
import com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy.layoutFor
import com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy.normalizedForPopupRuntime
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
class PopupNativeAdViewModel(
    private val alias: String,
    private val loader: AdRuntimeLoader,
    private val scheduler: AdRuntimeScheduler,
    private val callback: PopupNativeAdCallback = object : PopupNativeAdCallback {},
    private val revenueCallback: PopupNativeAdRevenueCallback? = null,
    private val onSnapshotChanged: (PopupNativeAdUiState) -> Unit = {},
) {
    private var config = PopupNativeAdConfig(ids = listOf(UnconfiguredAdUnitId))
    private var snapshot = PopupNativeAdUiState()
    private var pendingShowOnLoadSuccess = false
    private var reloadTimer: AdRuntimeCancellation? = null
    private var closeTimer: AdRuntimeCancellation? = null
    private val rotation = NativeAdRotation(
        alias = alias,
        formatKey = "popup",
        loader = loader,
        scheduler = scheduler,
        adUnitIds = { config.ids },
        events = object : NativeAdRotation.Events {
            override fun onLoading() = onRotationLoading()

            override fun onLoaded(turn: LoadedNativeAdTurn) = onTurnLoaded(turn)

            override fun onFailed(adUnitId: String, result: NativeAdLoadResult) = onTurnFailed(adUnitId, result)

            override fun onAdEvent(instanceId: String, event: NativeAdEvent) = onTurnEvent(instanceId, event)

            override fun onExpired(turn: LoadedNativeAdTurn) = onTurnExpired()
        },
    )

    fun configure(nextConfig: PopupNativeAdConfig) {
        val normalized = nextConfig.normalized()
        if (normalized == config) {
            return
        }
        // Close a visible popup the normal way first: the platform runtimes only take the view down on onClosed.
        if (snapshot.isVisible) {
            closeInternal()
        }
        cancelTimers()
        rotation.releaseReady()
        snapshot.activeInstanceId?.let(rotation::destroyInstance)
        rotation.restart()
        pendingShowOnLoadSuccess = false
        config = normalized
        publish(
            PopupNativeAdUiState(
                layoutName = config.layoutName,
                enableCtrOverlay = config.enableCtrOverlay,
            ),
        )
    }

    fun load() {
        pendingShowOnLoadSuccess = false
        rotation.requestNextTurn(reason = "manual")
    }

    fun isReady(): Boolean =
        snapshot.displayState == PopupNativeAdDisplayState.Loaded ||
            snapshot.displayState == PopupNativeAdDisplayState.Displayable ||
            snapshot.displayState == PopupNativeAdDisplayState.Showing ||
            hiddenInstanceId() != null

    fun isDisplayable(): Boolean =
        (snapshot.displayState == PopupNativeAdDisplayState.Displayable && rotation.hasReadyAd) ||
            hiddenInstanceId() != null

    fun isShowing(): Boolean =
        snapshot.displayState == PopupNativeAdDisplayState.Showing && snapshot.isVisible

    /** True while a request is in flight or a retry after a failed load is scheduled. */
    fun isLoading(): Boolean =
        rotation.isLoading

    fun displayableInstanceId(): String? =
        rotation.firstReady()?.instanceId ?: hiddenInstanceId()

    // The ad last shown, taken down by hide or its close button but still loaded: show puts it back up, as the reference library's
    // Android popup does, until a newer ad is loaded.
    private fun hiddenInstanceId(): String? =
        snapshot.activeInstanceId?.takeIf {
            snapshot.displayState == PopupNativeAdDisplayState.Closed &&
                !snapshot.isVisible &&
                snapshot.activeAdUnitId != null
        }

    fun stateName(): String =
        snapshot.displayState.name

    /** The layout and ad source of the ad on screen, or of the last one shown. */
    internal fun shownAd(): PopupNativeAdShown =
        PopupNativeAdShown(snapshot.layoutName, snapshot.activeAdSourceId, snapshot.activeAdSourceName)

    fun markShowFailed(message: String) {
        cancelCloseTimer()
        pendingShowOnLoadSuccess = false
        publish(
            snapshot.copy(
                state = NativeAdState.Failed,
                // An ad still waiting can be shown by the next show.
                displayState = if (rotation.hasReadyAd) {
                    PopupNativeAdDisplayState.Displayable
                } else {
                    PopupNativeAdDisplayState.Failed
                },
                isVisible = false,
                closeSecondsRemaining = 0,
                canClose = true,
            ),
        )
        callback.onFailedToLoad(
            PopupNativeAdError(
                alias = alias,
                adUnitId = snapshot.activeAdUnitId.orEmpty(),
                message = message,
            ),
        )
    }

    fun show() {
        if (isShowing()) {
            return
        }
        pendingShowOnLoadSuccess = true
        val ready = rotation.firstReady()
        if (ready != null) {
            showLoaded(ready)
            return
        }
        if (snapshot.activeInstanceId != null && snapshot.activeAdUnitId != null) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Shown,
                    displayState = PopupNativeAdDisplayState.Showing,
                    isVisible = true,
                    layoutName = config.layoutFor(snapshot.activeAdSourceId),
                    enableCtrOverlay = config.enableCtrOverlay,
                ),
            )
            callback.onDisplayed(currentInfo())
            callback.onOpened(currentInfo())
            restartCloseTimer()
            scheduleReload()
            return
        }
        // The load in flight shows its ad when it finishes. Another request would only fill the queue, and with
        // no free ad unit it scheduled a failure retry that loaded one more ad a few seconds later.
        if (rotation.loadingAdUnitIds.isNotEmpty()) {
            return
        }
        rotation.requestNextTurn(reason = "show")
    }

    fun close() {
        if (!snapshot.isVisible) {
            return
        }
        closeInternal()
    }

    fun hide() {
        // A hide before any show leaves a ready ad displayable; it only cancels a show waiting for its load.
        pendingShowOnLoadSuccess = false
        if (!snapshot.isVisible || snapshot.activeInstanceId == null) {
            return
        }
        closeInternal()
    }

    fun stop() {
        cancelTimers()
        pendingShowOnLoadSuccess = false
        publish(
            snapshot.copy(
                state = NativeAdState.onClosed,
                displayState = PopupNativeAdDisplayState.Closed,
                isVisible = false,
                closeSecondsRemaining = 0,
                canClose = true,
            ),
        )
    }

    fun destroy() {
        cancelTimers()
        rotation.releaseReady()
        snapshot.activeInstanceId?.let(rotation::destroyInstance)
        rotation.releaseLoading()
        rotation.clearFailures()
        pendingShowOnLoadSuccess = false
        publish(PopupNativeAdUiState(displayState = PopupNativeAdDisplayState.Destroyed))
    }

    private fun closeInternal() {
        cancelCloseTimer()
        cancelReloadTimer()
        // A load still in flight (reload or failure retry) must only refill the queue, not bring the popup back.
        pendingShowOnLoadSuccess = false
        val currentInfo = currentInfo()
        publish(
            snapshot.copy(
                state = NativeAdState.onClosed,
                displayState = PopupNativeAdDisplayState.Closed,
                isVisible = false,
                closeSecondsRemaining = 0,
                canClose = true,
            ),
        )
        callback.onClosed(currentInfo)
    }

    private fun onRotationLoading() {
        publish(
            snapshot.copy(
                state = NativeAdState.Loading,
                displayState = PopupNativeAdDisplayState.Loading,
            ),
        )
    }

    private fun onTurnLoaded(loaded: LoadedNativeAdTurn) {
        callback.onLoaded(loaded.info(config.layoutFor(loaded.adSourceId)))
        callback.onDisplayable(alias)
        publish(
            snapshot.copy(
                state = NativeAdState.Loaded,
                displayState = PopupNativeAdDisplayState.Displayable,
            ),
        )
        if (pendingShowOnLoadSuccess) {
            showLoaded(loaded)
        }
    }

    // A ready ad expired: the popup is no longer displayable unless another ad is ready.
    private fun onTurnExpired() {
        if (snapshot.displayState == PopupNativeAdDisplayState.Displayable && !rotation.hasReadyAd) {
            publish(snapshot.copy(state = NativeAdState.Idle, displayState = PopupNativeAdDisplayState.NotLoaded))
        }
    }

    // What an ad reports once it is up; only the ad on screen can be seen, clicked or paid for.
    private fun onTurnEvent(instanceId: String, event: NativeAdEvent) {
        if (instanceId != snapshot.activeInstanceId) {
            return
        }
        when (event) {
            NativeAdEvent.Clicked -> callback.onClicked(currentInfo())
            NativeAdEvent.Impression -> revenueCallback?.onImpression(currentInfo())
            is NativeAdEvent.Paid -> revenueCallback?.onPaidImpression(currentInfo(), event.toPaidInfo(snapshot.activeAdUnitId.orEmpty()))
            NativeAdEvent.Opened -> Unit
        }
    }

    private fun onTurnFailed(failedAdUnitId: String, result: NativeAdLoadResult) {
        callback.onFailedToLoad(
            PopupNativeAdError(
                alias = alias,
                adUnitId = failedAdUnitId,
                code = result.code,
                message = result.message.ifBlank { "Popup native ad failed to load" },
            ),
        )
        publish(
            snapshot.copy(
                state = NativeAdState.Failed,
                displayState = PopupNativeAdDisplayState.Failed,
            ),
        )
    }

    private fun showLoaded(loaded: LoadedNativeAdTurn) {
        rotation.takeReady(loaded)
        val previousInstanceId = snapshot.activeInstanceId
        val layoutName = config.layoutFor(loaded.adSourceId)
        val nextSnapshot = snapshot.copy(
            state = NativeAdState.Shown,
            displayState = PopupNativeAdDisplayState.Showing,
            isVisible = true,
            activeInstanceId = loaded.instanceId,
            activeAdUnitId = loaded.adUnitId,
            activeAdSourceId = loaded.adSourceId,
            activeAdSourceName = loaded.adSourceName,
            layoutName = layoutName,
            enableCtrOverlay = config.enableCtrOverlay,
            closeSecondsRemaining = config.timeShowSeconds,
            canClose = config.timeShowSeconds == 0,
        )
        publish(nextSnapshot)
        callback.onDisplayed(loaded.info(layoutName))
        callback.onOpened(loaded.info(layoutName))
        if (previousInstanceId != null && previousInstanceId != loaded.instanceId) {
            rotation.destroyInstance(previousInstanceId)
        }
        restartCloseTimer()
        scheduleReload()
    }

    private fun restartCloseTimer() {
        cancelCloseTimer()
        val seconds = config.timeShowSeconds.coerceAtLeast(0)
        if (!snapshot.isVisible || seconds == 0) {
            publish(snapshot.copy(closeSecondsRemaining = 0, canClose = true))
            return
        }
        publish(snapshot.copy(closeSecondsRemaining = seconds, canClose = false))
        scheduleCloseTick(seconds)
    }

    private fun scheduleCloseTick(totalSeconds: Int) {
        closeTimer = scheduler.schedule(1_000L) {
            closeTimer = null
            if (!snapshot.isVisible) {
                return@schedule
            }
            val remaining = (snapshot.closeSecondsRemaining - 1).coerceAtLeast(0)
            publish(snapshot.copy(closeSecondsRemaining = remaining, canClose = remaining == 0))
            if (remaining > 0) {
                scheduleCloseTick(totalSeconds)
            } else if (config.autoClose) {
                closeInternal()
            }
        }
    }

    private fun scheduleReload() {
        cancelReloadTimer()
        val seconds = config.timeReloadSeconds
        if (!snapshot.isVisible || seconds <= 0) {
            return
        }
        reloadTimer = scheduler.schedule(seconds * 1_000L) {
            reloadTimer = null
            if (snapshot.isVisible) {
                pendingShowOnLoadSuccess = true
                rotation.requestNextTurn(reason = "timeReload")
            }
        }
    }

    private fun currentInfo(): PopupNativeAdInfo =
        PopupNativeAdInfo(
            alias = alias,
            instanceId = snapshot.activeInstanceId.orEmpty(),
            adUnitId = snapshot.activeAdUnitId.orEmpty(),
            layoutName = snapshot.layoutName,
        )

    private fun LoadedNativeAdTurn.info(layoutName: String): PopupNativeAdInfo =
        PopupNativeAdInfo(alias, instanceId, adUnitId, layoutName)

    private fun publish(nextSnapshot: PopupNativeAdUiState) {
        snapshot = nextSnapshot
        onSnapshotChanged(nextSnapshot)
    }

    private fun cancelTimers() {
        cancelReloadTimer()
        cancelCloseTimer()
        rotation.cancelFailureRetry()
    }

    private fun cancelReloadTimer() {
        reloadTimer?.cancel()
        reloadTimer = null
    }

    private fun cancelCloseTimer() {
        closeTimer?.cancel()
        closeTimer = null
    }

    private fun PopupNativeAdConfig.normalized(): PopupNativeAdConfig =
        normalizedForPopupRuntime()
}
