package com.hdc.adsmultiplatform.unity.gameplay

import android.app.Activity
import java.lang.reflect.Field

/** The Unity player's current activity, read through reflection so the library does not depend on Unity. */
internal object HdcUnityActivity {
    private val currentActivityField: Field? by lazy {
        runCatching { Class.forName("com.unity3d.player.UnityPlayer").getField("currentActivity") }.getOrNull()
    }

    fun current(): Activity? = runCatching { currentActivityField?.get(null) as? Activity }.getOrNull()

    fun require(): Activity = current() ?: error("Unity activity is not available")
}
