package com.hdc.adsmultiplatform.presentation.fullscreen.state

data class FullscreenNativeAdControlState(
    val remainingSeconds: Int,
    val canClose: Boolean,
    val showCountdown: Boolean = remainingSeconds > 0 && !canClose,
    val phase: FullscreenNativeAdControlPhase = if (canClose) {
        FullscreenNativeAdControlPhase.FINISHED
    } else {
        FullscreenNativeAdControlPhase.PROGRESS
    },
    val closeStyle: FullscreenNativeAdCloseStyle = FullscreenNativeAdCloseStyle.STANDARD,
    val progress: Float = if (canClose) 1f else 0f,
    val showProgress: Boolean = false,
    val showOpenStoreButton: Boolean = false,
    val showCloseButton: Boolean = canClose,
    val closeButtonEnabled: Boolean = canClose,
    val closeButtonAlpha: Float = if (canClose) 1f else 0.35f,
)
