package com.hdc.adsmultiplatform.presentation.fullscreen.state.timeline

import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.NativeAdLayoutNames

/** The layouts a fullscreen overlay shows, in order: [layoutNames], or [layoutName] alone, normalized. */
internal fun normalizeOverlayLayoutNames(
    layoutName: String,
    layoutNames: List<String>,
    keepDuplicates: Boolean,
): List<String> {
    val candidates = layoutNames.ifEmpty { listOf(layoutName) }
    val normalized = candidates
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .map { NativeAdLayoutNames.normalize(it) }
    return if (keepDuplicates) normalized else normalized.distinct()
}

/** How long a sequence of [layoutCount] layouts runs; a layout past the end of [durationsSeconds] takes the last. */
internal fun sequenceTotalDurationSeconds(layoutCount: Int, durationsSeconds: List<Double>): Double {
    if (durationsSeconds.isEmpty()) {
        return 0.0
    }

    return (0 until layoutCount).sumOf { index ->
        durationsSeconds.getOrElse(index) { durationsSeconds.last() }
    }
}
