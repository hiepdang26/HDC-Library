package com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port

import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState

/** Where the fullscreen flow reports to the game: state changes and the load, display and close callbacks. */
internal interface FullscreenNativeAdEvents {
    fun onStateChanged(instanceId: String, state: NativeAdState)

    fun onLoadResult(instanceId: String, result: NativeAdLoadResult)

    fun onDisplayed(instanceId: String)

    fun onClosed(instanceId: String)
}
