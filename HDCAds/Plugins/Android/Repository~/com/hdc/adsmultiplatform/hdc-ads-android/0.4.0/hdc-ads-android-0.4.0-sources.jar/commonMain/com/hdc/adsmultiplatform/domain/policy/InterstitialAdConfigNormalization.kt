package com.hdc.adsmultiplatform.domain.policy

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig

internal fun InterstitialAdConfig.normalized(fallbackAdUnitId: String): InterstitialAdConfig =
    copy(
        ids = ids.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(fallbackAdUnitId) },
        preloadBufferSize = preloadBufferSize.coerceAtLeast(1),
    )
