package com.hdc.adsmultiplatform.platform.clock

import android.os.SystemClock

internal actual fun elapsedRealtimeMillis(): Long = SystemClock.elapsedRealtime()
