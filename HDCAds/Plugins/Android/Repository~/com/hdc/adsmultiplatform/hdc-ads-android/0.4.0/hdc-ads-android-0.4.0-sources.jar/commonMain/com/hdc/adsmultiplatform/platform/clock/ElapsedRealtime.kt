package com.hdc.adsmultiplatform.platform.clock

/**
 * Milliseconds of real time that keep counting while the device sleeps, as the networks count the age of an ad.
 * Only differences between two readings mean something.
 */
internal expect fun elapsedRealtimeMillis(): Long
