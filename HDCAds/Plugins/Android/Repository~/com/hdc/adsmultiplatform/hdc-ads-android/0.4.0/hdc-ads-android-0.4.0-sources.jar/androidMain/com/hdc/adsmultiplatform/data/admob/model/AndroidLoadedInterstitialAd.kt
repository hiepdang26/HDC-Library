package com.hdc.adsmultiplatform.data.admob.model

import com.google.android.gms.ads.interstitial.InterstitialAd
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdInfo

internal data class AndroidLoadedInterstitialAd(
    val ad: InterstitialAd,
    val info: InterstitialAdInfo,
)
