package com.hdc.adsmultiplatform.unity.command

import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.log.HdcLog

/** Routes a bridge command (`"<format>.<action>"`) to its handler. */
internal object HdcCommands {
    fun execute(method: String, args: HdcArgs): Any? {
        HdcLog.debug("call $method")
        return when (method) {
            "init" -> HdcSdkCommands.initialize(args)
            "interstitial.load" -> HdcInterstitialCommands.load(args)
            "interstitial.show" -> HdcInterstitialCommands.show(args)
            "interstitial.isReady" -> HdcInterstitialCommands.isReady(args)
            "interstitial.destroy" -> HdcInterstitialCommands.destroy(args)
            "fullscreen.load" -> HdcFullscreenCommands.load(args)
            "fullscreen.show" -> HdcFullscreenCommands.show(args)
            "fullscreen.hide" -> HdcFullscreenCommands.hide(args)
            "fullscreen.isReady" -> HdcFullscreenCommands.isReady(args)
            "fullscreen.destroy" -> HdcFullscreenCommands.destroy(args)
            "popup.load" -> HdcPopupCommands.load(args)
            "popup.updatePlacement" -> HdcPopupCommands.updatePlacement(args)
            "popup.show" -> HdcPopupCommands.show(args)
            "popup.close" -> HdcPopupCommands.close(args)
            "popup.hide" -> HdcPopupCommands.hide(args)
            "popup.stop" -> HdcPopupCommands.stop(args)
            "popup.destroy" -> HdcPopupCommands.destroy(args)
            "popup.isReady" -> HdcPopupCommands.isReady(args)
            "popup.isDisplayable" -> HdcPopupCommands.isDisplayable(args)
            "popup.state" -> HdcPopupCommands.state(args)
            "banner.load" -> HdcBannerCommands.load(args)
            "banner.show" -> HdcBannerCommands.show(args)
            "banner.hide" -> HdcBannerCommands.hide(args)
            "banner.expand" -> HdcBannerCommands.expand(args)
            "banner.collapse" -> HdcBannerCommands.collapse(args)
            "banner.destroy" -> HdcBannerCommands.destroy(args)
            "meta.enableTestMode" -> HdcMetaCommands.enableTestMode(args)
            "meta.disableTestMode" -> HdcMetaCommands.disableTestMode()
            "meta.isTestMode" -> HdcMetaCommands.isTestMode()
            "meta.deviceHash" -> HdcMetaCommands.deviceHash()
            else -> throw IllegalArgumentException("Unknown method: $method")
        }
    }
}
