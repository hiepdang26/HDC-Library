package com.hdc.adsmultiplatform.domain.repository

/** Records that the user clicked or opened a fullscreen native ad, so the ad can close when they come back. */
internal fun interface FullscreenAdInteractions {
    fun markInteraction(instanceId: String)
}
