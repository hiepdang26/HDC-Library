package com.hdc.adsmultiplatform.api.interstitial.callback

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdInfo
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdPaidInfo

interface InterstitialAdCallback {
    fun onInterstitialLoaded(ad: InterstitialAdInfo) = Unit
    fun onInterstitialDisplayed(ad: InterstitialAdInfo) = Unit
    fun onInterstitialImpression(ad: InterstitialAdInfo) = Unit
    fun onInterstitialOpened(ad: InterstitialAdInfo) = Unit
    fun onInterstitialClosed(ad: InterstitialAdInfo) = Unit
    fun onInterstitialClicked(ad: InterstitialAdInfo) = Unit
    fun onInterstitialFailedToLoad(adUnit: String, errorCode: Int, error: String) = Unit

    /** A show that failed. By default it goes to [onInterstitialFailedToLoad], which used to hear show failures too. */
    fun onInterstitialFailedToShow(adUnit: String, errorCode: Int, error: String) =
        onInterstitialFailedToLoad(adUnit, errorCode, error)
    fun onInterstitialPaidImpression(ad: InterstitialAdInfo, paidInfo: InterstitialAdPaidInfo) = Unit
    fun onInterstitialDisplayable() = Unit
}
