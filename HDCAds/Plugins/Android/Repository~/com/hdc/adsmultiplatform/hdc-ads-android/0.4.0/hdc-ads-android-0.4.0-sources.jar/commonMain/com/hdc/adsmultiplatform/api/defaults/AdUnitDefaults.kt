package com.hdc.adsmultiplatform.api.defaults

expect fun defaultNativeAdUnitId(): String

expect fun defaultNativeVideoAdUnitId(): String
