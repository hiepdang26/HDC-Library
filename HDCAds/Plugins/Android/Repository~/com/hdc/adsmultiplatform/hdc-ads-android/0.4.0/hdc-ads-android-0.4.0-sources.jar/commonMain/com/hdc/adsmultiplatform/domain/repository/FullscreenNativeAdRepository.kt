package com.hdc.adsmultiplatform.domain.repository

import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult

/**
 * The fullscreen native ad of each instance: the requests, the loaded ad and its age. [Host] is what a platform
 * loads from: an Android `Context`, an iOS `UIViewController`.
 */
internal interface FullscreenNativeAdRepository<Host : Any> {
    /**
     * Loads [adUnitIds] in order until one fills. [retryOnFailure] retries the whole waterfall in the background
     * after it fails.
     */
    fun loadFullscreen(
        host: Host,
        instanceId: String,
        adUnitIds: List<String>,
        retryOnFailure: Boolean,
        callback: (NativeAdLoadResult) -> Unit,
    )

    fun hasLoadedAd(instanceId: String): Boolean

    fun loadedAdUnitId(instanceId: String): String?

    /** Ad unit ids the latest request for [instanceId] was made with. */
    fun requestedAdUnitIds(instanceId: String): List<String>

    /** A request for [instanceId] is waiting for its result. */
    fun isLoading(instanceId: String): Boolean

    /** Seconds since the loaded ad of [instanceId] arrived, or null without one. */
    fun loadedAdAgeSeconds(instanceId: String): Double?

    fun clearLoaded(instanceId: String)

    fun destroy(instanceId: String)
}
