package com.hdc.adsmultiplatform.api.popup.model

data class PopupNativeAdError(
    val alias: String,
    val adUnitId: String,
    val code: Int = -1,
    val message: String,
)
