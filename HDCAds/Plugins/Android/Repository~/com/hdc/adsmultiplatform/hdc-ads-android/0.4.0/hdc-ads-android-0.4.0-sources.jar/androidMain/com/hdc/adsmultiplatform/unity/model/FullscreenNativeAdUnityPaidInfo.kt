package com.hdc.adsmultiplatform.unity.model

/** Paid impression value as the reference library's Unity glue reads it (`getRevenueMicros()`, `getCurrencyCode()`). */
data class FullscreenNativeAdUnityPaidInfo(
    val adUnitId: String,
    val revenueMicros: Long,
    val currencyCode: String?,
    val mediationAdapter: String?,
    val adSource: String?,
    val responseId: String?,
)
