package com.hdc.adsmultiplatform.api.fullscreen.model

data class NativeAssetVisibilityOptions(
    val cta: Boolean = true,
    val headline: Boolean = true,
    val body: Boolean = true,
    val description: Boolean = true,
    val icon: Boolean = true,
    val advertiser: Boolean = true,
    val media: Boolean = true,
    val mediaImage: Boolean = true,
    val mediaVideo: Boolean = true,
    val price: Boolean = true,
    val store: Boolean = true,
    val starRating: Boolean = true,
) {
    val bodyOrDescriptionVisible: Boolean
        get() = body || description

    val mediaImageVisible: Boolean
        get() = media && mediaImage

    val mediaVideoVisible: Boolean
        get() = media && mediaVideo

    val anyMediaVisible: Boolean
        get() = mediaImageVisible || mediaVideoVisible
}
