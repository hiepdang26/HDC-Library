package com.hdc.adsmultiplatform.di

import org.koin.core.Koin
import org.koin.core.KoinApplication
import org.koin.core.module.Module
import org.koin.dsl.koinApplication

/**
 * The library's own Koin container. It never calls `startKoin`, so it stays apart from any Koin the app or the game
 * starts, as Koin advises for libraries. Each definition is created on first use, like the singletons it replaced.
 */
internal object AdsKoin {
    private val application: KoinApplication by lazy { koinApplication { modules(adsModules()) } }

    val koin: Koin
        get() = application.koin
}

/** The Koin modules of this platform: the ad network plug-in, the screens and the Unity adapter. */
internal expect fun adsModules(): List<Module>

/** Gets [T] from the library's container, for entry points the container does not create (public SDK objects, composables). */
internal inline fun <reified T : Any> adsGet(): T = AdsKoin.koin.get()
