package com.hdc.adsmultiplatform.data.admob.repository

import android.app.Activity
import android.os.Looper
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdValue
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnPaidEventListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.hdc.adsmultiplatform.api.event.center.AdTrackingEvents
import com.hdc.adsmultiplatform.api.event.model.AdTrackingEvent
import com.hdc.adsmultiplatform.api.event.model.AdTrackingEventNames
import com.hdc.adsmultiplatform.api.interstitial.defaults.DefaultInterstitialAdInstanceId
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdInfo
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdPaidInfo
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.api.interstitial.registry.InterstitialAdRegistry
import com.hdc.adsmultiplatform.data.admob.config.AdMobAndroidTestAdUnits
import com.hdc.adsmultiplatform.data.admob.model.AndroidInterstitialSlot
import com.hdc.adsmultiplatform.data.admob.model.AndroidLoadedInterstitialAd
import com.hdc.adsmultiplatform.data.source.AndroidInterstitialAdSource
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.domain.policy.NoAdUnitConfiguredMessage
import com.hdc.adsmultiplatform.domain.policy.normalized
import com.hdc.adsmultiplatform.domain.policy.resolveAdUnitIds
import com.hdc.adsmultiplatform.platform.android.thread.runOnMainThread
import com.hdc.adsmultiplatform.platform.build.DevelopmentBuild
import java.util.concurrent.ConcurrentHashMap

/** AdMob (Google Mobile Ads) interstitial ads per alias, with a buffer of loaded ads to show from. */
internal class AndroidInterstitialAdRepository : AndroidInterstitialAdSource {
    private val slots = ConcurrentHashMap<String, AndroidInterstitialSlot>()

    override fun configure(alias: String, config: InterstitialAdConfig) {
        runOnMainThread {
            val normalizedAlias = alias.normalizedInterstitialAlias()
            val normalizedConfig = config.normalized(UnconfiguredAdUnitId).resolved()
            val slot = slots.getOrPut(normalizedAlias) { AndroidInterstitialSlot() }
            if (slot.reconfigure(normalizedConfig)) {
                slot.isShowing = false
            }
        }
    }

    override fun loadWithResult(
        activity: Activity,
        alias: String,
        bufferSize: Int,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        runOnMainThread {
            DevelopmentBuild.learn(activity)
            val normalizedAlias = alias.normalizedInterstitialAlias()
            val registryConfig = InterstitialAdRegistry
                .configFor(normalizedAlias, UnconfiguredAdUnitId)
                .copy(preloadBufferSize = bufferSize.coerceAtLeast(1))
                .normalized(UnconfiguredAdUnitId)
                .resolved()
            if (registryConfig.ids.isEmpty()) {
                InterstitialAdRegistry.notifyFailedToLoad(
                    alias = normalizedAlias,
                    adUnit = "",
                    errorCode = NativeAdLoadResult.NoErrorCode,
                    error = NoAdUnitConfiguredMessage,
                )
                callback(NativeAdLoadResult(state = NativeAdState.Failed, message = NoAdUnitConfiguredMessage))
                return@runOnMainThread
            }
            val slot = slots.getOrPut(normalizedAlias) { AndroidInterstitialSlot() }
            slot.reconfigure(registryConfig)
            InterstitialAdRegistry.create(normalizedAlias, registryConfig)
            InterstitialAdRegistry.notifyLoading(normalizedAlias)
            callback(
                NativeAdLoadResult(
                    state = NativeAdState.Loading,
                    adUnitId = registryConfig.ids.firstOrNull().orEmpty(),
                ),
            )

            MobileAds.initialize(activity.applicationContext)
            slot.fill { adUnitId, version ->
                loadOne(activity, normalizedAlias, slot, adUnitId, version, callback)
            }
        }
    }

    override fun show(activity: Activity, alias: String, options: InterstitialShowOptions): Boolean {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnMainThread { show(activity, alias, options) }
            return true
        }
        val normalizedAlias = alias.normalizedInterstitialAlias()
        val slot = slots[normalizedAlias]
        if (slot == null || slot.isShowing) {
            InterstitialAdRegistry.notifyFailedToShow(
                alias = normalizedAlias,
                adUnit = "",
                errorCode = NativeAdLoadResult.NoErrorCode,
                error = if (slot?.isShowing == true) "Interstitial is already showing" else "Interstitial not ready. Load first",
            )
            return false
        }
        val loaded = slot.pollReadyAd()
        if (loaded == null) {
            InterstitialAdRegistry.notifyFailedToShow(
                alias = normalizedAlias,
                adUnit = "",
                errorCode = NativeAdLoadResult.NoErrorCode,
                error = "Interstitial not ready. Load first",
            )
            return false
        }

        slot.isShowing = true
        loaded.ad.setImmersiveMode(options.immersiveMode)
        loaded.ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                InterstitialAdRegistry.notifyDisplayed(normalizedAlias, loaded.info)
                InterstitialAdRegistry.notifyOpened(normalizedAlias, loaded.info)
            }

            override fun onAdImpression() {
                InterstitialAdRegistry.notifyImpression(normalizedAlias, loaded.info)
                loaded.info.track(normalizedAlias, AdTrackingEventNames.Impression)
            }

            override fun onAdClicked() {
                InterstitialAdRegistry.notifyClicked(normalizedAlias, loaded.info)
                loaded.info.track(normalizedAlias, AdTrackingEventNames.Clicked)
            }

            override fun onAdDismissedFullScreenContent() {
                loaded.ad.fullScreenContentCallback = null
                slot.isShowing = false
                InterstitialAdRegistry.notifyClosed(normalizedAlias, loaded.info)
                if (slot.config.autoReload) {
                    loadWithResult(activity, normalizedAlias, slot.config.preloadBufferSize) {}
                }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                loaded.ad.fullScreenContentCallback = null
                slot.isShowing = false
                InterstitialAdRegistry.notifyFailedToShow(
                    alias = normalizedAlias,
                    adUnit = loaded.info.adUnitId,
                    errorCode = adError.code,
                    error = adError.message,
                )
                if (slot.config.autoReload) {
                    loadWithResult(activity, normalizedAlias, slot.config.preloadBufferSize) {}
                }
            }
        }
        loaded.ad.show(activity)
        return true
    }

    override fun destroy(alias: String) {
        runOnMainThread {
            slots.remove(alias.normalizedInterstitialAlias())
        }
    }

    override fun isReady(alias: String): Boolean {
        val slot = slots[alias.normalizedInterstitialAlias()] ?: return false
        return !slot.isShowing && slot.hasReadyAd()
    }

    private fun loadOne(
        activity: Activity,
        alias: String,
        slot: AndroidInterstitialSlot,
        adUnitId: String,
        version: Int,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        InterstitialAd.load(
            activity,
            adUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    if (!slot.finishLoad(adUnitId, version)) {
                        return
                    }
                    val info = interstitialAd.toInterstitialInfo(adUnitId)
                    interstitialAd.onPaidEventListener = OnPaidEventListener { adValue ->
                        InterstitialAdRegistry.notifyPaidImpression(
                            alias = alias,
                            ad = info,
                            paidInfo = InterstitialAdPaidInfo(
                                adUnitId = info.adUnitId,
                                revenueMicros = adValue.valueMicros,
                                currencyCode = adValue.currencyCode,
                                mediationAdapter = info.mediationAdapter,
                                adSource = info.adSource,
                                responseId = info.responseId,
                                precision = adValue.precisionType,
                            ),
                        )
                        info.track(alias, AdTrackingEventNames.Paid, adValue)
                    }
                    slot.enqueue(adUnitId, AndroidLoadedInterstitialAd(interstitialAd, info))
                    InterstitialAdRegistry.notifyLoaded(alias, info)
                    callback(NativeAdLoadResult(state = NativeAdState.Loaded, adUnitId = adUnitId))
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    if (!slot.finishLoad(adUnitId, version)) {
                        return
                    }
                    InterstitialAdRegistry.notifyFailedToLoad(
                        alias = alias,
                        adUnit = adUnitId,
                        errorCode = error.code,
                        error = error.message,
                    )
                    callback(
                        NativeAdLoadResult(
                            state = NativeAdState.Failed,
                            adUnitId = adUnitId,
                            code = error.code,
                            message = error.message,
                        ),
                    )
                }
            },
        )
    }

}

private fun InterstitialAd.toInterstitialInfo(adUnitId: String): InterstitialAdInfo {
    val response = responseInfo
    val loadedAdapter = response.loadedAdapterResponseInfo
    return InterstitialAdInfo(
        adUnitId = adUnitId,
        mediationAdapter = response.mediationAdapterClassName.orEmpty(),
        responseId = response.responseId.orEmpty(),
        adSource = loadedAdapter?.adSourceName,
    )
}

private const val InterstitialAdEventFormat = "interstitial"

// Impression, click and paid events of every format go to the tracking stream too, for the HDCLib bridge.
private fun InterstitialAdInfo.track(alias: String, name: String, value: AdValue? = null) {
    AdTrackingEvents.emit(
        AdTrackingEvent(
            instanceId = alias,
            format = InterstitialAdEventFormat,
            name = name,
            adUnitId = adUnitId,
            valueMicros = value?.valueMicros ?: 0L,
            currencyCode = value?.currencyCode.orEmpty(),
            precision = value?.precisionType ?: 0,
            adSourceName = adSource.orEmpty(),
            mediationAdapter = mediationAdapter,
            responseId = responseId,
        ),
    )
}

private fun String.normalizedInterstitialAlias(): String =
    ifBlank { DefaultInterstitialAdInstanceId }

private fun InterstitialAdConfig.resolved(): InterstitialAdConfig =
    copy(ids = resolveAdUnitIds(ids, AdMobAndroidTestAdUnits.interstitial, isDevelopment = DevelopmentBuild.isDevelopment != false))
