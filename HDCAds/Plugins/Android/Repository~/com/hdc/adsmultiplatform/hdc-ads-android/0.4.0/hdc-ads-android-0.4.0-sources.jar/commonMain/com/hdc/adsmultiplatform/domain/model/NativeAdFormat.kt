package com.hdc.adsmultiplatform.domain.model

internal data class NativeAdFormat(val key: String)
