package com.hdc.adsmultiplatform.unity.bridge

import android.app.Activity
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdMode
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeAssetVisibilityOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeClickAssetOptions
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.defaults.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.parser.splitListEntries
import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.AndroidFullscreenNativeAdWindow

object NativeAdUnityBridge {
    @JvmStatic
    @JvmOverloads
    fun load(activity: Activity, adUnitId: String = UnconfiguredAdUnitId) {
        loadFullscreen(activity, DefaultNativeAdInstanceId, adUnitId)
    }

    @JvmStatic
    @JvmOverloads
    fun loadFullscreen(
        activity: Activity,
        instanceId: String = DefaultNativeAdInstanceId,
        adUnitIdsCsv: String = UnconfiguredAdUnitId,
        enableReloadAfterShow: Boolean = true,
    ) {
        adsGet<AndroidFullscreenNativeAdWindow>().load(
            activity = activity,
            instanceId = instanceId,
            adUnitIdsCsv = adUnitIdsCsv,
            enableReloadAfterShow = enableReloadAfterShow,
        )
    }
    @JvmStatic
    @JvmOverloads
    fun show(activity: Activity, adUnitId: String = UnconfiguredAdUnitId) {
        showFullscreen(
            activity = activity,
            instanceId = DefaultNativeAdInstanceId,
            layoutName = FullscreenLayoutCatalog.SingleDefault,
            durationSeconds = 0.0,
            fallbackAdUnitId = adUnitId,
        )
    }

    @JvmStatic
    @JvmOverloads
    fun showFullscreen(
        activity: Activity,
        instanceId: String = DefaultNativeAdInstanceId,
        layoutName: String = FullscreenLayoutCatalog.SingleDefault,
        durationSeconds: Double = 0.0,
        fallbackAdUnitId: String = UnconfiguredAdUnitId,
        autoClose: Boolean = false,
        pauseGameplay: Boolean = true,
        enableAdComeback: Boolean = true,
        showTCD: Boolean = true,
        delaySeconds: Double = 0.0,
        clickAssets: NativeClickAssetOptions = NativeClickAssetOptions(),
        assetVisibility: NativeAssetVisibilityOptions = NativeAssetVisibilityOptions(),
    ) {
        showFullscreen(
            activity = activity,
            instanceId = instanceId,
            options = FullscreenNativeAdShowOptions(
                layoutName = layoutName,
                durationSeconds = durationSeconds,
                autoClose = autoClose,
                pauseGameplay = pauseGameplay,
                enableAdComeback = enableAdComeback,
                showTCD = showTCD,
                delaySeconds = delaySeconds,
                clickAssets = clickAssets,
                assetVisibility = assetVisibility,
            ),
            fallbackAdUnitId = fallbackAdUnitId,
        )
    }

    @JvmStatic
    fun showFullscreen(
        activity: Activity,
        instanceId: String = DefaultNativeAdInstanceId,
        options: FullscreenNativeAdShowOptions = FullscreenNativeAdShowOptions(),
        fallbackAdUnitId: String = UnconfiguredAdUnitId,
    ) {
        adsGet<AndroidFullscreenNativeAdWindow>().show(
            activity = activity,
            instanceId = instanceId,
            options = options,
            fallbackAdUnitId = fallbackAdUnitId,
        )
    }

    @JvmStatic
    fun showFullscreenWithOptions(
        activity: Activity,
        instanceId: String,
        mode: String,
        layoutNamesCsv: String,
        durationSeconds: Double,
        durationsSecondsCsv: String,
        orientation: String,
        autoClose: Boolean,
        pauseGameplay: Boolean,
        enableAdComeback: Boolean,
        showTCD: Boolean,
        delaySeconds: Double,
        timeUpCSeconds: Int,
        fallbackAdUnitId: String,
        cta: Boolean,
        headline: Boolean,
        body: Boolean,
        description: Boolean,
        icon: Boolean,
        advertiser: Boolean,
        media: Boolean,
        mediaImage: Boolean,
        mediaVideo: Boolean,
    ) {
        showFullscreen(
            activity = activity,
            instanceId = instanceId,
            options = FullscreenNativeAdShowOptions(
                layoutName = firstLayoutName(layoutNamesCsv),
                durationSeconds = durationSeconds,
                autoClose = autoClose,
                pauseGameplay = pauseGameplay,
                mode = FullscreenNativeAdMode.fromName(mode),
                layoutNames = parseLayoutNamesCsv(layoutNamesCsv),
                durationsSeconds = parseDurationsSecondsCsv(durationsSecondsCsv),
                orientation = orientation.ifBlank { "auto" },
                enableAdComeback = enableAdComeback,
                showTCD = showTCD,
                delaySeconds = delaySeconds,
                timeUpCSeconds = timeUpCSeconds,
                clickAssets = NativeClickAssetOptions(
                    cta = cta,
                    headline = headline,
                    body = body,
                    description = description,
                    icon = icon,
                    advertiser = advertiser,
                    media = media,
                    mediaImage = mediaImage,
                    mediaVideo = mediaVideo,
                ),
                assetVisibility = NativeAssetVisibilityOptions(),
            ),
            fallbackAdUnitId = fallbackAdUnitId,
        )
    }

    @JvmStatic
    fun showFullscreenWithOptionsAndAssetVisibility(
        activity: Activity,
        instanceId: String,
        mode: String,
        layoutNamesCsv: String,
        durationSeconds: Double,
        durationsSecondsCsv: String,
        orientation: String,
        autoClose: Boolean,
        pauseGameplay: Boolean,
        enableAdComeback: Boolean,
        showTCD: Boolean,
        delaySeconds: Double,
        timeUpCSeconds: Int,
        fallbackAdUnitId: String,
        cta: Boolean,
        headline: Boolean,
        body: Boolean,
        description: Boolean,
        icon: Boolean,
        advertiser: Boolean,
        media: Boolean,
        mediaImage: Boolean,
        mediaVideo: Boolean,
        assetCta: Boolean,
        assetHeadline: Boolean,
        assetBody: Boolean,
        assetDescription: Boolean,
        assetIcon: Boolean,
        assetAdvertiser: Boolean,
        assetMedia: Boolean,
        assetMediaImage: Boolean,
        assetMediaVideo: Boolean,
        assetPrice: Boolean,
        assetStore: Boolean,
        assetStarRating: Boolean,
    ) {
        showFullscreen(
            activity = activity,
            instanceId = instanceId,
            options = FullscreenNativeAdShowOptions(
                layoutName = firstLayoutName(layoutNamesCsv),
                durationSeconds = durationSeconds,
                autoClose = autoClose,
                pauseGameplay = pauseGameplay,
                mode = FullscreenNativeAdMode.fromName(mode),
                layoutNames = parseLayoutNamesCsv(layoutNamesCsv),
                durationsSeconds = parseDurationsSecondsCsv(durationsSecondsCsv),
                orientation = orientation.ifBlank { "auto" },
                enableAdComeback = enableAdComeback,
                showTCD = showTCD,
                delaySeconds = delaySeconds,
                timeUpCSeconds = timeUpCSeconds,
                clickAssets = NativeClickAssetOptions(
                    cta = cta,
                    headline = headline,
                    body = body,
                    description = description,
                    icon = icon,
                    advertiser = advertiser,
                    media = media,
                    mediaImage = mediaImage,
                    mediaVideo = mediaVideo,
                ),
                assetVisibility = NativeAssetVisibilityOptions(
                    cta = assetCta,
                    headline = assetHeadline,
                    body = assetBody,
                    description = assetDescription,
                    icon = assetIcon,
                    advertiser = assetAdvertiser,
                    media = assetMedia,
                    mediaImage = assetMediaImage,
                    mediaVideo = assetMediaVideo,
                    price = assetPrice,
                    store = assetStore,
                    starRating = assetStarRating,
                ),
            ),
            fallbackAdUnitId = fallbackAdUnitId,
        )
    }

    @JvmStatic
    fun hide(activity: Activity) {
        hideFullscreen(activity, null)
    }

    @JvmStatic
    fun hideFullscreen(activity: Activity, instanceId: String?) {
        adsGet<AndroidFullscreenNativeAdWindow>().hide(activity, instanceId)
    }

    @JvmStatic
    @JvmOverloads
    fun destroyFullscreen(instanceId: String = DefaultNativeAdInstanceId) {
        adsGet<AndroidFullscreenNativeAdWindow>().destroy(instanceId)
    }

    private fun parseLayoutNamesCsv(layoutNamesCsv: String): List<String> =
        layoutNamesCsv.splitListEntries()

    private fun firstLayoutName(layoutNamesCsv: String): String =
        parseLayoutNamesCsv(layoutNamesCsv).firstOrNull() ?: FullscreenLayoutCatalog.SingleDefault

    private fun parseDurationsSecondsCsv(durationsSecondsCsv: String): List<Double> =
        durationsSecondsCsv
            .split(',', ';', '\n')
            .mapNotNull { it.trim().toDoubleOrNull() }
            .filter { it > 0.0 }
}
