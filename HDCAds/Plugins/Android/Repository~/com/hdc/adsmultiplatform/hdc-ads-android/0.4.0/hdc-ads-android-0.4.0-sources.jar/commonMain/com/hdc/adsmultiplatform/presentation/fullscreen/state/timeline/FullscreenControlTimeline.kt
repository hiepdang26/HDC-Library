package com.hdc.adsmultiplatform.presentation.fullscreen.state.timeline

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdMode
import com.hdc.adsmultiplatform.domain.policy.NativeAdDurations
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdCloseStyle
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdControlPhase
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdControlState
import kotlin.math.ceil

internal fun fullscreenNativeAdControlState(
    elapsedSeconds: Int,
    countdownDurationSeconds: Double,
    hiddenDelaySeconds: Double,
): FullscreenNativeAdControlState {
    return fullscreenNativeAdControlState(
        elapsedMillis = elapsedSeconds.coerceAtLeast(0) * 1_000L,
        mode = FullscreenNativeAdMode.SINGLE,
        countdownDurationSeconds = countdownDurationSeconds,
        hiddenDelaySeconds = hiddenDelaySeconds,
        timeUpCSeconds = 0,
        showTCD = true,
    )
}

internal fun fullscreenNativeAdControlState(
    elapsedMillis: Long,
    mode: FullscreenNativeAdMode,
    countdownDurationSeconds: Double,
    hiddenDelaySeconds: Double,
    timeUpCSeconds: Int,
    showTCD: Boolean,
    layoutName: String = "",
): FullscreenNativeAdControlState {
    val closeStyle = mode.closeStyle
    // The reference FullscreenOverlayRenderer: "prgso" layouts leave the close delay out of the progress bar (it is
    // full once the countdown ends) and prgso_04 keeps its X undimmed while the delay runs.
    val progressExcludesDelay = closeStyle == FullscreenNativeAdCloseStyle.PGRS &&
        layoutName.contains(ProgressOnlyLayoutMarker, ignoreCase = true)
    val keepsDisabledCloseUndimmed = closeStyle == FullscreenNativeAdCloseStyle.PGRS &&
        layoutName.contains(ProgressOnlyUndimmedCloseLayoutMarker, ignoreCase = true)
    val countdownMillis = NativeAdDurations.toMillis(countdownDurationSeconds)
    val delayMillis = NativeAdDurations.toMillis(hiddenDelaySeconds)
    val timeUpCMillis = NativeAdDurations.toMillis(timeUpCSeconds.toDouble())
    val progressPhaseMillis = when (closeStyle) {
        FullscreenNativeAdCloseStyle.PGRS,
        FullscreenNativeAdCloseStyle.PGRS_CLS,
        -> timeUpCMillis + countdownMillis

        else -> countdownMillis
    }
    val totalMillis = progressPhaseMillis + delayMillis
    val safeElapsedMillis = elapsedMillis.coerceIn(0L, totalMillis.coerceAtLeast(0L))
    val canClose = safeElapsedMillis >= totalMillis
    val phase = when {
        canClose -> FullscreenNativeAdControlPhase.FINISHED
        safeElapsedMillis >= progressPhaseMillis -> FullscreenNativeAdControlPhase.CLOSE_DELAY
        else -> FullscreenNativeAdControlPhase.PROGRESS
    }
    val remainingProgressMillis = (progressPhaseMillis - safeElapsedMillis).coerceAtLeast(0L)
    val remainingCountdownSeconds = ceil(remainingProgressMillis / 1_000.0).toInt()
    val showProgress = showTCD && (
        closeStyle == FullscreenNativeAdCloseStyle.PGRS ||
            closeStyle == FullscreenNativeAdCloseStyle.PGRS_CLS ||
            closeStyle == FullscreenNativeAdCloseStyle.LOOP
        )
    // A visible progress bar also covers the close delay, except loop and "prgso" bars; otherwise only the
    // countdown counts.
    val progress = if (showProgress && !progressExcludesDelay && closeStyle != FullscreenNativeAdCloseStyle.LOOP) {
        elapsedFraction(safeElapsedMillis, totalMillis)
    } else {
        elapsedFraction(safeElapsedMillis, progressPhaseMillis)
    }
    val showCountdown = showTCD &&
        phase == FullscreenNativeAdControlPhase.PROGRESS &&
        remainingCountdownSeconds > 0 &&
        closeStyle != FullscreenNativeAdCloseStyle.PGRS &&
        closeStyle != FullscreenNativeAdCloseStyle.PGRS_CLS

    return FullscreenNativeAdControlState(
        remainingSeconds = remainingCountdownSeconds,
        canClose = canClose,
        showCountdown = showCountdown,
        phase = phase,
        closeStyle = closeStyle,
        progress = progress,
        showProgress = showProgress && !canClose,
        showOpenStoreButton = closeStyle == FullscreenNativeAdCloseStyle.PGRS &&
            phase == FullscreenNativeAdControlPhase.PROGRESS &&
            safeElapsedMillis >= timeUpCMillis,
        showCloseButton = closeStyle.closeButtonVisible(phase, canClose, showTCD),
        closeButtonEnabled = canClose,
        closeButtonAlpha = if (keepsDisabledCloseUndimmed) {
            1f
        } else {
            closeStyle.closeButtonAlpha(
                phase = phase,
                canClose = canClose,
                elapsedDelayMillis = (safeElapsedMillis - progressPhaseMillis).coerceAtLeast(0L),
                delayMillis = delayMillis,
            )
        },
    )
}

private const val ProgressOnlyLayoutMarker = "prgso"

private const val ProgressOnlyUndimmedCloseLayoutMarker = "prgso_04"

internal fun fullscreenControlTimelineMillis(
    mode: FullscreenNativeAdMode,
    countdownDurationSeconds: Double,
    hiddenDelaySeconds: Double,
    timeUpCSeconds: Int,
): Long {
    val countdownMillis = NativeAdDurations.toMillis(countdownDurationSeconds)
    val progressPhaseMillis = if (mode.isProgressOverlay) {
        NativeAdDurations.toMillis(timeUpCSeconds.toDouble()) + countdownMillis
    } else {
        countdownMillis
    }
    return progressPhaseMillis + NativeAdDurations.toMillis(hiddenDelaySeconds)
}

/** Share of [totalMillis] that has passed, from 0 to 1; a timeline with no length is complete. */
private fun elapsedFraction(elapsedMillis: Long, totalMillis: Long): Float =
    if (totalMillis <= 0L) {
        1f
    } else {
        (elapsedMillis.toFloat() / totalMillis.toFloat()).coerceIn(0f, 1f)
    }

private val FullscreenNativeAdMode.closeStyle: FullscreenNativeAdCloseStyle
    get() = when (this) {
        FullscreenNativeAdMode.OVERLAY_CLS -> FullscreenNativeAdCloseStyle.CLS
        FullscreenNativeAdMode.OVERLAY_NAV -> FullscreenNativeAdCloseStyle.NAV
        FullscreenNativeAdMode.OVERLAY_PGRS -> FullscreenNativeAdCloseStyle.PGRS
        FullscreenNativeAdMode.OVERLAY_PGRS_CLS -> FullscreenNativeAdCloseStyle.PGRS_CLS
        FullscreenNativeAdMode.LOOP -> FullscreenNativeAdCloseStyle.LOOP
        else -> FullscreenNativeAdCloseStyle.STANDARD
    }

private fun FullscreenNativeAdCloseStyle.closeButtonVisible(
    phase: FullscreenNativeAdControlPhase,
    canClose: Boolean,
    showTCD: Boolean,
): Boolean =
    when (this) {
        FullscreenNativeAdCloseStyle.CLS -> true
        FullscreenNativeAdCloseStyle.PGRS,
        FullscreenNativeAdCloseStyle.PGRS_CLS,
        -> canClose || phase == FullscreenNativeAdControlPhase.CLOSE_DELAY

        // The reference FullscreenAdRenderer.startLoopDelayPhase: without the countdown the X stays gone until ready.
        FullscreenNativeAdCloseStyle.LOOP ->
            canClose || (showTCD && phase == FullscreenNativeAdControlPhase.CLOSE_DELAY)

        FullscreenNativeAdCloseStyle.STANDARD,
        FullscreenNativeAdCloseStyle.NAV,
        -> canClose
    }

private fun FullscreenNativeAdCloseStyle.closeButtonAlpha(
    phase: FullscreenNativeAdControlPhase,
    canClose: Boolean,
    elapsedDelayMillis: Long,
    delayMillis: Long,
): Float {
    if (canClose) return 1f
    return when (this) {
        FullscreenNativeAdCloseStyle.PGRS_CLS -> {
            if (phase != FullscreenNativeAdControlPhase.CLOSE_DELAY || delayMillis <= 0L) {
                0f
            } else {
                (elapsedDelayMillis.toFloat() / delayMillis.toFloat()).coerceIn(0f, 1f)
            }
        }

        FullscreenNativeAdCloseStyle.PGRS,
        FullscreenNativeAdCloseStyle.CLS,
        FullscreenNativeAdCloseStyle.LOOP,
        -> 0.35f

        FullscreenNativeAdCloseStyle.STANDARD,
        FullscreenNativeAdCloseStyle.NAV,
        -> 1f
    }
}
