@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.common.viewmodel.port

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.platform.clock.elapsedRealtimeMillis
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/**
 * Runs [schedule]'s block after a delay on the ViewModel's thread (reloads, countdowns, failure retries), and tells
 * the time the ViewModel measures ad ages with.
 */
@AdsConsoleSupportApi
@HiddenFromObjC
fun interface AdRuntimeScheduler {
    fun schedule(delayMillis: Long, block: () -> Unit): AdRuntimeCancellation

    /** Milliseconds that keep counting while the device sleeps; only differences mean something. */
    fun nowMillis(): Long = elapsedRealtimeMillis()
}
