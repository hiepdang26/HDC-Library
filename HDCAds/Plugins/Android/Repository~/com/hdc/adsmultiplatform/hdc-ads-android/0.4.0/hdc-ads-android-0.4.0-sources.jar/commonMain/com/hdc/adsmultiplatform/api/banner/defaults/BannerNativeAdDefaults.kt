package com.hdc.adsmultiplatform.api.banner.defaults

const val DefaultBannerNativeAdInstanceId = "banner_native_default"
