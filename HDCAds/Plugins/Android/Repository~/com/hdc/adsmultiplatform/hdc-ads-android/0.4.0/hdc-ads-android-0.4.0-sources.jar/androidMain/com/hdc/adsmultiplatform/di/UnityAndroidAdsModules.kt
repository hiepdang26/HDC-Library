package com.hdc.adsmultiplatform.di

import org.koin.core.module.Module

/** The Unity library's modules: the AdMob plug-in, plain-view fullscreen overlays, what Unity drives and the Unity adapter. */
internal actual fun adsModules(): List<Module> =
    listOf(adMobAndroidModule, androidViewModule, androidPresentationModule, androidUnityModule)
