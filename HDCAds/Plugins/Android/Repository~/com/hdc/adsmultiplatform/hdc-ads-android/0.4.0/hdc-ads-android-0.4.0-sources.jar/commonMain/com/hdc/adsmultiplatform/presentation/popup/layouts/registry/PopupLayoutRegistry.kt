package com.hdc.adsmultiplatform.presentation.popup.layouts.registry

/**
 * Every popup layout name the library knows, in catalog order. The catalog, the router and the media rules read this
 * list; a new layout is added to its group's list here and its design to the group's designs
 * (`layouts/manual/PopupManualLayoutDesigns.kt`), a new group is one more `+` here.
 */
internal object PopupLayoutRegistry {
    val entries: List<PopupLayoutEntry> = PopupManualLayoutEntries

    private val entriesByName: Map<String, PopupLayoutEntry> = entries.associateBy { it.name }

    fun entry(name: String): PopupLayoutEntry? = entriesByName[name]
}

/** The manual popup layouts, in catalog order. */
private val PopupManualLayoutEntries: List<PopupLayoutEntry> = listOf(
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual01, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual02, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual03, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual04, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual05, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual06, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual07, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual08, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual09, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual10, usesMediaView = false),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual11, usesMediaView = false),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual12, usesMediaView = true),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual13, usesMediaView = false),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual14, usesMediaView = false),
    PopupLayoutEntry(PopupNativeAdLayoutCatalog.PopupSingleManual15, usesMediaView = true),
)
