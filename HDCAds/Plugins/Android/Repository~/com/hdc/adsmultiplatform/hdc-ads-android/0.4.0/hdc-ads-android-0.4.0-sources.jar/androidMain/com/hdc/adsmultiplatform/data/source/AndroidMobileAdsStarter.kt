package com.hdc.adsmultiplatform.data.source

import android.content.Context

/** Starts the ad network's SDK when a host wants to know when it is ready (the HDCLib bridge's `init`). */
internal fun interface AndroidMobileAdsStarter {
    /** Starts the SDK with [context]; [onStarted] runs once it is ready, on any thread. */
    fun start(context: Context, onStarted: () -> Unit)
}
