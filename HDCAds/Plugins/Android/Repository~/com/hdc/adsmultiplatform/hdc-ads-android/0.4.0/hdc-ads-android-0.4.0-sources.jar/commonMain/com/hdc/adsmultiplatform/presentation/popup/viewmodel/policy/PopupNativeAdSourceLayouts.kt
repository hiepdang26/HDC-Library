package com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy

import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.presentation.popup.layouts.registry.PopupNativeAdLayoutCatalog

/** The layout an ad from [adSourceId] shows: the first ad source layout that lists the source, else the config's. */
internal fun PopupNativeAdConfig.layoutFor(adSourceId: String): String =
    adSourceLayouts.firstOrNull { adSourceId.isNotEmpty() && adSourceId in it.adSourceIds }?.layoutName ?: layoutName

/** The tallest minimum height among the layouts this popup can show. */
internal fun PopupNativeAdConfig.minLayoutHeightDp(): Float =
    (listOf(layoutName) + adSourceLayouts.map { it.layoutName }).maxOf { PopupNativeAdLayoutCatalog.minHeightDp(it) }
