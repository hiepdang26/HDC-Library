package com.hdc.adsmultiplatform.api.popup.callback

import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdError
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdInfo

interface PopupNativeAdCallback {
    fun onLoaded(ad: PopupNativeAdInfo) = Unit
    fun onDisplayable(alias: String) = Unit
    fun onDisplayed(ad: PopupNativeAdInfo) = Unit
    fun onOpened(ad: PopupNativeAdInfo) = Unit
    fun onClosed(ad: PopupNativeAdInfo) = Unit
    fun onClicked(ad: PopupNativeAdInfo) = Unit
    fun onFailedToLoad(error: PopupNativeAdError) = Unit
}
