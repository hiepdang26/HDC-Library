package com.hdc.adsmultiplatform.platform.android.thread

import android.os.Handler
import android.os.Looper
import com.hdc.adsmultiplatform.platform.log.AdsLog

private val mainHandler: Handler by lazy { Handler(Looper.getMainLooper()) }

/**
 * Runs [block] on the main thread: right away when the caller is already there, otherwise posted, like
 * `Activity.runOnUiThread`. Unity calls the library on its own thread, while ad callbacks and views live on the main
 * thread, so state they share is only changed here.
 */
internal fun runOnMainThread(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
        block()
    } else {
        mainHandler.post { runLoggingFailure(block) }
    }
}

// A block posted from Unity's thread runs on its own on the main thread, where an exception would end the app: it is
// logged instead.
private fun runLoggingFailure(block: () -> Unit) {
    try {
        block()
    } catch (error: Throwable) {
        AdsLog.warn("AdsMultiplatform Android main thread task failed: ${error::class.simpleName}: ${error.message}")
    }
}
