package com.hdc.adsmultiplatform.di

import com.hdc.adsmultiplatform.unity.callback.FullscreenNativeAdUnityCallbacks
import com.hdc.adsmultiplatform.unity.compat.FullscreenNativeAdUnityCompat
import com.hdc.adsmultiplatform.unity.event.UnityFullscreenNativeAdEvents
import com.hdc.adsmultiplatform.unity.host.AndroidHdcBannerHost
import com.hdc.adsmultiplatform.unity.host.AndroidHdcFullscreenHost
import com.hdc.adsmultiplatform.unity.host.AndroidHdcInterstitialHost
import com.hdc.adsmultiplatform.unity.host.AndroidHdcMetaTestHost
import com.hdc.adsmultiplatform.unity.host.AndroidHdcPopupHost
import com.hdc.adsmultiplatform.unity.host.AndroidHdcSdkHost
import com.hdc.adsmultiplatform.unity.port.HdcBannerHost
import com.hdc.adsmultiplatform.unity.port.HdcFullscreenHost
import com.hdc.adsmultiplatform.unity.port.HdcInterstitialHost
import com.hdc.adsmultiplatform.unity.port.HdcMetaTestHost
import com.hdc.adsmultiplatform.unity.port.HdcPopupHost
import com.hdc.adsmultiplatform.unity.port.HdcSdkHost
import org.koin.core.module.Module
import org.koin.dsl.module

/** The Unity adapter: the callbacks to Unity, the AdsPublicApi-style calls, and the hosts of the HDCLib bridge. */
internal val androidUnityModule: Module = module {
    single { FullscreenNativeAdUnityCallbacks(get()) }
    single { UnityFullscreenNativeAdEvents(get()) }
    single { FullscreenNativeAdUnityCompat(ads = get(), fullscreen = get(), callbacks = get()) }
    single<HdcSdkHost> { AndroidHdcSdkHost(starter = get(), fullscreenEvents = get()) }
    single<HdcInterstitialHost> { AndroidHdcInterstitialHost() }
    single<HdcFullscreenHost> { AndroidHdcFullscreenHost(window = get(), ads = get()) }
    single<HdcPopupHost> { AndroidHdcPopupHost(runtimes = get()) }
    single<HdcBannerHost> { AndroidHdcBannerHost(runtimes = get()) }
    single<HdcMetaTestHost> { AndroidHdcMetaTestHost() }
}
