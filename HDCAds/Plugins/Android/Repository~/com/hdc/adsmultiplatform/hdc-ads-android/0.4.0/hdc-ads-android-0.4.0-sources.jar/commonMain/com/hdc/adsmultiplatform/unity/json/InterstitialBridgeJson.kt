package com.hdc.adsmultiplatform.unity.json

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.policy.normalized

internal fun parseInterstitialAdConfigJson(
    configJson: String,
    fallbackAdUnitId: String = UnconfiguredAdUnitId,
): InterstitialAdConfig {
    val json = configJson.trim()
    require(json.startsWith("{") && json.endsWith("}")) { "Invalid interstitial config JSON" }
    return InterstitialAdConfig(
        ids = json.jsonStringArray("ids").ifEmpty { listOf(fallbackAdUnitId) },
        autoReload = json.jsonBoolean("autoReload", defaultValue = true),
        preloadBufferSize = json.jsonInt("preloadBufferSize")
            ?: json.jsonInt("bufferSize")
            ?: 1,
    ).normalized(fallbackAdUnitId)
}

internal fun parseInterstitialShowOptionsJson(optionsJson: String?): InterstitialShowOptions {
    val json = optionsJson?.trim().orEmpty()
    if (json.isBlank()) return InterstitialShowOptions()
    require(json.startsWith("{") && json.endsWith("}")) { "Invalid interstitial show options JSON" }
    return InterstitialShowOptions(
        immersiveMode = json.jsonBoolean("immersiveMode", defaultValue = true),
    )
}

private fun String.jsonStringArray(name: String): List<String> {
    // [\s\S] also matches line breaks; RegexOption.DOT_MATCHES_ALL does not exist in common Kotlin.
    val body = Regex(""""${Regex.escape(name)}"\s*:\s*\[([\s\S]*?)]""")
        .find(this)
        ?.groupValues
        ?.getOrNull(1)
        ?: return emptyList()
    return Regex(""""((?:\\.|[^"\\])*)"""")
        .findAll(body)
        .map { it.groupValues[1].jsonUnescape().trim() }
        .filter { it.isNotEmpty() }
        .toList()
}

private fun String.jsonBoolean(name: String, defaultValue: Boolean): Boolean {
    val value = Regex(""""${Regex.escape(name)}"\s*:\s*(true|false)""", RegexOption.IGNORE_CASE)
        .find(this)
        ?.groupValues
        ?.getOrNull(1)
        ?: return defaultValue
    return value.equals("true", ignoreCase = true)
}

private fun String.jsonInt(name: String): Int? =
    Regex(""""${Regex.escape(name)}"\s*:\s*(-?\d+)""")
        .find(this)
        ?.groupValues
        ?.getOrNull(1)
        ?.toIntOrNull()

private fun String.jsonUnescape(): String =
    replace("\\\"", "\"")
        .replace("\\\\", "\\")
        .replace("\\/", "/")
        .replace("\\n", "\n")
        .replace("\\r", "\r")
        .replace("\\t", "\t")
