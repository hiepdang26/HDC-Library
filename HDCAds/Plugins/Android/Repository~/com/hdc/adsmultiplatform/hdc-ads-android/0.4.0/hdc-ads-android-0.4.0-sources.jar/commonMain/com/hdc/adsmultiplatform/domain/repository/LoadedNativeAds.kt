package com.hdc.adsmultiplatform.domain.repository

import com.hdc.adsmultiplatform.domain.model.NativeAdFormat

/** Read access to the native ads a repository has loaded, for the code that renders or reports them. */
internal interface LoadedNativeAds<Ad : Any> {
    fun loadedAd(format: NativeAdFormat, instanceId: String): Ad?

    fun loadedAdUnitId(format: NativeAdFormat, instanceId: String): String?

    /** The ad a host draws for [instanceId]: the ad of the show on screen when the repository keeps one, else the loaded ad. */
    fun adToDraw(format: NativeAdFormat, instanceId: String): Ad? = loadedAd(format, instanceId)
}
