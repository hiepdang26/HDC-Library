package com.hdc.adsmultiplatform.presentation.common.viewmodel

import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.domain.parser.stableRuntimeKey
import com.hdc.adsmultiplatform.domain.policy.FailureBackoffPolicy
import com.hdc.adsmultiplatform.presentation.common.viewmodel.model.LoadedNativeAdTurn
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeCancellation
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeLoader
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeScheduler

/** A loaded ad waiting longer than this gets a replacement loaded; it can still show until it expires. */
private const val ReplaceAfterMillis = 50 * 60 * 1_000L

/** The networks expire a native ad an hour after it loads: it is let go and never shown. */
private const val ExpireAfterMillis = 60 * 60 * 1_000L

/**
 * The ad unit rotation that the banner and popup ViewModels load through: which of [adUnitIds] loads next, the
 * requests in flight, the loaded ads waiting to show, the ad units that failed, and the retry once every one failed.
 * [events] tells the ViewModel what happened so it publishes its own state, and passes on what each loaded ad
 * reports. Instance ids read `alias:formatKey:turn:adUnitKey`, and each instance is let go through [loader] once.
 * A loaded ad that waits 50 minutes gets a replacement loaded and still shows first; at an hour it has expired and is
 * let go. Ages are read from [scheduler]'s clock, which keeps counting while the device sleeps as the networks do.
 */
internal class NativeAdRotation(
    private val alias: String,
    private val formatKey: String,
    private val loader: AdRuntimeLoader,
    private val scheduler: AdRuntimeScheduler,
    private val adUnitIds: () -> List<String>,
    private val events: Events,
) {
    interface Events {
        /** A request went out, or the repository reports one still waiting. */
        fun onLoading()

        /** [turn] loaded and joined the ready queue. */
        fun onLoaded(turn: LoadedNativeAdTurn)

        /** [adUnitId] failed with [result]; the next ad unit is requested right after. */
        fun onFailed(adUnitId: String, result: NativeAdLoadResult)

        /** The ad of [instanceId] reported [event] (impression, click, paid value). */
        fun onAdEvent(instanceId: String, event: NativeAdEvent)

        /** [turn] expired before it was shown and left the ready queue. */
        fun onExpired(turn: LoadedNativeAdTurn)
    }

    private var loadTurn = 0
    private var nextAdUnitIndex = 0
    private val failureBackoff = FailureBackoffPolicy()
    private var failureTimer: AdRuntimeCancellation? = null
    private val loadingByInstanceId = mutableMapOf<String, String>()
    private val readyQueue = mutableListOf<LoadedNativeAdTurn>()
    private val failedAdUnitIds = mutableSetOf<String>()
    private val retiredInstanceIds = mutableSetOf<String>()
    private val ageTimers = mutableMapOf<String, List<AdRuntimeCancellation>>()

    val loadingAdUnitIds: Set<String>
        get() = loadingByInstanceId.values.toSet()

    val readyAdUnitIds: Set<String>
        get() = readyQueue.filterNot { it.isExpired() }.map { it.adUnitId }.toSet()

    val hasReadyAd: Boolean
        get() = readyQueue.any { !it.isExpired() }

    /** True while a request is in flight or a retry after a failed load is scheduled. */
    val isLoading: Boolean
        get() = loadingByInstanceId.isNotEmpty() || failureTimer != null

    /** The ad to show next: the oldest one that has not expired. */
    fun firstReady(): LoadedNativeAdTurn? = readyQueue.firstOrNull { !it.isExpired() }

    /** [turn] is about to show: it leaves the ready queue. */
    fun takeReady(turn: LoadedNativeAdTurn) {
        stopWatchingAge(turn.instanceId)
        readyQueue.removeAll { it.instanceId == turn.instanceId }
        letExpiredGo()
    }

    /** Requests the next ad unit that is neither loading nor failed, or retries after a backoff when there is none. */
    fun requestNextTurn(reason: String) {
        letExpiredGo()
        cancelFailureRetry()
        val adUnitId = nextLoadCandidate()
        if (adUnitId == null) {
            scheduleFailureBackoff(reason)
            return
        }
        failedAdUnitIds.remove(adUnitId)
        val instanceId = nextInstanceId(adUnitId)
        loadingByInstanceId[instanceId] = adUnitId
        events.onLoading()
        loader.listen(instanceId) { event -> events.onAdEvent(instanceId, event) }
        loader.load(instanceId, adUnitId) { result ->
            handleLoadResult(instanceId, adUnitId, result)
        }
    }

    /** Lets the repository drop the ad of [instanceId]. */
    fun destroyInstance(instanceId: String) {
        if (instanceId.isBlank() || !retiredInstanceIds.add(instanceId)) {
            return
        }
        loader.destroy(instanceId)
    }

    /** Lets every ready ad go and empties the queue. */
    fun releaseReady() {
        readyQueue.forEach {
            stopWatchingAge(it.instanceId)
            destroyInstance(it.instanceId)
        }
        readyQueue.clear()
    }

    /** Lets every request in flight go; their results are ignored. */
    fun releaseLoading() {
        loadingByInstanceId.keys.toList().forEach(::destroyInstance)
        loadingByInstanceId.clear()
    }

    fun clearFailures() {
        failedAdUnitIds.clear()
    }

    /** Starts over for a new config: nothing loading, ready or failed, the first ad unit next, no backoff. */
    fun restart() {
        ageTimers.values.forEach { timers -> timers.forEach { it.cancel() } }
        ageTimers.clear()
        loadingByInstanceId.clear()
        readyQueue.clear()
        failedAdUnitIds.clear()
        nextAdUnitIndex = 0
        failureBackoff.resetAfterLoaded()
    }

    fun cancelFailureRetry() {
        failureTimer?.cancel()
        failureTimer = null
    }

    private fun handleLoadResult(
        instanceId: String,
        adUnitId: String,
        result: NativeAdLoadResult,
    ) {
        if (loadingByInstanceId[instanceId] != adUnitId) {
            return
        }
        when (result.state) {
            NativeAdState.Loading -> events.onLoading()
            NativeAdState.Loaded -> {
                loadingByInstanceId.remove(instanceId)
                val loadedAdUnitId = result.adUnitId.ifBlank { adUnitId }
                failedAdUnitIds.remove(loadedAdUnitId)
                failureBackoff.resetAfterLoaded()
                val loaded = LoadedNativeAdTurn(
                    instanceId = instanceId,
                    adUnitId = loadedAdUnitId,
                    loadedAtMillis = scheduler.nowMillis(),
                    adSourceId = result.adSourceId,
                    adSourceName = result.adSourceName,
                )
                readyQueue += loaded
                watchAge(loaded)
                events.onLoaded(loaded)
            }
            NativeAdState.Failed -> {
                loadingByInstanceId.remove(instanceId)
                val failedAdUnitId = result.adUnitId.ifBlank { adUnitId }
                failedAdUnitIds += failedAdUnitId
                destroyInstance(instanceId)
                events.onFailed(failedAdUnitId, result)
                requestNextTurn(reason = "load_failed")
            }
            else -> Unit
        }
    }

    // The timers only speed things up: the age is read from the clock each time, which also covers a timer that
    // fired late because the device slept.
    private fun watchAge(turn: LoadedNativeAdTurn) {
        ageTimers[turn.instanceId] = listOf(
            scheduler.schedule(ReplaceAfterMillis) { replaceIfStale(turn) },
            scheduler.schedule(ExpireAfterMillis) { letExpiredGo() },
        )
    }

    private fun stopWatchingAge(instanceId: String) {
        ageTimers.remove(instanceId)?.forEach { it.cancel() }
    }

    // A replacement loads while the stale ad can still show, unless a younger ad is ready or a load is running.
    private fun replaceIfStale(turn: LoadedNativeAdTurn) {
        if (readyQueue.none { it.instanceId == turn.instanceId } || !turn.isStale()) {
            return
        }
        val hasYoungerAd = readyQueue.any { it.instanceId != turn.instanceId && !it.isStale() }
        if (!hasYoungerAd && loadingByInstanceId.isEmpty()) {
            requestNextTurn(reason = "stale")
        }
    }

    private fun letExpiredGo() {
        val expired = readyQueue.filter { it.isExpired() }
        if (expired.isEmpty()) {
            return
        }
        readyQueue.removeAll { it.isExpired() }
        expired.forEach { turn ->
            stopWatchingAge(turn.instanceId)
            destroyInstance(turn.instanceId)
            events.onExpired(turn)
        }
    }

    private fun LoadedNativeAdTurn.isStale(): Boolean = scheduler.nowMillis() - loadedAtMillis >= ReplaceAfterMillis

    private fun LoadedNativeAdTurn.isExpired(): Boolean = scheduler.nowMillis() - loadedAtMillis >= ExpireAfterMillis

    private fun scheduleFailureBackoff(reason: String) {
        if (failureTimer != null) {
            return
        }
        val delayMillis = failureBackoff.nextFailureRetryDelayMillis()
        failureTimer = scheduler.schedule(delayMillis) {
            failureTimer = null
            failedAdUnitIds.clear()
            requestNextTurn(reason = reason)
        }
    }

    private fun nextLoadCandidate(): String? {
        val ids = adUnitIds()
        if (ids.isEmpty()) {
            return null
        }
        repeat(ids.size) {
            val index = (nextAdUnitIndex + it) % ids.size
            val candidate = ids[index]
            val isLoading = candidate in loadingByInstanceId.values
            val isFailed = candidate in failedAdUnitIds
            if (!isLoading && !isFailed) {
                nextAdUnitIndex = (index + 1) % ids.size
                return candidate
            }
        }
        return null
    }

    private fun nextInstanceId(adUnitId: String): String {
        loadTurn += 1
        return "$alias:$formatKey:$loadTurn:${adUnitId.stableRuntimeKey()}"
    }
}
