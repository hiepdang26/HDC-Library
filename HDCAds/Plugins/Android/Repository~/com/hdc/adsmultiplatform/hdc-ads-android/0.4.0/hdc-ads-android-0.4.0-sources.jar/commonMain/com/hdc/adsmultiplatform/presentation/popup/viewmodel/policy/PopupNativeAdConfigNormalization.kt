package com.hdc.adsmultiplatform.presentation.popup.viewmodel.policy

import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdSourceLayout
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.presentation.popup.layouts.registry.PopupNativeAdLayoutCatalog

internal fun PopupNativeAdConfig.normalizedForPopupRuntime(): PopupNativeAdConfig {
    val normalized = copy(
        ids = ids.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(UnconfiguredAdUnitId) },
        layoutName = PopupNativeAdLayoutCatalog.normalize(layoutName),
        timeShowSeconds = timeShowSeconds.coerceAtLeast(0),
        timeReloadSeconds = timeReloadSeconds.coerceAtLeast(0),
        adWidthDp = adWidthDp.coerceAtLeast(PopupNativeAdLayoutCatalog.MinWidthDp),
        adSourceLayouts = adSourceLayouts.mapNotNull { sourceLayout ->
            val adSourceIds = sourceLayout.adSourceIds.map { it.trim() }.filter { it.isNotEmpty() }
            if (adSourceIds.isEmpty() || sourceLayout.layoutName.isBlank()) {
                null
            } else {
                PopupNativeAdSourceLayout(adSourceIds, PopupNativeAdLayoutCatalog.normalize(sourceLayout.layoutName))
            }
        },
    )
    return normalized.copy(adHeightDp = adHeightDp.coerceAtLeast(normalized.minLayoutHeightDp()))
}
