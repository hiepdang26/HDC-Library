@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.domain.parser

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.domain.model.NativeAdUnitWaterfall
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
fun parseAdUnitIdsCsv(adUnitIdsCsv: String): List<String> =
    NativeAdUnitWaterfall.fromCsv(adUnitIdsCsv).ids
