package com.hdc.adsmultiplatform.domain.parser

/** The string's Java-style hash as text: the same on every platform and run, short enough for instance ids. */
internal fun String.stableRuntimeKey(): String {
    var hash = 0
    forEach { char ->
        hash = 31 * hash + char.code
    }
    return hash.toString()
}
