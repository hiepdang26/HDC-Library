package com.hdc.adsmultiplatform.data.common.buffer

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.platform.clock.elapsedRealtimeMillis
import kotlin.concurrent.Volatile

/** A loaded interstitial waiting longer than this no longer fills the buffer: the next fill loads a replacement. */
private const val ReplaceAfterMillis = 50 * 60 * 1_000L

/** The networks expire an interstitial an hour after it loads: it is let go and never shown. */
private const val ExpireAfterMillis = 60 * 60 * 1_000L

/**
 * The interstitial ads of one alias that the Android and iOS repositories load and show: the loaded ads waiting per
 * ad unit, the loads in flight, and whether one is on screen. A new config starts a new request version, so answers
 * to the loads of an older config are dropped. Each platform's slot extends it with what its show needs. The loads
 * and shows run on the main thread; [isShowing] and [hasReadyAd] can also be read from another one (Unity's on
 * Android). Ads are kept with the time they loaded on [clock], which keeps counting while the device sleeps.
 */
internal open class InterstitialAdBuffer<Ad : Any>(
    defaultAdUnitId: String,
    private val clock: () -> Long = ::elapsedRealtimeMillis,
) {
    private class Loaded<Ad>(val ad: Ad, val loadedAtMillis: Long)

    var config: InterstitialAdConfig = InterstitialAdConfig(ids = listOf(defaultAdUnitId))
        private set
    @Volatile
    var isShowing: Boolean = false
    private var requestVersion = 0

    @Volatile
    private var readyAds = 0
    private val queues = mutableMapOf<String, ArrayDeque<Loaded<Ad>>>()
    private val loadingCounts = mutableMapOf<String, Int>()

    /**
     * Switches to [nextConfig]; false when nothing changed. New ad units start over: the ads and loads of the old
     * ones are forgotten. The same ad units with another buffer size or reload rule keep both, so no loaded ad is
     * dropped (a matched request that never shows).
     */
    fun reconfigure(nextConfig: InterstitialAdConfig): Boolean {
        if (config == nextConfig) {
            return false
        }
        val sameAdUnits = config.ids == nextConfig.ids
        config = nextConfig
        if (sameAdUnits) {
            return true
        }
        requestVersion += 1
        queues.clear()
        readyAds = 0
        loadingCounts.clear()
        return true
    }

    /**
     * Starts loads through [load] until every ad unit of the config has as many ads loaded or loading as the buffer
     * size. [load] gets the request version to hand back to [finishLoad].
     */
    fun fill(load: (adUnitId: String, version: Int) -> Unit) {
        letExpiredGo()
        val version = requestVersion
        config.ids.forEach { adUnitId ->
            while (freshCount(adUnitId) + loadingCount(adUnitId) < config.preloadBufferSize) {
                incrementLoading(adUnitId)
                load(adUnitId, version)
            }
        }
    }

    /**
     * A load of [adUnitId] answered. False when it belongs to older ad units: its answer is dropped, and it no longer
     * counts as loading (that count went with the old ad units), so it cannot lower the count of the new ones.
     */
    fun finishLoad(adUnitId: String, version: Int): Boolean {
        if (version != requestVersion) {
            return false
        }
        decrementLoading(adUnitId)
        return true
    }

    fun enqueue(adUnitId: String, ad: Ad) {
        queues.getOrPut(adUnitId) { ArrayDeque() }.addLast(Loaded(ad, clock()))
        readyAds += 1
    }

    /** The ad to show next: from the first ad unit of the config that has one, else any ad left; never an expired one. */
    fun pollReadyAd(): Ad? {
        letExpiredGo()
        val loaded = config.ids.firstNotNullOfOrNull { adUnitId -> queues[adUnitId]?.removeFirstOrNull() }
            ?: queues.values.firstNotNullOfOrNull { it.removeFirstOrNull() }
        if (loaded != null) {
            readyAds -= 1
        }
        return loaded?.ad
    }

    // Read from a counter rather than the queues, which only the main thread may walk.
    fun hasReadyAd(): Boolean = readyAds > 0

    fun readyCount(adUnitId: String): Int =
        queues[adUnitId]?.count { !it.isExpired() } ?: 0

    fun loadingCount(adUnitId: String): Int =
        loadingCounts[adUnitId] ?: 0

    /** Forgets every loaded ad and every load in flight, and the show. */
    protected fun clear() {
        queues.clear()
        readyAds = 0
        loadingCounts.clear()
        isShowing = false
    }

    // Ads that are not stale yet; a stale one still shows but no longer counts toward the buffer.
    private fun freshCount(adUnitId: String): Int =
        queues[adUnitId]?.count { clock() - it.loadedAtMillis < ReplaceAfterMillis } ?: 0

    private fun letExpiredGo() {
        queues.values.forEach { queue ->
            val before = queue.size
            queue.removeAll { it.isExpired() }
            readyAds -= before - queue.size
        }
    }

    private fun Loaded<Ad>.isExpired(): Boolean = clock() - loadedAtMillis >= ExpireAfterMillis

    private fun incrementLoading(adUnitId: String) {
        loadingCounts[adUnitId] = loadingCount(adUnitId) + 1
    }

    private fun decrementLoading(adUnitId: String) {
        val next = (loadingCount(adUnitId) - 1).coerceAtLeast(0)
        if (next == 0) {
            loadingCounts.remove(adUnitId)
        } else {
            loadingCounts[adUnitId] = next
        }
    }
}
