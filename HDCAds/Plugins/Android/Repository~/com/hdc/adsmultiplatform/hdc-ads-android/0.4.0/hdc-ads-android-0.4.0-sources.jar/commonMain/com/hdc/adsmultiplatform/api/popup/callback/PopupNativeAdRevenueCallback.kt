package com.hdc.adsmultiplatform.api.popup.callback

import com.hdc.adsmultiplatform.api.common.model.NativeAdPaidInfo
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdInfo

/**
 * Impressions and paid impressions of the popup native ads of an alias, for revenue reporting. It is apart from
 * [PopupNativeAdCallback] so code that implements that callback keeps working: on iOS every method of an exported
 * callback is required.
 */
interface PopupNativeAdRevenueCallback {
    fun onImpression(ad: PopupNativeAdInfo) = Unit

    fun onPaidImpression(ad: PopupNativeAdInfo, paidInfo: NativeAdPaidInfo) = Unit
}
