@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.domain.model

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/** Who served an ad: the mediation adapter, the ad source and the response id, when the network tells. */
@AdsConsoleSupportApi
@HiddenFromObjC
data class AdResponseInfo(
    val mediationAdapter: String? = null,
    val adSource: String? = null,
    val responseId: String? = null,
)
