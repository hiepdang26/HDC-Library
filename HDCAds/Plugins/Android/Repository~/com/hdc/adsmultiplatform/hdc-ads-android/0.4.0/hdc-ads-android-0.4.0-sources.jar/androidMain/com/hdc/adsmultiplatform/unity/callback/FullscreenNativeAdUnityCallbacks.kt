package com.hdc.adsmultiplatform.unity.callback

import com.hdc.adsmultiplatform.data.model.LoadedNativeAdInfo
import com.hdc.adsmultiplatform.data.port.NativeAdEventListener
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.domain.model.AdPaidValue
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdFormats
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.platform.log.AdsLog
import com.hdc.adsmultiplatform.unity.model.FullscreenNativeAdUnityInfo
import com.hdc.adsmultiplatform.unity.model.FullscreenNativeAdUnityPaidInfo
import java.util.concurrent.ConcurrentHashMap

/** Relays fullscreen native events to the [FullscreenNativeAdUnityCallback] Unity set for an alias. */
internal class FullscreenNativeAdUnityCallbacks(
    private val ads: AndroidNativeAdSource,
) : NativeAdEventListener {
    private val callbacks = ConcurrentHashMap<String, FullscreenNativeAdUnityCallback>()
    private val loadedInfos = ConcurrentHashMap<String, FullscreenNativeAdUnityInfo>()

    fun set(alias: String, callback: FullscreenNativeAdUnityCallback?) {
        if (callback == null) callbacks.remove(alias) else callbacks[alias] = callback
    }

    fun remove(alias: String) {
        callbacks.remove(alias)
        loadedInfos.remove(alias)
    }

    /** Adapter of the last ad loaded for [alias], kept after it is shown (the reference library's `getLatestNativeMediationAdapter`). */
    fun latestMediationAdapter(alias: String): String? = loadedInfos[alias]?.mediationAdapter

    fun onLoadResult(alias: String, result: NativeAdLoadResult) {
        when (result.state) {
            NativeAdState.Loaded -> {
                val info = ads.loadedAdInfo(NativeAdFormats.Fullscreen, alias).toUnityInfo(
                    ads.loadedAdUnitId(NativeAdFormats.Fullscreen, alias) ?: result.adUnitId,
                )
                loadedInfos[alias] = info
                notify(alias, "loaded") { onFSNALoaded(info) }
                notify(alias, "displayable") { onFSNADisplayable() }
            }
            NativeAdState.Failed ->
                notify(alias, "failed") { onFSNAFailedToLoad(result.adUnitId, result.code, result.message) }
            else -> Unit
        }
    }

    /** The ad screen is attached; like the reference library, displayed means on screen rather than impression recorded. */
    fun onDisplayed(alias: String) {
        val info = loadedInfos[alias] ?: return
        notify(alias, "displayed") { onFSNADisplayed(info) }
    }

    fun onClosed(alias: String) {
        val info = loadedInfos[alias] ?: return
        notify(alias, "closed") { onFSNAClosed(info) }
    }

    override fun onAdEvent(instanceId: String, event: NativeAdEvent) {
        val info = loadedInfos[instanceId] ?: return
        when (event) {
            NativeAdEvent.Clicked -> notify(instanceId, "clicked") { onFSNAClicked(info) }
            NativeAdEvent.Opened -> notify(instanceId, "opened") { onFSNAOpened(info) }
            is NativeAdEvent.Paid -> notify(instanceId, "paid") { onFSNAPaidImpression(info, event.value.toUnityPaidInfo(info)) }
            // The reference library's Unity callback has no impression method; adding one would break the Unity proxies already built.
            NativeAdEvent.Impression -> Unit
        }
    }

    private inline fun notify(alias: String, event: String, call: FullscreenNativeAdUnityCallback.() -> Unit) {
        val callback = callbacks[alias] ?: return
        // A failing Unity proxy must not break the ad flow on this side.
        runCatching { callback.call() }.onFailure { error ->
            AdsLog.warn("Fullscreen native Unity callback failed: alias=$alias event=$event error=${error.message}")
        }
    }

    private fun LoadedNativeAdInfo?.toUnityInfo(adUnitId: String): FullscreenNativeAdUnityInfo =
        FullscreenNativeAdUnityInfo(
            adUnitId = adUnitId,
            headline = this?.headline,
            body = this?.body,
            callToAction = this?.callToAction,
            advertiser = this?.advertiser,
            store = this?.store,
            price = this?.price,
            mediationAdapter = this?.mediationAdapter,
            responseId = this?.responseId,
            adSource = this?.adSource,
            adSourceId = this?.adSourceId,
        )

    private fun AdPaidValue.toUnityPaidInfo(info: FullscreenNativeAdUnityInfo): FullscreenNativeAdUnityPaidInfo =
        FullscreenNativeAdUnityPaidInfo(
            adUnitId = info.adUnitId,
            revenueMicros = valueMicros,
            currencyCode = currencyCode,
            mediationAdapter = info.mediationAdapter,
            adSource = info.adSource,
            responseId = info.responseId,
        )
}
