package com.hdc.adsmultiplatform.unity.host

import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.api.interstitial.sdk.AndroidInterstitialAdSdk
import com.hdc.adsmultiplatform.unity.gameplay.HdcUnityActivity
import com.hdc.adsmultiplatform.unity.port.HdcInterstitialHost

/** Interstitials for the bridge, through the public Android interstitial SDK, on the Unity activity. */
internal class AndroidHdcInterstitialHost : HdcInterstitialHost {
    override fun load(id: String, config: InterstitialAdConfig) {
        AndroidInterstitialAdSdk.create(
            alias = id,
            adUnitIdsCsv = config.ids.joinToString(","),
            preloadBufferSize = config.preloadBufferSize,
            autoReload = config.autoReload,
        )
        AndroidInterstitialAdSdk.load(HdcUnityActivity.require(), id)
    }

    override fun show(id: String, options: InterstitialShowOptions): Boolean =
        AndroidInterstitialAdSdk.show(HdcUnityActivity.require(), id, options)

    override fun isReady(id: String): Boolean = AndroidInterstitialAdSdk.isReady(id)

    override fun destroy(id: String) {
        AndroidInterstitialAdSdk.destroy(id)
    }
}
