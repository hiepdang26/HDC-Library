package com.hdc.adsmultiplatform.api.event.model

/**
 * An impression, click or paid event of one ad, of any format. [instanceId] is the alias the host loaded the ad with,
 * [format] the format key ("fullscreen", "popup", "banner", "interstitial").
 */
internal data class AdTrackingEvent(
    val instanceId: String,
    val format: String,
    val name: String,
    val adUnitId: String,
    val valueMicros: Long = 0L,
    val currencyCode: String = "",
    val precision: Int = 0,
    val adSourceName: String = "",
    val mediationAdapter: String = "",
    val responseId: String = "",
)
