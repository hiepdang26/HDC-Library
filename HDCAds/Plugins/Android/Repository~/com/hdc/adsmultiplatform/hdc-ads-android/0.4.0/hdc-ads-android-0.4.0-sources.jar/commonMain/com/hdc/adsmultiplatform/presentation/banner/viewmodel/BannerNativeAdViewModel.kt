@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.banner.viewmodel

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.api.banner.callback.BannerNativeAdCallback
import com.hdc.adsmultiplatform.api.banner.callback.BannerNativeAdRevenueCallback
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdConfig
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdError
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdInfo
import com.hdc.adsmultiplatform.api.banner.policy.BannerNativeAdReloadPolicy
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.banner.layouts.registry.BannerNativeAdLayoutCatalog
import com.hdc.adsmultiplatform.presentation.banner.state.BannerNativeAdUiState
import com.hdc.adsmultiplatform.presentation.common.viewmodel.NativeAdRotation
import com.hdc.adsmultiplatform.presentation.common.viewmodel.mapper.toPaidInfo
import com.hdc.adsmultiplatform.presentation.common.viewmodel.model.LoadedNativeAdTurn
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeCancellation
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeLoader
import com.hdc.adsmultiplatform.presentation.common.viewmodel.port.AdRuntimeScheduler
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
class BannerNativeAdViewModel(
    private val alias: String,
    private val loader: AdRuntimeLoader,
    private val scheduler: AdRuntimeScheduler,
    private val callback: BannerNativeAdCallback = object : BannerNativeAdCallback {},
    private val revenueCallback: BannerNativeAdRevenueCallback? = null,
    private val onSnapshotChanged: (BannerNativeAdUiState) -> Unit = {},
) {
    private var config = BannerNativeAdConfig(ids = listOf(UnconfiguredAdUnitId))
    private var snapshot = BannerNativeAdUiState()
    private var pendingShowOnLoadSuccess = false
    private var currentLayoutIndex = 0
    private var reloadTimer: AdRuntimeCancellation? = null
    private var closeCountdownTimer: AdRuntimeCancellation? = null
    private var collapsedCountdownTimer: AdRuntimeCancellation? = null
    private val rotation = NativeAdRotation(
        alias = alias,
        formatKey = "banner",
        loader = loader,
        scheduler = scheduler,
        adUnitIds = { config.ids },
        events = object : NativeAdRotation.Events {
            override fun onLoading() = onRotationLoading()

            override fun onLoaded(turn: LoadedNativeAdTurn) = onTurnLoaded(turn)

            override fun onFailed(adUnitId: String, result: NativeAdLoadResult) = onTurnFailed(adUnitId, result)

            override fun onAdEvent(instanceId: String, event: NativeAdEvent) = onTurnEvent(instanceId, event)

            override fun onExpired(turn: LoadedNativeAdTurn) = onTurnExpired()
        },
    )

    fun configure(nextConfig: BannerNativeAdConfig) {
        val normalized = nextConfig.normalized()
        if (normalized == config) {
            return
        }
        cancelTimers()
        rotation.releaseReady()
        snapshot.activeInstanceId?.let(rotation::destroyInstance)
        rotation.restart()
        pendingShowOnLoadSuccess = false
        currentLayoutIndex = 0
        config = normalized
        publish(
            BannerNativeAdUiState(
                state = NativeAdState.Idle,
                activeLayoutName = config.layoutNames.first(),
            ),
        )
    }

    fun load() {
        pendingShowOnLoadSuccess = false
        rotation.requestNextTurn(reason = "manual")
    }

    fun show() {
        if (!snapshot.isVisible && snapshot.activeInstanceId != null && snapshot.activeAdUnitId != null) {
            pendingShowOnLoadSuccess = true
            cancelCloseCountdownTimer()
            publish(
                snapshot.copy(
                    state = NativeAdState.Shown,
                    isVisible = true,
                    isExpanded = false,
                    expandedCloseClickEnabled = false,
                    canCollapseExpanded = true,
                    collapseCountdownSecondsRemaining = 0,
                    collapseCountdownProgress = 0f,
                    canCloseCollapsed = false,
                ),
            )
            callback.onDisplayed(currentInfo())
            callback.onOpened(currentInfo())
            scheduleNextReload()
            restartCollapsedCountdown()
            return
        }
        pendingShowOnLoadSuccess = true
        val ready = rotation.firstReady()
        if (ready != null) {
            showLoaded(ready, scheduleReloadTimer = true)
            return
        }
        rotation.requestNextTurn(reason = "show")
    }

    fun expand(enableClick: Boolean = false): Boolean {
        if (!snapshot.isVisible || snapshot.activeInstanceId == null || snapshot.activeAdUnitId == null || snapshot.isExpanded) {
            return false
        }
        cancelCollapsedCountdownTimer()
        val countdownMillis = config.timeCollapseSeconds.coerceAtLeast(0) * 1_000L
        val canCollapseImmediately = countdownMillis == 0L
        publish(
            snapshot.copy(
                isExpanded = true,
                expandedCloseClickEnabled = enableClick,
                canCollapseExpanded = canCollapseImmediately,
            ),
        )
        if (!canCollapseImmediately) {
            closeCountdownTimer = scheduler.schedule(countdownMillis) {
                closeCountdownTimer = null
                if (snapshot.isExpanded) {
                    publish(snapshot.copy(canCollapseExpanded = true))
                }
            }
        }
        return true
    }

    fun collapse() {
        if (!snapshot.isExpanded || !snapshot.canCollapseExpanded) {
            return
        }
        cancelCloseCountdownTimer()
        publish(
            snapshot.copy(
                isExpanded = false,
                expandedCloseClickEnabled = false,
                canCollapseExpanded = true,
                collapseCountdownSecondsRemaining = 0,
                collapseCountdownProgress = 0f,
                canCloseCollapsed = false,
            ),
        )
        scheduleNextReload()
        restartCollapsedCountdown()
    }

    fun hide() {
        cancelReloadTimer()
        cancelCloseCountdownTimer()
        cancelCollapsedCountdownTimer()
        pendingShowOnLoadSuccess = false
        val currentInfo = currentInfo()
        publish(
            snapshot.copy(
                state = NativeAdState.onClosed,
                isVisible = false,
                isExpanded = false,
                expandedCloseClickEnabled = false,
                canCollapseExpanded = true,
                collapseCountdownSecondsRemaining = 0,
                collapseCountdownProgress = 0f,
                canCloseCollapsed = false,
            ),
        )
        callback.onClosed(currentInfo)
    }

    fun destroy() {
        cancelTimers()
        cancelCloseCountdownTimer()
        rotation.releaseReady()
        snapshot.activeInstanceId?.let(rotation::destroyInstance)
        rotation.releaseLoading()
        rotation.clearFailures()
        pendingShowOnLoadSuccess = false
        publish(BannerNativeAdUiState())
    }

    private fun onRotationLoading() {
        publish(
            snapshot.copy(
                state = NativeAdState.Loading,
                loadingAdUnitIds = rotation.loadingAdUnitIds,
            ),
        )
    }

    private fun onTurnLoaded(loaded: LoadedNativeAdTurn) {
        callback.onLoaded(loaded.info(layoutName = ""))
        callback.onDisplayable(alias)
        publish(
            snapshot.copy(
                state = NativeAdState.Loaded,
                loadingAdUnitIds = rotation.loadingAdUnitIds,
                readyAdUnitIds = rotation.readyAdUnitIds,
            ),
        )
        if (pendingShowOnLoadSuccess) {
            showLoaded(loaded, scheduleReloadTimer = true)
        }
    }

    // A ready ad expired: the banner no longer counts as loaded unless another one is ready or one is on screen.
    private fun onTurnExpired() {
        val stillLoaded = snapshot.isVisible || rotation.hasReadyAd
        publish(
            snapshot.copy(
                state = if (snapshot.state == NativeAdState.Loaded && !stillLoaded) NativeAdState.Idle else snapshot.state,
                loadingAdUnitIds = rotation.loadingAdUnitIds,
                readyAdUnitIds = rotation.readyAdUnitIds,
            ),
        )
    }

    // What an ad reports once it is up; only the ad on screen can be seen, clicked or paid for.
    private fun onTurnEvent(instanceId: String, event: NativeAdEvent) {
        if (instanceId != snapshot.activeInstanceId) {
            return
        }
        when (event) {
            NativeAdEvent.Clicked -> callback.onClicked(currentInfo())
            NativeAdEvent.Impression -> revenueCallback?.onImpression(currentInfo())
            is NativeAdEvent.Paid -> revenueCallback?.onPaidImpression(currentInfo(), event.toPaidInfo(snapshot.activeAdUnitId.orEmpty()))
            NativeAdEvent.Opened -> Unit
        }
    }

    private fun onTurnFailed(failedAdUnitId: String, result: NativeAdLoadResult) {
        callback.onFailedToLoad(
            BannerNativeAdError(
                alias = alias,
                adUnitId = failedAdUnitId,
                code = result.code,
                message = result.message.ifBlank { "Banner native ad failed to load" },
            ),
        )
        publish(
            snapshot.copy(
                state = NativeAdState.Failed,
                loadingAdUnitIds = rotation.loadingAdUnitIds,
            ),
        )
    }

    private fun showLoaded(
        loaded: LoadedNativeAdTurn,
        scheduleReloadTimer: Boolean,
    ) {
        rotation.takeReady(loaded)
        val previousInstanceId = snapshot.activeInstanceId
        val wasExpanded = snapshot.isExpanded
        val previousExpandedCloseClickEnabled = snapshot.expandedCloseClickEnabled
        val previousCanCollapseExpanded = snapshot.canCollapseExpanded
        val layoutName = nextLayoutName()
        val nextSnapshot = snapshot.copy(
            state = NativeAdState.Shown,
            isVisible = true,
            isExpanded = wasExpanded,
            expandedCloseClickEnabled = if (wasExpanded) previousExpandedCloseClickEnabled else false,
            canCollapseExpanded = if (wasExpanded) previousCanCollapseExpanded else true,
            collapseCountdownSecondsRemaining = 0,
            collapseCountdownProgress = 0f,
            canCloseCollapsed = false,
            activeInstanceId = loaded.instanceId,
            activeAdUnitId = loaded.adUnitId,
            activeLayoutName = layoutName,
            readyAdUnitIds = rotation.readyAdUnitIds,
        )
        publish(nextSnapshot)
        callback.onDisplayed(loaded.info(layoutName))
        callback.onOpened(loaded.info(layoutName))
        if (previousInstanceId != null && previousInstanceId != loaded.instanceId) {
            rotation.destroyInstance(previousInstanceId)
        }
        if (scheduleReloadTimer) {
            scheduleNextReload()
        }
        if (!wasExpanded) {
            restartCollapsedCountdown()
        }
    }

    private fun scheduleNextReload() {
        cancelReloadTimer()
        val seconds = config.timeReloadSeconds
        if (!snapshot.isVisible || !BannerNativeAdReloadPolicy.isEnabled(seconds)) {
            return
        }
        reloadTimer = scheduler.schedule(BannerNativeAdReloadPolicy.intervalMillis(seconds)) {
            reloadTimer = null
            if (snapshot.isVisible) {
                pendingShowOnLoadSuccess = true
                cancelCollapsedCountdownTimer()
                rotation.requestNextTurn(reason = "timeReload")
            }
        }
    }

    private fun restartCollapsedCountdown() {
        cancelCollapsedCountdownTimer()
        if (!snapshot.isVisible || snapshot.isExpanded || !BannerNativeAdLayoutCatalog.hasCollapseCountdown(snapshot.activeLayoutName)) {
            publish(
                snapshot.copy(
                    collapseCountdownSecondsRemaining = 0,
                    collapseCountdownProgress = 0f,
                    canCloseCollapsed = false,
                ),
            )
            return
        }

        val totalSeconds = config.timeCountdownSeconds.coerceAtLeast(0)
        if (totalSeconds == 0) {
            publish(
                snapshot.copy(
                    collapseCountdownSecondsRemaining = 0,
                    collapseCountdownProgress = 0f,
                    canCloseCollapsed = true,
                ),
            )
            return
        }

        publish(
            snapshot.copy(
                collapseCountdownSecondsRemaining = totalSeconds,
                collapseCountdownProgress = 1f,
                canCloseCollapsed = false,
            ),
        )
        scheduleCollapsedCountdownTick(totalSeconds)
    }

    private fun scheduleCollapsedCountdownTick(totalSeconds: Int) {
        collapsedCountdownTimer = scheduler.schedule(1_000L) {
            collapsedCountdownTimer = null
            if (!snapshot.isVisible || snapshot.isExpanded || !BannerNativeAdLayoutCatalog.hasCollapseCountdown(snapshot.activeLayoutName)) {
                return@schedule
            }

            val remaining = (snapshot.collapseCountdownSecondsRemaining - 1).coerceAtLeast(0)
            publish(
                snapshot.copy(
                    collapseCountdownSecondsRemaining = remaining,
                    collapseCountdownProgress = if (totalSeconds == 0) 0f else remaining.toFloat() / totalSeconds.toFloat(),
                    canCloseCollapsed = remaining == 0,
                ),
            )
            if (remaining > 0) {
                scheduleCollapsedCountdownTick(totalSeconds)
            }
        }
    }

    private fun nextLayoutName(): String {
        val layouts = config.layoutNames
        val layout = layouts[currentLayoutIndex % layouts.size]
        currentLayoutIndex = (currentLayoutIndex + 1) % layouts.size
        return layout
    }

    private fun currentInfo(): BannerNativeAdInfo =
        BannerNativeAdInfo(
            alias = alias,
            instanceId = snapshot.activeInstanceId.orEmpty(),
            adUnitId = snapshot.activeAdUnitId.orEmpty(),
            layoutName = snapshot.activeLayoutName,
        )

    private fun LoadedNativeAdTurn.info(layoutName: String): BannerNativeAdInfo =
        BannerNativeAdInfo(
            alias = alias,
            instanceId = instanceId,
            adUnitId = adUnitId,
            layoutName = layoutName,
        )

    private fun publish(nextSnapshot: BannerNativeAdUiState) {
        snapshot = nextSnapshot
        onSnapshotChanged(nextSnapshot)
    }

    private fun cancelTimers() {
        cancelReloadTimer()
        cancelCloseCountdownTimer()
        cancelCollapsedCountdownTimer()
        rotation.cancelFailureRetry()
    }

    private fun cancelReloadTimer() {
        reloadTimer?.cancel()
        reloadTimer = null
    }

    private fun cancelCloseCountdownTimer() {
        closeCountdownTimer?.cancel()
        closeCountdownTimer = null
    }

    private fun cancelCollapsedCountdownTimer() {
        collapsedCountdownTimer?.cancel()
        collapsedCountdownTimer = null
    }

    private fun BannerNativeAdConfig.normalized(): BannerNativeAdConfig {
        val normalizedIds = ids.map { it.trim() }.filter { it.isNotEmpty() }
        val normalizedLayouts = layoutNames
            .map { BannerNativeAdLayoutCatalog.normalize(it) }
            .distinct()
            .filter { it in BannerNativeAdLayoutCatalog.All }
        return copy(
            ids = normalizedIds.ifEmpty { listOf(UnconfiguredAdUnitId) },
            layoutNames = normalizedLayouts.ifEmpty { BannerNativeAdLayoutCatalog.All },
            timeReloadSeconds = timeReloadSeconds.coerceAtLeast(0),
            timeCountdownSeconds = timeCountdownSeconds.coerceAtLeast(0),
            timeCollapseSeconds = timeCollapseSeconds.coerceAtLeast(0),
        )
    }
}
