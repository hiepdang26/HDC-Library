package com.hdc.adsmultiplatform.api.banner.callback

import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdError
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdInfo

interface BannerNativeAdCallback {
    fun onLoaded(ad: BannerNativeAdInfo) = Unit
    fun onDisplayable(alias: String) = Unit
    fun onDisplayed(ad: BannerNativeAdInfo) = Unit
    fun onOpened(ad: BannerNativeAdInfo) = Unit
    fun onClosed(ad: BannerNativeAdInfo) = Unit
    fun onClicked(ad: BannerNativeAdInfo) = Unit
    fun onFailedToLoad(error: BannerNativeAdError) = Unit
}
