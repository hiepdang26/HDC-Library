package com.hdc.adsmultiplatform.api.banner.policy

object BannerNativeAdReloadPolicy {
    fun isEnabled(timeReloadSeconds: Int): Boolean =
        timeReloadSeconds > 0

    fun intervalMillis(timeReloadSeconds: Int): Long =
        timeReloadSeconds.coerceAtLeast(0) * 1_000L
}
