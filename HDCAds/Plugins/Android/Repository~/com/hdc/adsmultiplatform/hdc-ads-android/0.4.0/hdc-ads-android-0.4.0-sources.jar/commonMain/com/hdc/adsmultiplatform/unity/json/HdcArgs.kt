package com.hdc.adsmultiplatform.unity.json

/** Typed access to a command's JSON arguments. */
internal class HdcArgs(private val values: Map<String, Any?>) {
    fun string(name: String, default: String = ""): String = values[name] as? String ?: default

    fun int(name: String, default: Int): Int = (values[name] as? Number)?.toInt() ?: default

    fun double(name: String, default: Double): Double = (values[name] as? Number)?.toDouble() ?: default

    fun float(name: String, default: Float): Float = (values[name] as? Number)?.toFloat() ?: default

    fun boolean(name: String, default: Boolean): Boolean = values[name] as? Boolean ?: default

    fun has(name: String): Boolean = values[name] != null

    /** A nested object; empty when missing, so every read falls back to its default. */
    fun obj(name: String): HdcArgs {
        @Suppress("UNCHECKED_CAST")
        val nested = values[name] as? Map<String, Any?>
        return HdcArgs(nested ?: emptyMap())
    }

    /** A list of nested objects; non-object items are skipped. */
    fun objList(name: String): List<HdcArgs> =
        (values[name] as? List<*>).orEmpty().mapNotNull { item ->
            @Suppress("UNCHECKED_CAST")
            (item as? Map<String, Any?>)?.let(::HdcArgs)
        }

    fun doubleList(name: String): List<Double> =
        (values[name] as? List<*>).orEmpty().mapNotNull { (it as? Number)?.toDouble() }

    /** A list of non-blank strings, from a JSON array or a string separated by `,` `;` or new lines. */
    fun stringList(name: String): List<String> =
        when (val value = values[name]) {
            is List<*> -> value.mapNotNull { (it as? String)?.trim() }
            is String -> value.split(',', ';', '\n')
            else -> emptyList()
        }.map { it.trim() }.filter { it.isNotEmpty() }

    /** The ad instance id every ad command needs. */
    fun id(): String = string("id").trim().also { require(it.isNotEmpty()) { "id is required" } }

    companion object {
        fun parse(json: String): HdcArgs = HdcArgs(HdcJson.parseObject(json))
    }
}
