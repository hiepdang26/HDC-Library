package com.hdc.adsmultiplatform.api.common.model

/** A paid impression of a native banner or popup: its value in micros of [currencyCode], and who served the ad. */
data class NativeAdPaidInfo(
    val adUnitId: String,
    val revenueMicros: Long,
    val currencyCode: String,
    val mediationAdapter: String? = null,
    val adSource: String? = null,
    val responseId: String? = null,
    /** How exact the value is, as the network says: 0 unknown, 1 estimated, 2 publisher provided, 3 precise. */
    val precision: Int = 0,
)
