package com.hdc.adsmultiplatform.api.interstitial.defaults

expect fun defaultInterstitialAdUnitId(): String
