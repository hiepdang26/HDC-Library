package com.hdc.adsmultiplatform.api.interstitial.model

data class InterstitialAdPaidInfo(
    val adUnitId: String,
    val revenueMicros: Long,
    val currencyCode: String,
    val mediationAdapter: String = "",
    val adSource: String? = null,
    val responseId: String = "",
    /** How exact the value is, as the network says: 0 unknown, 1 estimated, 2 publisher provided, 3 precise. */
    val precision: Int = 0,
)
