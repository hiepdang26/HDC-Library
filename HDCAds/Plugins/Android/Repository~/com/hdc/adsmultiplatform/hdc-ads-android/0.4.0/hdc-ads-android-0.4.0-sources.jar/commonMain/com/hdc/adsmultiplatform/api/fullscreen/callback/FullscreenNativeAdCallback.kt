package com.hdc.adsmultiplatform.api.fullscreen.callback

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdError
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdInfo

interface FullscreenNativeAdCallback {
    fun onLoaded(ad: FullscreenNativeAdInfo) = Unit
    fun onDisplayable(alias: String) = Unit
    fun onDisplayed(ad: FullscreenNativeAdInfo) = Unit
    fun onOpened(ad: FullscreenNativeAdInfo) = Unit
    fun onClosed(ad: FullscreenNativeAdInfo) = Unit
    fun onClicked(ad: FullscreenNativeAdInfo) = Unit
    fun onFailedToLoad(error: FullscreenNativeAdError) = Unit
}
