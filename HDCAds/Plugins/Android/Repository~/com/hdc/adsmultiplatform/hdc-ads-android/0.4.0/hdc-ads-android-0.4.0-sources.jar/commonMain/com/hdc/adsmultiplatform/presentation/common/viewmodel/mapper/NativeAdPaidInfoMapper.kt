package com.hdc.adsmultiplatform.presentation.common.viewmodel.mapper

import com.hdc.adsmultiplatform.api.common.model.NativeAdPaidInfo
import com.hdc.adsmultiplatform.domain.model.NativeAdEvent

/** The paid impression the game hears for this event of an ad of [adUnitId]. */
internal fun NativeAdEvent.Paid.toPaidInfo(adUnitId: String): NativeAdPaidInfo =
    NativeAdPaidInfo(
        adUnitId = adUnitId,
        revenueMicros = value.valueMicros,
        currencyCode = value.currencyCode,
        mediationAdapter = response.mediationAdapter,
        adSource = response.adSource,
        responseId = response.responseId,
        precision = value.precision,
    )
