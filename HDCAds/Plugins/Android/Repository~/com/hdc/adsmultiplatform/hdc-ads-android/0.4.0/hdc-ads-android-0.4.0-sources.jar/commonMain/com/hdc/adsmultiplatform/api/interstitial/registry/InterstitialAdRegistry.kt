package com.hdc.adsmultiplatform.api.interstitial.registry

import com.hdc.adsmultiplatform.api.common.registry.AliasRegistry
import com.hdc.adsmultiplatform.api.interstitial.callback.InterstitialAdCallback
import com.hdc.adsmultiplatform.api.interstitial.defaults.DefaultInterstitialAdInstanceId
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdInfo
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdPaidInfo
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.domain.policy.normalized

object InterstitialAdRegistry {
    private val store = AliasRegistry<InterstitialAdEntry, InterstitialAdCallback>(
        newEntry = { InterstitialAdEntry(InterstitialAdConfig(ids = listOf(UnconfiguredAdUnitId))) },
        keyOf = { it.normalizedAlias() },
    )

    fun create(
        alias: String = DefaultInterstitialAdInstanceId,
        config: InterstitialAdConfig,
    ) {
        store[alias] = InterstitialAdEntry(
            config = config.normalized(UnconfiguredAdUnitId),
        )
    }

    fun setCallback(alias: String, callback: InterstitialAdCallback?) {
        store.setCallback(alias, callback)
    }

    fun configFor(
        alias: String = DefaultInterstitialAdInstanceId,
        fallbackAdUnitId: String = UnconfiguredAdUnitId,
    ): InterstitialAdConfig {
        val entry = store.getOrPut(alias) {
            InterstitialAdEntry(config = InterstitialAdConfig(ids = listOf(fallbackAdUnitId)).normalized(fallbackAdUnitId))
        }
        return entry.config.normalized(fallbackAdUnitId)
    }

    fun stateFor(alias: String = DefaultInterstitialAdInstanceId): NativeAdState =
        store[alias]?.state ?: NativeAdState.Idle

    fun isReady(alias: String = DefaultInterstitialAdInstanceId): Boolean =
        store[alias]?.state == NativeAdState.Loaded

    fun loadedAdUnitId(alias: String = DefaultInterstitialAdInstanceId): String? =
        store[alias]?.loadedAdUnitId

    fun notifyLoading(alias: String) {
        store.update(alias) { it.copy(state = NativeAdState.Loading) }
    }

    fun notifyLoaded(alias: String, ad: InterstitialAdInfo) {
        store.update(alias) { it.copy(state = NativeAdState.Loaded, loadedAdUnitId = ad.adUnitId) }
        store.callback(alias)?.onInterstitialLoaded(ad)
        store.callback(alias)?.onInterstitialDisplayable()
    }

    fun notifyDisplayed(alias: String, ad: InterstitialAdInfo) {
        store.update(alias) { it.copy(state = NativeAdState.Shown, loadedAdUnitId = ad.adUnitId) }
        store.callback(alias)?.onInterstitialDisplayed(ad)
    }

    fun notifyOpened(alias: String, ad: InterstitialAdInfo) {
        store.callback(alias)?.onInterstitialOpened(ad)
    }

    fun notifyClosed(alias: String, ad: InterstitialAdInfo) {
        store.update(alias) { it.copy(state = NativeAdState.onClosed) }
        store.callback(alias)?.onInterstitialClosed(ad)
    }

    fun notifyClicked(alias: String, ad: InterstitialAdInfo) {
        store.callback(alias)?.onInterstitialClicked(ad)
    }

    fun notifyImpression(alias: String, ad: InterstitialAdInfo) {
        store.callback(alias)?.onInterstitialImpression(ad)
    }

    fun notifyFailedToLoad(
        alias: String,
        adUnit: String,
        errorCode: Int,
        error: String,
    ) {
        store.update(alias) { it.copy(state = NativeAdState.Failed) }
        store.callback(alias)?.onInterstitialFailedToLoad(adUnit, errorCode, error)
    }

    fun notifyFailedToShow(
        alias: String,
        adUnit: String,
        errorCode: Int,
        error: String,
    ) {
        store.update(alias) { it.copy(state = NativeAdState.Failed) }
        store.callback(alias)?.onInterstitialFailedToShow(adUnit, errorCode, error)
    }

    fun notifyPaidImpression(
        alias: String,
        ad: InterstitialAdInfo,
        paidInfo: InterstitialAdPaidInfo,
    ) {
        store.callback(alias)?.onInterstitialPaidImpression(ad, paidInfo)
    }

    fun destroy(alias: String = DefaultInterstitialAdInstanceId) {
        store.remove(alias)
    }
}

private fun String.normalizedAlias(): String =
    ifBlank { DefaultInterstitialAdInstanceId }
