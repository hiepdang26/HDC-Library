package com.hdc.adsmultiplatform.api.fullscreen.model

data class NativeClickAssetOptions(
    val cta: Boolean = true,
    val headline: Boolean = true,
    val body: Boolean = true,
    val description: Boolean = true,
    val icon: Boolean = true,
    val advertiser: Boolean = true,
    val media: Boolean = true,
    val mediaImage: Boolean = true,
    val mediaVideo: Boolean = true,
) {
    val bodyOrDescriptionClickEnabled: Boolean
        get() = body || description

    val mediaImageClickEnabled: Boolean
        get() = media && mediaImage

    val mediaVideoClickEnabled: Boolean
        get() = media && mediaVideo

    val anyMediaClickEnabled: Boolean
        get() = mediaImageClickEnabled || mediaVideoClickEnabled
}
