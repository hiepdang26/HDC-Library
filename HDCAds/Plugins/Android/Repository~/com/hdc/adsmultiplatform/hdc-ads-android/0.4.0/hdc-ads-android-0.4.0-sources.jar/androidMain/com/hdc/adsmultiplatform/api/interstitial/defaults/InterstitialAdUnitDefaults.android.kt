package com.hdc.adsmultiplatform.api.interstitial.defaults

import com.hdc.adsmultiplatform.data.model.AdNetworkTestAdUnits
import com.hdc.adsmultiplatform.di.adsGet

actual fun defaultInterstitialAdUnitId(): String = adsGet<AdNetworkTestAdUnits>().interstitial
