package com.hdc.adsmultiplatform.api.fullscreen.sdk

import android.app.Activity
import com.hdc.adsmultiplatform.api.fullscreen.callback.FullscreenNativeAdCallback
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.api.fullscreen.registry.FullscreenNativeAdRegistry
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.defaults.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.parser.parseAdUnitIdsCsv
import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.AndroidFullscreenNativeAdWindow

object AndroidFullscreenNativeAdSdk {
    @JvmStatic
    @JvmOverloads
    fun create(
        alias: String = DefaultNativeAdInstanceId,
        adUnitIdsCsv: String = UnconfiguredAdUnitId,
        preloadBufferSize: Int = 1,
        enableReloadAfterShow: Boolean = true,
    ) {
        FullscreenNativeAdRegistry.create(
            alias = alias,
            config = FullscreenNativeAdConfig(
                ids = parseAdUnitIdsCsv(adUnitIdsCsv),
                preloadBufferSize = preloadBufferSize,
                enableReloadAfterShow = enableReloadAfterShow,
            ),
        )
    }

    @JvmStatic
    fun setCallback(alias: String, callback: FullscreenNativeAdCallback?) {
        FullscreenNativeAdRegistry.setCallback(alias, callback)
    }

    @JvmStatic
    @JvmOverloads
    fun load(
        activity: Activity,
        alias: String = DefaultNativeAdInstanceId,
    ) {
        val config = FullscreenNativeAdRegistry.configFor(alias, UnconfiguredAdUnitId)
        adsGet<AndroidFullscreenNativeAdWindow>().load(
            activity = activity,
            instanceId = alias,
            adUnitIdsCsv = config.ids.joinToString(","),
            enableReloadAfterShow = true,
        )
    }

    @JvmStatic
    @JvmOverloads
    fun loadWithIds(
        activity: Activity,
        alias: String = DefaultNativeAdInstanceId,
        adUnitIdsCsv: String = UnconfiguredAdUnitId,
        enableReloadAfterShow: Boolean = true,
    ) {
        create(
            alias = alias,
            adUnitIdsCsv = adUnitIdsCsv,
            enableReloadAfterShow = enableReloadAfterShow,
        )
        load(activity = activity, alias = alias)
    }

    @JvmStatic
    @JvmOverloads
    fun show(
        activity: Activity,
        alias: String = DefaultNativeAdInstanceId,
        options: FullscreenNativeAdShowOptions = FullscreenNativeAdShowOptions(),
    ) {
        val fallbackAdUnitId = FullscreenNativeAdRegistry.loadedAdUnitId(alias) ?: UnconfiguredAdUnitId
        adsGet<AndroidFullscreenNativeAdWindow>().show(
            activity = activity,
            instanceId = alias,
            options = options,
            fallbackAdUnitId = fallbackAdUnitId,
        )
    }

    @JvmStatic
    @JvmOverloads
    fun showWithLayoutName(
        activity: Activity,
        alias: String = DefaultNativeAdInstanceId,
        layoutName: String = FullscreenLayoutCatalog.SingleDefault,
        durationSeconds: Double = 5.0,
        autoClose: Boolean = false,
    ) {
        show(
            activity = activity,
            alias = alias,
            options = FullscreenNativeAdShowOptions(
                layoutName = layoutName,
                durationSeconds = durationSeconds,
                autoClose = autoClose,
            ),
        )
    }

    @JvmStatic
    @JvmOverloads
    fun hide(
        activity: Activity,
        alias: String = DefaultNativeAdInstanceId,
    ) {
        adsGet<AndroidFullscreenNativeAdWindow>().hide(activity, alias)
    }

    @JvmStatic
    @JvmOverloads
    fun destroy(alias: String = DefaultNativeAdInstanceId) {
        adsGet<AndroidFullscreenNativeAdWindow>().destroy(alias)
    }

    @JvmStatic
    fun isReady(alias: String = DefaultNativeAdInstanceId): Boolean =
        FullscreenNativeAdRegistry.isReady(alias)
}
