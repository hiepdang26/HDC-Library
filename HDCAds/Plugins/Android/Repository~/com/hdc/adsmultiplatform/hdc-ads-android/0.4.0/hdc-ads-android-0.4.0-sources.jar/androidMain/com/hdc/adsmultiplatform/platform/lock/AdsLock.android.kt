package com.hdc.adsmultiplatform.platform.lock

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

internal actual class AdsLock actual constructor() {
    private val lock = ReentrantLock()

    actual fun <T> locked(block: () -> T): T = lock.withLock(block)
}
