package com.hdc.adsmultiplatform.platform.android.window

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.view.View
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController

// systemUiVisibility and the bar colors are deprecated, but the ad saves the game's values and puts them back on close,
// on every API level.
@Suppress("DEPRECATION")
internal object AndroidFullscreenSystemUi {
    private var snapshot: AndroidSystemUiSnapshot? = null

    fun enter(activity: Activity) {
        val window = activity.window ?: return
        if (snapshot == null) {
            snapshot = AndroidSystemUiSnapshot(
                systemUiVisibility = window.decorView.systemUiVisibility,
                statusBarColor = window.statusBarColor,
                navigationBarColor = window.navigationBarColor,
            )
        }
        hideSystemBars(window)
    }

    fun exit(activity: Activity) {
        val window = activity.window ?: return
        val previous = snapshot ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.show(WindowInsets.Type.systemBars())
        }
        window.decorView.systemUiVisibility = previous.systemUiVisibility
        window.statusBarColor = previous.statusBarColor
        window.navigationBarColor = previous.navigationBarColor
        snapshot = null
    }

    private fun hideSystemBars(window: Window) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
    }
}
