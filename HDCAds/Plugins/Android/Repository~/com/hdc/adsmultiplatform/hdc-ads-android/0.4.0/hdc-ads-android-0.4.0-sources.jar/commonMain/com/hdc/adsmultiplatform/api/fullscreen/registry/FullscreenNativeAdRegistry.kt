package com.hdc.adsmultiplatform.api.fullscreen.registry

import com.hdc.adsmultiplatform.api.common.registry.AliasRegistry
import com.hdc.adsmultiplatform.api.fullscreen.callback.FullscreenNativeAdCallback
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdError
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdInfo
import com.hdc.adsmultiplatform.domain.defaults.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog

object FullscreenNativeAdRegistry {
    private val store = AliasRegistry<FullscreenNativeAdEntry, FullscreenNativeAdCallback>(
        newEntry = { FullscreenNativeAdEntry(FullscreenNativeAdConfig(ids = emptyList())) },
    )

    fun create(
        alias: String = DefaultNativeAdInstanceId,
        config: FullscreenNativeAdConfig,
    ) {
        store[alias] = FullscreenNativeAdEntry(config = config)
    }

    fun setCallback(alias: String, callback: FullscreenNativeAdCallback?) {
        store.setCallback(alias, callback)
    }

    fun configFor(alias: String, fallbackAdUnitId: String): FullscreenNativeAdConfig {
        val entry = store.getOrPut(alias) {
            FullscreenNativeAdEntry(config = FullscreenNativeAdConfig(ids = listOf(fallbackAdUnitId)).normalized(fallbackAdUnitId))
        }
        return entry.config.normalized(fallbackAdUnitId)
    }

    fun stateFor(alias: String): NativeAdState =
        store[alias]?.state ?: NativeAdState.Idle

    fun isReady(alias: String): Boolean =
        store[alias]?.state == NativeAdState.Loaded

    /**
     * Takes the loaded ad out of the ready state as soon as its screen is built, so a second show
     * cannot reuse it. [notifyDisplayed] still runs once the ad is actually on screen.
     */
    fun markShowing(alias: String) {
        store.update(alias) { it.copy(state = NativeAdState.Shown) }
    }

    /** Undoes [markShowing] for a screen that never appeared, so the ad that is still loaded can be shown later. */
    fun restoreReady(alias: String) {
        store.updateIfPresent(alias) { if (it.state == NativeAdState.Shown) it.copy(state = NativeAdState.Loaded) else it }
    }

    fun loadedAdUnitId(alias: String): String? =
        store[alias]?.loadedAdUnitId

    fun markLoading(alias: String) {
        store.update(alias) { it.copy(state = NativeAdState.Loading) }
    }

    fun notifyState(
        alias: String,
        state: NativeAdState,
        adUnitId: String?,
        errorMessage: String? = null,
        errorCode: Int = -1,
        adSourceId: String = "",
        adSourceName: String = "",
    ) {
        when (state) {
            NativeAdState.Loading -> markLoading(alias)
            NativeAdState.Loaded -> notifyLoaded(alias, adUnitId.orEmpty(), adSourceId, adSourceName)
            NativeAdState.Failed ->
                notifyFailed(alias, adUnitId.orEmpty(), errorMessage ?: "Native ad failed to load", errorCode)
            NativeAdState.Shown -> notifyDisplayed(alias, adUnitId.orEmpty(), "")
            NativeAdState.onClosed -> notifyClosed(alias)
            NativeAdState.Idle -> store.update(alias) { it.copy(state = NativeAdState.Idle) }
        }
    }

    fun notifyLoaded(alias: String, adUnitId: String, adSourceId: String = "", adSourceName: String = "") {
        store.update(alias) { it.copy(state = NativeAdState.Loaded, loadedAdUnitId = adUnitId) }
        val info = FullscreenNativeAdInfo(
            alias = alias,
            adUnitId = adUnitId,
            adSourceId = adSourceId,
            adSourceName = adSourceName,
        )
        store.callback(alias)?.onLoaded(info)
        store.callback(alias)?.onDisplayable(alias)
    }

    fun notifyFailed(alias: String, adUnitId: String, message: String, code: Int = -1) {
        store.update(alias) { it.copy(state = NativeAdState.Failed) }
        store.callback(alias)?.onFailedToLoad(
            FullscreenNativeAdError(
                alias = alias,
                adUnitId = adUnitId,
                code = code,
                message = message,
            ),
        )
    }

    fun notifyDisplayed(
        alias: String,
        adUnitId: String,
        layoutName: String,
    ) {
        val normalizedLayoutName = FullscreenLayoutCatalog.normalize(layoutName)
        val entry = store.update(alias) { it.copy(state = NativeAdState.Shown, displayedLayoutName = normalizedLayoutName) }
        val resolvedAdUnitId = adUnitId.ifBlank { entry.loadedAdUnitId.orEmpty() }
        val info = FullscreenNativeAdInfo(
            alias = alias,
            adUnitId = resolvedAdUnitId,
            layoutName = normalizedLayoutName,
        )
        store.callback(alias)?.onDisplayed(info)
        store.callback(alias)?.onOpened(info)
    }

    fun notifyClicked(alias: String) {
        val entry = store.entry(alias)
        store.callback(alias)?.onClicked(
            FullscreenNativeAdInfo(
                alias = alias,
                adUnitId = entry.loadedAdUnitId.orEmpty(),
                layoutName = entry.displayedLayoutName,
            ),
        )
    }

    fun notifyClosed(alias: String) {
        val entry = store.update(alias) { it.copy(state = NativeAdState.onClosed) }
        store.callback(alias)?.onClosed(
            FullscreenNativeAdInfo(
                alias = alias,
                adUnitId = entry.loadedAdUnitId.orEmpty(),
            ),
        )
    }

    fun shouldReloadAfterShow(alias: String): Boolean =
        store[alias]?.config?.enableReloadAfterShow == true

    fun destroy(alias: String) {
        store.remove(alias)
    }

    private fun FullscreenNativeAdConfig.normalized(fallbackAdUnitId: String): FullscreenNativeAdConfig {
        val normalizedIds = ids.map { it.trim() }.filter { it.isNotEmpty() }
        return copy(
            ids = normalizedIds.ifEmpty { listOf(fallbackAdUnitId) },
            preloadBufferSize = preloadBufferSize.coerceAtLeast(1),
        )
    }
}
