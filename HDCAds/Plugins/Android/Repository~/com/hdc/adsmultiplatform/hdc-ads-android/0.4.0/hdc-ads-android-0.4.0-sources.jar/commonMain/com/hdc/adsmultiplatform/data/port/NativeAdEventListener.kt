package com.hdc.adsmultiplatform.data.port

import com.hdc.adsmultiplatform.domain.model.NativeAdEvent

/** Receives the callbacks of loaded fullscreen native ads. */
internal fun interface NativeAdEventListener {
    fun onAdEvent(instanceId: String, event: NativeAdEvent)
}
