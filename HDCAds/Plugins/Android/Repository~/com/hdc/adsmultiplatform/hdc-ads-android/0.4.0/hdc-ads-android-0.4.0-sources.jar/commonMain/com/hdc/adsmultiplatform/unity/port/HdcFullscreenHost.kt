package com.hdc.adsmultiplatform.unity.port

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions

/**
 * Fullscreen native ads for the bridge. Load, display and close are reported through FullscreenNativeAdRegistry.
 * Called on the main thread only.
 */
internal interface HdcFullscreenHost {
    fun load(id: String, adUnitIds: List<String>, reloadAfterShow: Boolean)

    /** Starts showing a loaded ad; false when it cannot be shown. */
    fun show(id: String, options: FullscreenNativeAdShowOptions): Boolean

    fun hide(id: String)

    fun destroy(id: String)
}
