package com.hdc.adsmultiplatform.api.banner.model

data class BannerNativeAdInfo(
    val alias: String,
    val instanceId: String,
    val adUnitId: String,
    val layoutName: String = "",
)
