package com.hdc.adsmultiplatform.api.event.model

/** The names of [AdTrackingEvent]. */
internal object AdTrackingEventNames {
    const val Impression = "Impression"
    const val Clicked = "Clicked"
    const val Paid = "Paid"
}
