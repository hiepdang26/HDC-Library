package com.hdc.adsmultiplatform.unity.log

import com.hdc.adsmultiplatform.platform.log.AdsLog
import kotlin.concurrent.Volatile

/** The bridge's lines in the library's log. Calls and events are logged only after `init` with `debugLog`. */
internal object HdcLog {
    @Volatile
    var enabled = false

    fun debug(message: String) {
        if (enabled) {
            AdsLog.debug("HDCAds: $message")
        }
    }

    fun warn(message: String) {
        AdsLog.warn("HDCAds: $message")
    }
}
