package com.hdc.adsmultiplatform.unity.model

/**
 * A loaded fullscreen native ad as the reference library's Unity glue reads it: `FSNACallback.ParseNativeAdInfo` calls these getters
 * (`getAdUnitId()`, `getAdSourceId()`, ...).
 */
data class FullscreenNativeAdUnityInfo(
    val adUnitId: String,
    val headline: String?,
    val body: String?,
    val callToAction: String?,
    val advertiser: String?,
    val store: String?,
    val price: String?,
    val mediationAdapter: String?,
    val responseId: String?,
    val adSource: String? = null,
    val adSourceId: String? = null,
)
