package com.hdc.adsmultiplatform.presentation.fullscreen.state.interaction

import com.hdc.adsmultiplatform.domain.repository.FullscreenAdInteractions

/** The fullscreen ads the user clicked or opened, until they come back to the ad; one per app, from the library's container. */
internal class FullscreenNativeAdInteractionRegistry : FullscreenAdInteractions {
    private val interactedInstances = mutableSetOf<String>()

    override fun markInteraction(instanceId: String) {
        interactedInstances += instanceId
    }

    fun consumeInteraction(instanceId: String): Boolean =
        interactedInstances.remove(instanceId)

    fun clear(instanceId: String) {
        interactedInstances -= instanceId
    }
}
