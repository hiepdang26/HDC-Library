package com.hdc.adsmultiplatform.unity.command

import com.hdc.adsmultiplatform.api.log.model.AdsLogLevel
import com.hdc.adsmultiplatform.api.log.sdk.AdsLogging
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.unity.event.HdcEventType
import com.hdc.adsmultiplatform.unity.event.HdcEvents
import com.hdc.adsmultiplatform.unity.event.HdcFormat
import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.log.HdcLog
import com.hdc.adsmultiplatform.unity.port.HdcSdkHost
import com.hdc.adsmultiplatform.unity.thread.hdcRunOnMain
import kotlin.concurrent.Volatile

/**
 * `init` `{debugLog?}` starts the ads SDK once; `Initialized` is sent every time, so a late caller still gets it.
 * `debugLog` true logs every call and event and lifts the library's log to debug level.
 */
internal object HdcSdkCommands {
    private val host: HdcSdkHost by lazy { adsGet() }

    @Volatile
    private var initialized = false

    fun initialize(args: HdcArgs): Boolean {
        if (args.has("debugLog")) {
            val debugLog = args.boolean("debugLog", false)
            HdcLog.enabled = debugLog
            AdsLogging.setLevel(if (debugLog) AdsLogLevel.Debug else null)
        }
        if (initialized) {
            hdcRunOnMain { HdcEvents.emit(id = "", format = HdcFormat.Sdk, type = HdcEventType.Initialized) }
            return true
        }
        host.initialize {
            initialized = true
            HdcEvents.emit(id = "", format = HdcFormat.Sdk, type = HdcEventType.Initialized)
        }
        return true
    }
}
