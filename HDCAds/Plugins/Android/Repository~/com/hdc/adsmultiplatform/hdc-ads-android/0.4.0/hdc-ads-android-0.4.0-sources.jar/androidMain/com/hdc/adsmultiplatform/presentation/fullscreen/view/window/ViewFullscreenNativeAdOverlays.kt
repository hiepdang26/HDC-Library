package com.hdc.adsmultiplatform.presentation.fullscreen.view.window

import android.app.Activity
import android.view.View
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdShowPlan
import com.hdc.adsmultiplatform.presentation.fullscreen.state.interaction.FullscreenNativeAdInteractionRegistry
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port.FullscreenNativeAdOverlays
import com.hdc.adsmultiplatform.presentation.renderer.AndroidNativeAdViewHosts

/** Fullscreen shows drawn without Compose, from the XML designs: the overlays of the Unity library. */
internal class ViewFullscreenNativeAdOverlays(
    private val hosts: AndroidNativeAdViewHosts,
    private val interactions: FullscreenNativeAdInteractionRegistry,
) : FullscreenNativeAdOverlays {
    override fun create(activity: Activity, plan: FullscreenNativeAdShowPlan.Ready, onClose: () -> Unit): View =
        AndroidFullscreenNativeOverlayView(
            activity = activity,
            options = plan.screen,
            adUnitId = plan.adUnitId,
            host = hosts.createFullscreenHost(activity),
            interactions = interactions,
            onClose = onClose,
        )

    override fun release(view: View) = Unit
}
