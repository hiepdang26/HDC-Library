@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.common.viewmodel.port

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/** Cancels a block an [AdRuntimeScheduler] has not run yet. */
@AdsConsoleSupportApi
@HiddenFromObjC
fun interface AdRuntimeCancellation {
    fun cancel()
}
