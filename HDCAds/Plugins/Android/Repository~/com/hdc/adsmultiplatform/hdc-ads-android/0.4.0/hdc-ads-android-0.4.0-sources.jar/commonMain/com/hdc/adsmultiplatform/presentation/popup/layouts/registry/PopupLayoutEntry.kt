package com.hdc.adsmultiplatform.presentation.popup.layouts.registry

/**
 * One popup layout name. [usesMediaView] is false for a compact popup without media, which also takes the compact
 * minimum height. Its design is in its group's folder (`layouts/manual/PopupManualLayoutDesigns.kt`).
 */
internal class PopupLayoutEntry(
    val name: String,
    val usesMediaView: Boolean,
)
