package com.hdc.adsmultiplatform.api.fullscreen.model

import com.hdc.adsmultiplatform.domain.defaults.DefaultNativeAdInstanceId

data class FullscreenNativeAdRequest(
    val instanceId: String = DefaultNativeAdInstanceId,
    val adUnitIds: List<String>,
)
