package com.hdc.adsmultiplatform.unity.command

import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdSourceLayout
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.presentation.popup.layouts.registry.PopupNativeAdLayoutCatalog
import com.hdc.adsmultiplatform.unity.event.HdcEventType
import com.hdc.adsmultiplatform.unity.event.HdcEvents
import com.hdc.adsmultiplatform.unity.event.HdcFormat
import com.hdc.adsmultiplatform.unity.event.HdcNativeStateEvents
import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.port.HdcPopupHost
import com.hdc.adsmultiplatform.unity.thread.hdcQueryOnMain
import com.hdc.adsmultiplatform.unity.thread.hdcRunOnMainCatching
import com.hdc.adsmultiplatform.unity.thread.hdcStartShow

/**
 * `popup.*` commands for native popups placed over the game.
 *
 * - `load` `{id, adUnitIds:[…], layout?, adSourceLayouts?:[{adSources:[…], layout}], timeShow?, timeReload?, x?,
 *   y?, width?, height?, autoClose?, enableCtrOverlay?}`. Sizes are dp. A position with both values in 0..1 is a
 *   normalized center (y from the bottom), otherwise the top-left corner. An ad from a source listed in
 *   `adSourceLayouts` shows that entry's layout; any other ad shows `layout`. Shown events carry `layout`,
 *   `adSourceId` and `adSource` of the ad on screen.
 * - `updatePlacement` `{id, x, y, width, height}`.
 * - `show` returns whether the popup starts to show; one that cannot start after all reports ShowFailed.
 *   `close`, `hide`, `stop`, `destroy` `{id}`.
 * - `isReady`, `isDisplayable` return booleans; `state` returns the display state name.
 */
internal object HdcPopupCommands {
    private val host: HdcPopupHost by lazy { adsGet() }
    private val events = mutableMapOf<String, HdcNativeStateEvents>()

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val defaults = PopupNativeAdConfig(ids = adUnitIds)
        val config = defaults.copy(
            layoutName = args.string("layout").ifBlank { PopupNativeAdLayoutCatalog.Default },
            timeShowSeconds = args.int("timeShow", defaults.timeShowSeconds),
            timeReloadSeconds = args.int("timeReload", defaults.timeReloadSeconds),
            xDp = args.float("x", defaults.xDp),
            yDp = args.float("y", defaults.yDp),
            adWidthDp = args.float("width", defaults.adWidthDp),
            adHeightDp = args.float("height", defaults.adHeightDp),
            autoClose = args.boolean("autoClose", defaults.autoClose),
            enableCtrOverlay = args.boolean("enableCtrOverlay", defaults.enableCtrOverlay),
            adSourceLayouts = args.objList("adSourceLayouts").map { sourceLayout ->
                PopupNativeAdSourceLayout(sourceLayout.stringList("adSources"), sourceLayout.string("layout"))
            },
        )
        hdcRunOnMainCatching(onError = { error -> failed(id, HdcEventType.LoadFailed, error) }) {
            val stateEvents = HdcNativeStateEvents(id, HdcFormat.Popup) { shownFields(id) }
            events[id] = stateEvents
            host.load(id, config, stateEvents)
        }
        return true
    }

    fun updatePlacement(args: HdcArgs): Boolean {
        val id = args.id()
        val x = args.float("x", Float.NaN)
        val y = args.float("y", Float.NaN)
        val width = args.float("width", Float.NaN)
        val height = args.float("height", Float.NaN)
        require(listOf(x, y, width, height).all { it.isFinite() }) { "x, y, width and height are required" }
        hdcRunOnMainCatching(onError = {}) { host.updatePlacement(id, x, y, width, height) }
        return true
    }

    fun show(args: HdcArgs): Boolean {
        val id = args.id()
        val displayable = hdcQueryOnMain(fallback = false) {
            host.isDisplayable(id).also { displayable ->
                if (!displayable) {
                    failed(id, HdcEventType.ShowFailed, IllegalStateException("Popup not displayable: ${host.state(id)}"))
                }
            }
        }
        val notShown = { reason: String ->
            failed(id, HdcEventType.ShowFailed, IllegalStateException("Popup did not show: $reason"))
        }
        return displayable && hdcStartShow(notShown) {
            events[id]?.onShowRequested()
            host.show(id)
            true
        }
    }

    fun close(args: HdcArgs): Boolean = run(args) { host.close(it) }

    fun hide(args: HdcArgs): Boolean = run(args) { host.hide(it) }

    fun stop(args: HdcArgs): Boolean = run(args) { host.stop(it) }

    fun destroy(args: HdcArgs): Boolean =
        run(args) { id ->
            host.destroy(id)
            events.remove(id)
        }

    fun isReady(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { host.isReady(id) }
    }

    fun isDisplayable(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { host.isDisplayable(id) }
    }

    fun state(args: HdcArgs): String {
        val id = args.id()
        return hdcQueryOnMain(fallback = "NotLoaded") { host.state(id) }
    }

    private fun shownFields(id: String): Map<String, Any?> {
        val shown = host.shown(id) ?: return emptyMap()
        return mapOf("layout" to shown.layoutName, "adSourceId" to shown.adSourceId, "adSource" to shown.adSourceName)
    }

    private fun run(args: HdcArgs, block: (String) -> Unit): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { block(id) }
        return true
    }

    private fun failed(id: String, type: String, error: Throwable) {
        HdcEvents.emit(
            id = id,
            format = HdcFormat.Popup,
            type = type,
            fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
        )
    }
}
