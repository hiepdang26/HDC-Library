package com.hdc.adsmultiplatform.api.banner.model

import com.hdc.adsmultiplatform.api.banner.defaults.DefaultBannerNativeAdInstanceId

data class BannerNativeAdRequest(
    val instanceId: String = DefaultBannerNativeAdInstanceId,
    val adUnitIds: List<String>,
)
