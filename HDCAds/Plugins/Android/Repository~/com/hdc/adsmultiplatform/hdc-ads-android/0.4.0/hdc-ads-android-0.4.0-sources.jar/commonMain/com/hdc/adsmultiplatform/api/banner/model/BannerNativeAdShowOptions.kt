package com.hdc.adsmultiplatform.api.banner.model

import com.hdc.adsmultiplatform.presentation.banner.layouts.registry.BannerNativeAdLayoutCatalog

data class BannerNativeAdShowOptions(
    val layoutName: String = BannerNativeAdLayoutCatalog.Default,
    val timeReloadSeconds: Int = 0,
    val timeCountdownSeconds: Int = 5,
    val timeCollapseSeconds: Int = 5,
)
