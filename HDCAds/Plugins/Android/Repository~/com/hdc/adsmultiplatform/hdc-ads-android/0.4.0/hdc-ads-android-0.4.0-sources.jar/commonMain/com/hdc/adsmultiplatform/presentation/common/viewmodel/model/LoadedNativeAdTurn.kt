package com.hdc.adsmultiplatform.presentation.common.viewmodel.model

/**
 * An ad that loaded for one turn of a rotation: the instance it loaded into, the ad unit that filled, when it loaded
 * on the rotation's clock, and the ad source (mediation network) that filled it when the network tells.
 */
internal data class LoadedNativeAdTurn(
    val instanceId: String,
    val adUnitId: String,
    val loadedAtMillis: Long = 0L,
    val adSourceId: String = "",
    val adSourceName: String = "",
)
