package com.hdc.adsmultiplatform.presentation.fullscreen.state

/** What a Unity load of a fullscreen native ad does with what its instance already has. */
internal sealed interface FullscreenNativeAdLoadPlan {
    /** Nothing to keep: a new request goes out. */
    data object Request : FullscreenNativeAdLoadPlan

    /** The same request is still in flight; its result is reported when it arrives. */
    data object KeepLoading : FullscreenNativeAdLoadPlan

    /** The loaded ad is young enough to show, so Loaded is reported again for [adUnitId]. */
    data class KeepLoaded(val adUnitId: String, val ageSeconds: Double) : FullscreenNativeAdLoadPlan
}
