package com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry

/**
 * Every fullscreen layout name the library knows, in catalog order, with its family. The catalogs, the router and the
 * host routing all read this list; nothing else lists layout names. A new layout is its name constant, one entry here
 * and, in a family with designs, its design file plus one design in the family's list (`layouts/<family>/…LayoutDesigns.kt`).
 * A new family is a new folder, a [FullscreenLayoutFamily] constant and one list here.
 */
internal object FullscreenLayoutRegistry {
    val entries: List<FullscreenLayoutEntry> =
        UniversalLayoutEntries +
            TransparentLayoutEntries +
            ClsLayoutEntries +
            NavLayoutEntries +
            ProgressLayoutEntries +
            ProgressClsLayoutEntries +
            LoopLayoutEntries +
            OtherAarLayoutEntries

    private val entriesByName: Map<String, FullscreenLayoutEntry> = entries.associateBy { it.name }

    fun entry(name: String): FullscreenLayoutEntry? = entriesByName[name]

    fun familyOf(name: String): FullscreenLayoutFamily? = entriesByName[name]?.family

    fun names(family: FullscreenLayoutFamily): List<String> =
        entries.filter { it.family == family }.map { it.name }

    fun names(predicate: (FullscreenLayoutEntry) -> Boolean): List<String> =
        entries.filter(predicate).map { it.name }
}

/** The universal layouts, in catalog order. */
private val UniversalLayoutEntries: List<FullscreenLayoutEntry> = listOf(
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal01, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal02, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal03, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal04, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal05, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal06, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal07, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal08, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal09, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal10, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal11, FullscreenLayoutFamily.UNIVERSAL),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Universal12, FullscreenLayoutFamily.UNIVERSAL),
)

/** The CLS layouts, in catalog order. */
private val ClsLayoutEntries: List<FullscreenLayoutEntry> = listOf(
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls01, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls02, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls03, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls04, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls05, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls06, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls07, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls08, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls09, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls10, FullscreenLayoutFamily.CLS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Cls11, FullscreenLayoutFamily.CLS),
)

/** The NAV layouts, in catalog order. They share one design that reads the layout name. */
private val NavLayoutEntries: List<FullscreenLayoutEntry> = listOf(
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Nav01, FullscreenLayoutFamily.NAV),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Nav02, FullscreenLayoutFamily.NAV),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Nav03, FullscreenLayoutFamily.NAV),
)

/** The progress layouts (prgs, prgso), in catalog order. */
private val ProgressLayoutEntries: List<FullscreenLayoutEntry> = listOf(
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Progress01, FullscreenLayoutFamily.PROGRESS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.ProgressOnly01, FullscreenLayoutFamily.PROGRESS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.ProgressOnly02, FullscreenLayoutFamily.PROGRESS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.ProgressOnly03, FullscreenLayoutFamily.PROGRESS),
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.ProgressOnly04, FullscreenLayoutFamily.PROGRESS),
)

/** The progress layouts with a CLS bottom panel. */
private val ProgressClsLayoutEntries: List<FullscreenLayoutEntry> = listOf(
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.ProgressCls01, FullscreenLayoutFamily.PROGRESS_CLS),
)

/** The loop layouts, in catalog order. */
private val LoopLayoutEntries: List<FullscreenLayoutEntry> = listOf(
    FullscreenLayoutEntry(FullscreenNativeAdLayoutCatalog.Loop01, FullscreenLayoutFamily.LOOP),
)

/** The transparent layouts of the AAR. They have no design of their own. */
private val TransparentLayoutEntries: List<FullscreenLayoutEntry> = (1..7).map { index ->
    FullscreenLayoutEntry(
        name = "fs_single_transparent_${index.toString().padStart(2, '0')}",
        family = FullscreenLayoutFamily.TRANSPARENT,
    )
}

/** The other names the AAR accepts, without a design of their own. */
private val OtherAarLayoutEntries: List<FullscreenLayoutEntry> = listOf(
    FullscreenLayoutEntry("fs_single_ctr_01", FullscreenLayoutFamily.CTR),
    FullscreenLayoutEntry("fs_single_ctr_transparent_01", FullscreenLayoutFamily.CTR),
    FullscreenLayoutEntry("fs_multi_01", FullscreenLayoutFamily.MULTI),
    FullscreenLayoutEntry("fs_sequence_01", FullscreenLayoutFamily.SEQUENCE),
)
