package com.hdc.adsmultiplatform.presentation.popup.view.runtime

import android.app.Activity
import com.hdc.adsmultiplatform.api.popup.callback.PopupNativeAdCallback
import com.hdc.adsmultiplatform.api.popup.callback.PopupNativeAdRevenueCallback
import com.hdc.adsmultiplatform.api.popup.defaults.DefaultPopupNativeAdInstanceId
import com.hdc.adsmultiplatform.api.popup.model.PopupNativeAdConfig
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.platform.log.AdsLog
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.AndroidFullscreenNativeAdWindow
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdDisplayState
import com.hdc.adsmultiplatform.presentation.popup.state.PopupNativeAdShown
import com.hdc.adsmultiplatform.presentation.renderer.AndroidNativeAdViewHosts

/**
 * The native popups Unity shows without Compose, placed over an activity's content, by alias: the Android side of the
 * iOS popup runtimes. Several popups can be on screen at once. Call on the main thread.
 */
internal class AndroidPopupRuntimes(
    private val nativeAds: AndroidNativeAdSource,
    private val hosts: AndroidNativeAdViewHosts,
    private val fullscreen: AndroidFullscreenNativeAdWindow,
) {
    private val runtimes = mutableMapOf<String, AndroidPopupRuntime>()
    private val destroyedAliases = mutableSetOf<String>()

    fun create(alias: String, config: PopupNativeAdConfig) {
        val safeAlias = normalizedAlias(alias)
        destroyedAliases.remove(safeAlias)
        runtime(safeAlias).configure(config)
    }

    /** What the ads of [alias] report: loads, failures and clicks to [callback], impressions and paid values to [revenueCallback]. */
    fun setAdCallbacks(alias: String, callback: PopupNativeAdCallback?, revenueCallback: PopupNativeAdRevenueCallback?) {
        runtime(alias).callbacks.apply {
            this.callback = callback
            this.revenueCallback = revenueCallback
        }
    }

    fun setCallback(alias: String, callback: (NativeAdState) -> Unit) {
        runtime(alias).stateCallback = callback
    }

    fun updatePlacement(alias: String, xDp: Float, yDp: Float, adWidthDp: Float, adHeightDp: Float) {
        runtimes[normalizedAlias(alias)]?.updatePlacement(xDp, yDp, adWidthDp, adHeightDp)
    }

    fun load(alias: String, activity: Activity) {
        destroyedAliases.remove(normalizedAlias(alias))
        runtime(alias).load(activity)
    }

    fun show(alias: String, activity: Activity? = null) {
        val safeAlias = normalizedAlias(alias)
        val runtime = runtimes[safeAlias]
        if (runtime == null) {
            popupLog("show skipped alias=$safeAlias reason=missing_runtime")
            return
        }
        if (runtime.isShowing()) {
            popupLog("show skipped alias=$safeAlias reason=already_showing")
            return
        }
        activity?.let { runtime.activity = it }
        runtime.show()
    }

    fun close(alias: String) {
        runtimes[normalizedAlias(alias)]?.close()
    }

    fun hide(alias: String) {
        runtimes[normalizedAlias(alias)]?.hide()
    }

    fun stop(alias: String) {
        runtimes[normalizedAlias(alias)]?.stop()
    }

    fun destroy(alias: String) {
        val safeAlias = normalizedAlias(alias)
        destroyedAliases += safeAlias
        runtimes.remove(safeAlias)?.destroy()
    }

    fun isReady(alias: String): Boolean =
        runtimes[normalizedAlias(alias)]?.isReady() == true

    fun isDisplayable(alias: String): Boolean =
        runtimes[normalizedAlias(alias)]?.isDisplayable() == true

    fun shownAd(alias: String): PopupNativeAdShown? =
        runtimes[normalizedAlias(alias)]?.controller?.shownAd()

    fun stateFor(alias: String): String {
        val safeAlias = normalizedAlias(alias)
        return runtimes[safeAlias]?.stateName()
            ?: if (safeAlias in destroyedAliases) {
                PopupNativeAdDisplayState.Destroyed.name
            } else {
                PopupNativeAdDisplayState.NotLoaded.name
            }
    }

    private fun runtime(alias: String): AndroidPopupRuntime =
        runtimes.getOrPut(normalizedAlias(alias)) {
            AndroidPopupRuntime(normalizedAlias(alias), nativeAds, hosts, fullscreen)
        }

    private fun normalizedAlias(alias: String): String =
        alias.ifBlank { DefaultPopupNativeAdInstanceId }

    private fun popupLog(message: String) {
        AdsLog.debug("AdsMultiplatform Android popup $message")
    }
}
