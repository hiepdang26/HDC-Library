package com.hdc.adsmultiplatform.domain.defaults

/**
 * Stands for an ad unit nobody configured. The repositories resolve it when they request ads: a development build
 * asks for the network's test ad unit, a release build fails the load, so a game that lost its ad unit ids never
 * shows test ads to players.
 */
internal const val UnconfiguredAdUnitId = ""
