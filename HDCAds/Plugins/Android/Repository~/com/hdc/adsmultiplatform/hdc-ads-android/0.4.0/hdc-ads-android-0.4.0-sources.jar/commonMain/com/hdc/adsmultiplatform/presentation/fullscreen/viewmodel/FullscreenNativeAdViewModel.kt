package com.hdc.adsmultiplatform.presentation.fullscreen.viewmodel

import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdMode
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeAdShowOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.withLayoutInferredOverlay
import com.hdc.adsmultiplatform.api.fullscreen.registry.FullscreenNativeAdRegistry
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.domain.parser.parseAdUnitIdsCsv
import com.hdc.adsmultiplatform.domain.repository.FullscreenNativeAdRepository
import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.NativeAdLayoutNames
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdLoadPlan
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdShowPlan

/** Google native ads expire an hour after they load; older ones are loaded again instead of reused. */
private const val ReusableLoadedAdAgeSeconds = 50.0 * 60.0

/**
 * The fullscreen native ad of each instance that Unity drives, shared by the Android and iOS windows. It decides
 * whether a load keeps what the instance has, builds the screen a show draws, and keeps the registry state through
 * load, display and close. The windows put the ad on screen and decide when each step runs.
 */
internal class FullscreenNativeAdViewModel<Host : Any>(
    private val ads: FullscreenNativeAdRepository<Host>,
) {
    private val stateListeners = mutableMapOf<String, (NativeAdState) -> Unit>()

    /** The result each instance's loaded ad came with, so a kept ad is reported with its ad source again. */
    private val loadedResults = mutableMapOf<String, NativeAdLoadResult>()

    /** The config of a load: the ids in [adUnitIdsCsv], or the default ad unit when it lists none. */
    fun loadConfig(adUnitIdsCsv: String, enableReloadAfterShow: Boolean): FullscreenNativeAdConfig {
        val adUnitIds = parseAdUnitIdsCsv(adUnitIdsCsv).ifEmpty { listOf(UnconfiguredAdUnitId) }
        return FullscreenNativeAdConfig(ids = adUnitIds, enableReloadAfterShow = enableReloadAfterShow)
    }

    /**
     * A repeated load for the same ad unit ids keeps what [instanceId] already has, as the reference library does: a loaded ad that is
     * not on screen is reported again instead of being dropped (a filled request that would never show), and a
     * request still in flight is not restarted (its result is still reported). [isOnScreen] tells whether the
     * instance's ad is showing now.
     */
    fun keepLoadedOrLoadingAd(
        instanceId: String,
        config: FullscreenNativeAdConfig,
        isOnScreen: () -> Boolean,
    ): FullscreenNativeAdLoadPlan {
        if (ads.requestedAdUnitIds(instanceId) != config.ids) return FullscreenNativeAdLoadPlan.Request
        if (isOnScreen()) return FullscreenNativeAdLoadPlan.Request
        val loadedAdAgeSeconds = ads.loadedAdAgeSeconds(instanceId)
        return when {
            ads.isLoading(instanceId) -> {
                FullscreenNativeAdRegistry.create(alias = instanceId, config = config)
                FullscreenNativeAdRegistry.markLoading(instanceId)
                FullscreenNativeAdLoadPlan.KeepLoading
            }
            loadedAdAgeSeconds != null && loadedAdAgeSeconds < ReusableLoadedAdAgeSeconds -> {
                val adUnitId = ads.loadedAdUnitId(instanceId).orEmpty()
                val kept = loadedResults[instanceId]
                FullscreenNativeAdRegistry.create(alias = instanceId, config = config)
                FullscreenNativeAdRegistry.notifyState(
                    alias = instanceId,
                    state = NativeAdState.Loaded,
                    adUnitId = adUnitId,
                    adSourceId = kept?.adSourceId.orEmpty(),
                    adSourceName = kept?.adSourceName.orEmpty(),
                )
                FullscreenNativeAdLoadPlan.KeepLoaded(adUnitId = adUnitId, ageSeconds = loadedAdAgeSeconds)
            }
            else -> FullscreenNativeAdLoadPlan.Request
        }
    }

    /** A new load of [config] starts for [instanceId]: the registry forgets the previous one. */
    fun beginLoad(instanceId: String, config: FullscreenNativeAdConfig) {
        FullscreenNativeAdRegistry.create(alias = instanceId, config = config)
    }

    /**
     * Requests the ad and records the result before [onResult] reports it. Unity decides when to load again: a
     * background retry fills ads it never asked to show, and they would pop up whenever Unity hears Loaded.
     */
    fun request(host: Host, instanceId: String, adUnitIds: List<String>, onResult: (NativeAdLoadResult) -> Unit) {
        ads.loadFullscreen(host = host, instanceId = instanceId, adUnitIds = adUnitIds, retryOnFailure = false) { result ->
            if (result.state == NativeAdState.Loaded) {
                loadedResults[instanceId] = result
            }
            FullscreenNativeAdRegistry.notifyState(
                alias = instanceId,
                state = result.state,
                adUnitId = ads.loadedAdUnitId(instanceId) ?: result.adUnitId,
                errorMessage = result.message.ifBlank { null },
                errorCode = result.code,
                adSourceId = result.adSourceId,
                adSourceName = result.adSourceName,
            )
            onResult(result)
        }
    }

    /** The config a reload after close uses: what [instanceId] was loaded with. */
    fun reloadConfig(instanceId: String): FullscreenNativeAdConfig =
        FullscreenNativeAdRegistry.configFor(instanceId, UnconfiguredAdUnitId)

    /** The ad of [instanceId] is on screen, or its screen is built and about to be. */
    fun isShowing(instanceId: String): Boolean =
        FullscreenNativeAdRegistry.stateFor(instanceId) == NativeAdState.Shown

    /**
     * The screen a show of [instanceId] builds from [options]. When the ad is gone the failure is reported and the
     * plan is [FullscreenNativeAdShowPlan.NoLoadedAd].
     */
    fun show(
        instanceId: String,
        options: FullscreenNativeAdShowOptions,
        fallbackAdUnitId: String,
    ): FullscreenNativeAdShowPlan {
        val effectiveOptions = options.toEffectiveShowOptions()
        if (!ads.hasLoadedAd(instanceId)) {
            FullscreenNativeAdRegistry.notifyFailed(
                alias = instanceId,
                adUnitId = fallbackAdUnitId,
                message = "No loaded fullscreen native ad to show",
            )
            return FullscreenNativeAdShowPlan.NoLoadedAd(effectiveOptions)
        }
        return FullscreenNativeAdShowPlan.Ready(
            options = effectiveOptions,
            screen = NativeAdShowOptions(
                instanceId = instanceId,
                layoutName = NativeAdLayoutNames.normalize(effectiveOptions.normalizedLayoutName),
                durationSeconds = effectiveOptions.resolvedDurationSeconds,
                autoClose = effectiveOptions.autoClose,
                orientation = effectiveOptions.orientation,
                pauseGameplay = effectiveOptions.pauseGameplay,
                enableAdComeback = effectiveOptions.enableAdComeback,
                showTCD = effectiveOptions.showTCD,
                delaySeconds = effectiveOptions.delaySeconds,
                timeUpCSeconds = effectiveOptions.timeUpCSeconds,
                mode = effectiveOptions.mode,
                layoutNames = effectiveOptions.normalizedLayoutNames,
                durationsSeconds = effectiveOptions.normalizedDurationsSeconds,
                clickAssets = effectiveOptions.clickAssets,
                assetVisibility = effectiveOptions.assetVisibility,
            ),
            adUnitId = ads.loadedAdUnitId(instanceId) ?: fallbackAdUnitId,
        )
    }

    /** The screen of [instanceId] is built: a second show cannot reuse its ad. */
    fun markShowing(instanceId: String) {
        FullscreenNativeAdRegistry.markShowing(instanceId)
    }

    /** The screen of [instanceId] never appeared: the ad that is still loaded can be shown later. */
    fun showFailed(instanceId: String) {
        if (ads.hasLoadedAd(instanceId)) {
            FullscreenNativeAdRegistry.restoreReady(instanceId)
        }
    }

    /** The ad of [plan] is on screen. */
    fun displayed(instanceId: String, plan: FullscreenNativeAdShowPlan.Ready) {
        FullscreenNativeAdRegistry.notifyDisplayed(
            alias = instanceId,
            adUnitId = plan.adUnitId,
            layoutName = plan.screen.layoutName,
        )
    }

    /** Closing [instanceId] loads its next ad when its config asks for a reload after show. */
    fun shouldReloadAfterClose(instanceId: String): Boolean =
        FullscreenNativeAdRegistry.shouldReloadAfterShow(instanceId)

    /** The shown ad of [instanceId] is used up. */
    fun clearLoaded(instanceId: String) {
        ads.clearLoaded(instanceId)
    }

    /** The screen of [instanceId] closed. */
    fun closed(instanceId: String) {
        FullscreenNativeAdRegistry.notifyClosed(instanceId)
    }

    /** Destroys the ad of [instanceId] and forgets the instance. */
    fun destroy(instanceId: String) {
        ads.destroy(instanceId)
        loadedResults.remove(instanceId)
        FullscreenNativeAdRegistry.destroy(instanceId)
    }

    /** Forgets [instanceId] and drops its loaded ad, as the reference library's destroy on iOS does. */
    fun forget(instanceId: String) {
        FullscreenNativeAdRegistry.destroy(instanceId)
        ads.clearLoaded(instanceId)
        loadedResults.remove(instanceId)
    }

    /** Unity's state callback for the latest load of [instanceId]; a reload after close reports to it too. */
    fun setStateListener(instanceId: String, listener: (NativeAdState) -> Unit) {
        stateListeners[instanceId] = listener
    }

    fun stateListener(instanceId: String): (NativeAdState) -> Unit =
        stateListeners[instanceId] ?: {}

    private fun FullscreenNativeAdShowOptions.toEffectiveShowOptions(): FullscreenNativeAdShowOptions {
        val inferredMode = mode.withLayoutInferredOverlay(normalizedLayoutNames)
        val routedMode = when (inferredMode) {
            FullscreenNativeAdMode.SINGLE ->
                if (pauseGameplay) FullscreenNativeAdMode.SINGLE else FullscreenNativeAdMode.OVERLAY
            FullscreenNativeAdMode.TRANSPARENT ->
                if (pauseGameplay) FullscreenNativeAdMode.TRANSPARENT else FullscreenNativeAdMode.OVERLAY_TRANSPARENT
            FullscreenNativeAdMode.CTR -> FullscreenNativeAdMode.SINGLE
            FullscreenNativeAdMode.OVERLAY_CTR -> FullscreenNativeAdMode.OVERLAY
            else -> inferredMode
        }
        return copy(
            mode = routedMode,
            pauseGameplay = if (routedMode.alwaysPausesGameplay) true else pauseGameplay,
        )
    }
}
