@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.banner.state

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.banner.layouts.registry.BannerNativeAdLayoutCatalog
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
data class BannerNativeAdUiState(
    val state: NativeAdState = NativeAdState.Idle,
    val isVisible: Boolean = false,
    val activeInstanceId: String? = null,
    val activeAdUnitId: String? = null,
    val activeLayoutName: String = BannerNativeAdLayoutCatalog.Default,
    val isExpanded: Boolean = false,
    val expandedCloseClickEnabled: Boolean = false,
    val canCollapseExpanded: Boolean = true,
    val collapseCountdownSecondsRemaining: Int = 0,
    val collapseCountdownProgress: Float = 0f,
    val canCloseCollapsed: Boolean = false,
    val loadingAdUnitIds: Set<String> = emptySet(),
    val readyAdUnitIds: Set<String> = emptySet(),
)
