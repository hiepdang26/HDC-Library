package com.hdc.adsmultiplatform.platform.lock

/**
 * A reentrant lock for state that more than one thread touches: on Android, Unity calls the SDK from its own thread
 * while ad callbacks run on the main thread.
 */
internal expect class AdsLock() {
    fun <T> locked(block: () -> T): T
}
