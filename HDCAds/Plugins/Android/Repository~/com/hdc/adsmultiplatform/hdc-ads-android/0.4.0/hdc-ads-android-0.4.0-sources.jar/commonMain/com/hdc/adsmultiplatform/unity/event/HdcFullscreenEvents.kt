package com.hdc.adsmultiplatform.unity.event

import com.hdc.adsmultiplatform.api.fullscreen.callback.FullscreenNativeAdCallback
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdError
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdInfo
import com.hdc.adsmultiplatform.api.fullscreen.registry.FullscreenNativeAdRegistry
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.unity.thread.hdcPostToMain

/** Forwards one fullscreen instance's registry callbacks to Unity. */
internal class HdcFullscreenEvents(private val id: String) : FullscreenNativeAdCallback {
    override fun onLoaded(ad: FullscreenNativeAdInfo) =
        emit(HdcEventType.Loaded, mapOf("adUnitId" to ad.adUnitId, "adSourceId" to ad.adSourceId, "adSource" to ad.adSourceName))

    // Loading moves on to the next ad unit right after a failure: report it only if the ad is still failed
    // one main loop later.
    override fun onFailedToLoad(error: FullscreenNativeAdError) {
        hdcPostToMain {
            if (FullscreenNativeAdRegistry.stateFor(id) == NativeAdState.Failed) {
                emit(HdcEventType.LoadFailed, mapOf("adUnitId" to error.adUnitId) + HdcEvents.error(error.code, error.message))
            }
        }
    }

    override fun onDisplayed(ad: FullscreenNativeAdInfo) =
        emit(HdcEventType.Shown, mapOf("adUnitId" to ad.adUnitId, "layout" to ad.layoutName))

    override fun onClosed(ad: FullscreenNativeAdInfo) = emit(HdcEventType.Closed, mapOf("adUnitId" to ad.adUnitId))

    private fun emit(type: String, fields: Map<String, Any?>) {
        HdcEvents.emit(id = id, format = HdcFormat.Fullscreen, type = type, fields = fields)
    }
}
