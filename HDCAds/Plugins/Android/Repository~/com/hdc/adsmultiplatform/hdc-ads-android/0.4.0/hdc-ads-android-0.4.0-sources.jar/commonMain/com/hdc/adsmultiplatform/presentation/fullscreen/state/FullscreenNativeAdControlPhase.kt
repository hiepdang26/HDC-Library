package com.hdc.adsmultiplatform.presentation.fullscreen.state

enum class FullscreenNativeAdControlPhase {
    PROGRESS,
    CLOSE_DELAY,
    FINISHED,
}
