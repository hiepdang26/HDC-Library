@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.domain.policy

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

/** Delay before the next retry after failed loads: 4 s, then 8 s, doubling up to 64 s; back to 4 s after a load. */
@AdsConsoleSupportApi
@HiddenFromObjC
class FailureBackoffPolicy {
    private var failureExponent = MinFailureExponent

    fun nextFailureRetryDelayMillis(): Long {
        val exponent = failureExponent.coerceAtMost(MaxFailureExponent)
        failureExponent = (failureExponent + 1).coerceAtMost(MaxFailureExponent)
        return (1L shl exponent) * 1_000L
    }

    fun resetAfterLoaded() {
        failureExponent = MinFailureExponent
    }

    companion object {
        private const val MinFailureExponent = 2
        private const val MaxFailureExponent = 6
    }
}
