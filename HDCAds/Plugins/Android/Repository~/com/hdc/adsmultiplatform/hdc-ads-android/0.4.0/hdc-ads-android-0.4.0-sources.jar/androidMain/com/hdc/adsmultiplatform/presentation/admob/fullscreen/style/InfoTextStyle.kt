package com.hdc.adsmultiplatform.presentation.admob.fullscreen.style

internal data class InfoTextStyle(
    val headlineSizeSp: Float,
    val bodySizeSp: Float,
    val headlineMaxLines: Int,
    val bodyMaxLines: Int,
)
