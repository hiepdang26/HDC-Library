package com.hdc.adsmultiplatform.presentation.banner.view.runtime

import com.hdc.adsmultiplatform.api.common.model.NativeAdPaidInfo
import com.hdc.adsmultiplatform.api.banner.callback.BannerNativeAdCallback
import com.hdc.adsmultiplatform.api.banner.callback.BannerNativeAdRevenueCallback
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdError
import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdInfo

/**
 * The callbacks a banner runtime gives its ViewModel, passed on to the ones set later ([callback], [revenueCallback]):
 * the ViewModel takes its callbacks when it is created, and the game sets them after.
 */
internal class BannerNativeAdCallbackRelay : BannerNativeAdCallback, BannerNativeAdRevenueCallback {
    var callback: BannerNativeAdCallback? = null
    var revenueCallback: BannerNativeAdRevenueCallback? = null

    override fun onLoaded(ad: BannerNativeAdInfo) {
        callback?.onLoaded(ad)
    }

    override fun onDisplayable(alias: String) {
        callback?.onDisplayable(alias)
    }

    override fun onDisplayed(ad: BannerNativeAdInfo) {
        callback?.onDisplayed(ad)
    }

    override fun onOpened(ad: BannerNativeAdInfo) {
        callback?.onOpened(ad)
    }

    override fun onClosed(ad: BannerNativeAdInfo) {
        callback?.onClosed(ad)
    }

    override fun onClicked(ad: BannerNativeAdInfo) {
        callback?.onClicked(ad)
    }

    override fun onFailedToLoad(error: BannerNativeAdError) {
        callback?.onFailedToLoad(error)
    }

    override fun onImpression(ad: BannerNativeAdInfo) {
        revenueCallback?.onImpression(ad)
    }

    override fun onPaidImpression(ad: BannerNativeAdInfo, paidInfo: NativeAdPaidInfo) {
        revenueCallback?.onPaidImpression(ad, paidInfo)
    }
}
