package com.hdc.adsmultiplatform.presentation.banner.layouts.registry

object BannerNativeAdLayoutCatalog {
    const val Default = "bn_single_transparent_01"

    val All: List<String> = (1..20).map { index ->
        "bn_single_transparent_${index.toString().padStart(2, '0')}"
    }

    fun normalize(layoutName: String?): String {
        val rawKey = layoutName?.trim()?.lowercase().orEmpty()
        val key = rawKey
            .removeSuffix("_collapse")
            .removeSuffix("_expand")
        if (key == "bn_single_compose_01") {
            return Default
        }
        return if (key in All) key else Default
    }

    fun collapseCountdownStyle(layoutName: String?): BannerCollapseCountdownStyle =
        when (All.indexOf(normalize(layoutName)) + 1) {
            in 11..15 -> BannerCollapseCountdownStyle.Ring
            in 16..17 -> BannerCollapseCountdownStyle.Horizontal
            in 18..20 -> BannerCollapseCountdownStyle.Segments
            else -> BannerCollapseCountdownStyle.None
        }

    fun hasCollapseCountdown(layoutName: String?): Boolean =
        collapseCountdownStyle(layoutName) != BannerCollapseCountdownStyle.None
}
