package com.hdc.adsmultiplatform.presentation.renderer

import android.view.View
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeAssetVisibilityOptions
import com.hdc.adsmultiplatform.api.fullscreen.model.NativeClickAssetOptions
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.presentation.fullscreen.state.FullscreenNativeAdControlState

/**
 * A fullscreen ad drawn without Compose, from the XML designs: the overlay that Unity drives places [view] and passes
 * it each control state.
 */
internal interface AndroidFullscreenNativeAdHost {
    val view: View

    fun render(
        instanceId: String,
        fallbackAdUnitId: String,
        layoutName: String,
        controlState: FullscreenNativeAdControlState,
        showControls: Boolean = true,
        clickAssets: NativeClickAssetOptions = NativeClickAssetOptions(),
        assetVisibility: NativeAssetVisibilityOptions = NativeAssetVisibilityOptions(),
        onStateChanged: (NativeAdState) -> Unit,
        onClose: (() -> Unit)?,
    )

    fun release()
}
