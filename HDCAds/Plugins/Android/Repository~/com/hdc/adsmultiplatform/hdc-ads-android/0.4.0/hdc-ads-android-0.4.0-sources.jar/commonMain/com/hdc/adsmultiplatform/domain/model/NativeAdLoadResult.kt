package com.hdc.adsmultiplatform.domain.model

data class NativeAdLoadResult(
    val state: NativeAdState,
    val adUnitId: String = "",
    val code: Int = NoErrorCode,
    val message: String = "",
    /** The ad source (mediation network) that filled a loaded ad, as the network reports it. */
    val adSourceId: String = "",
    val adSourceName: String = "",
) {
    val hasErrorCode: Boolean
        get() = code != NoErrorCode

    companion object {
        const val NoErrorCode = -1
    }
}
