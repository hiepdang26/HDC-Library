package com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry

/**
 * A group of fullscreen layouts that the platforms draw the same way. A new layout in an existing family needs no new
 * rule anywhere: the catalogs and the host routing read these flags.
 */
internal enum class FullscreenLayoutFamily(
    /** Android draws it from its XML design (res/layout, found by the layout name) instead of the Compose layout. */
    val hasAndroidXmlDesign: Boolean,
    /** iOS draws it with the UIKit host that mirrors the XML design (IosFullscreenNativeXmlAdHost). */
    val iosUsesUiKitHost: Boolean,
    /** The iOS host fills the whole screen, behind the safe area, like the reference library's edge-to-edge overlay. */
    val drawsEdgeToEdge: Boolean,
    /**
     * Its layouts have a Compose design of their own (`layouts/<family>/…LayoutDesigns.kt`); the others are drawn as
     * `fs_single_universal_01`.
     */
    val hasOwnDesign: Boolean,
) {
    UNIVERSAL(hasAndroidXmlDesign = true, iosUsesUiKitHost = false, drawsEdgeToEdge = false, hasOwnDesign = true),
    TRANSPARENT(hasAndroidXmlDesign = false, iosUsesUiKitHost = false, drawsEdgeToEdge = false, hasOwnDesign = false),
    CLS(hasAndroidXmlDesign = true, iosUsesUiKitHost = false, drawsEdgeToEdge = true, hasOwnDesign = true),
    NAV(hasAndroidXmlDesign = true, iosUsesUiKitHost = true, drawsEdgeToEdge = true, hasOwnDesign = true),
    PROGRESS(hasAndroidXmlDesign = true, iosUsesUiKitHost = true, drawsEdgeToEdge = true, hasOwnDesign = true),
    PROGRESS_CLS(hasAndroidXmlDesign = false, iosUsesUiKitHost = true, drawsEdgeToEdge = true, hasOwnDesign = true),
    LOOP(hasAndroidXmlDesign = true, iosUsesUiKitHost = true, drawsEdgeToEdge = true, hasOwnDesign = true),
    CTR(hasAndroidXmlDesign = false, iosUsesUiKitHost = false, drawsEdgeToEdge = false, hasOwnDesign = false),
    MULTI(hasAndroidXmlDesign = false, iosUsesUiKitHost = false, drawsEdgeToEdge = false, hasOwnDesign = false),
    SEQUENCE(hasAndroidXmlDesign = false, iosUsesUiKitHost = false, drawsEdgeToEdge = false, hasOwnDesign = false),
}
