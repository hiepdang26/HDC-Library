@file:OptIn(ExperimentalObjCRefinement::class)

package com.hdc.adsmultiplatform.presentation.interstitial.viewmodel

import com.hdc.adsmultiplatform.api.annotation.AdsConsoleSupportApi
import com.hdc.adsmultiplatform.api.interstitial.callback.InterstitialAdCallback
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdConfig
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdInfo
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialAdPaidInfo
import com.hdc.adsmultiplatform.api.interstitial.model.InterstitialShowOptions
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.domain.model.NativeAdState
import com.hdc.adsmultiplatform.domain.policy.normalized
import com.hdc.adsmultiplatform.presentation.interstitial.state.InterstitialAdUiState
import com.hdc.adsmultiplatform.presentation.interstitial.viewmodel.port.InterstitialAdLoader
import kotlin.experimental.ExperimentalObjCRefinement
import kotlin.native.HiddenFromObjC

@AdsConsoleSupportApi
@HiddenFromObjC
class InterstitialAdViewModel(
    private val alias: String,
    private val loader: InterstitialAdLoader,
    private val callback: InterstitialAdCallback = object : InterstitialAdCallback {},
    private val onSnapshotChanged: (InterstitialAdUiState) -> Unit = {},
) {
    private var config = InterstitialAdConfig(ids = listOf(UnconfiguredAdUnitId))
    private var snapshot = InterstitialAdUiState()
    private val runtimeCallback = object : InterstitialAdCallback {
        override fun onInterstitialLoaded(ad: InterstitialAdInfo) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Loaded,
                    activeAdUnitId = ad.adUnitId,
                    responseId = ad.responseId,
                    mediationAdapter = ad.mediationAdapter,
                    adSource = ad.adSource,
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - ad.adUnitId,
                    loadedAdUnitIds = snapshot.loadedAdUnitIds + ad.adUnitId,
                    isShowing = false,
                ),
            )
            callback.onInterstitialLoaded(ad)
        }

        override fun onInterstitialDisplayed(ad: InterstitialAdInfo) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Shown,
                    activeAdUnitId = ad.adUnitId,
                    responseId = ad.responseId,
                    mediationAdapter = ad.mediationAdapter,
                    adSource = ad.adSource,
                    loadedAdUnitIds = snapshot.loadedAdUnitIds - ad.adUnitId,
                    isShowing = true,
                ),
            )
            callback.onInterstitialDisplayed(ad)
        }

        override fun onInterstitialOpened(ad: InterstitialAdInfo) {
            callback.onInterstitialOpened(ad)
        }

        override fun onInterstitialClosed(ad: InterstitialAdInfo) {
            publish(
                snapshot.copy(
                    state = NativeAdState.onClosed,
                    activeAdUnitId = ad.adUnitId.ifBlank { snapshot.activeAdUnitId },
                    responseId = ad.responseId.ifBlank { snapshot.responseId },
                    mediationAdapter = ad.mediationAdapter.ifBlank { snapshot.mediationAdapter },
                    adSource = ad.adSource ?: snapshot.adSource,
                    isShowing = false,
                ),
            )
            callback.onInterstitialClosed(ad)
        }

        override fun onInterstitialClicked(ad: InterstitialAdInfo) {
            callback.onInterstitialClicked(ad)
        }

        override fun onInterstitialFailedToLoad(adUnit: String, errorCode: Int, error: String) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Failed,
                    activeAdUnitId = adUnit.ifBlank { snapshot.activeAdUnitId },
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - adUnit,
                    isShowing = false,
                ),
            )
            callback.onInterstitialFailedToLoad(adUnit, errorCode, error)
        }

        override fun onInterstitialPaidImpression(ad: InterstitialAdInfo, paidInfo: InterstitialAdPaidInfo) {
            callback.onInterstitialPaidImpression(ad, paidInfo)
        }

        override fun onInterstitialDisplayable() {
            callback.onInterstitialDisplayable()
        }
    }

    init {
        loader.setCallback(alias, runtimeCallback)
    }

    fun configure(nextConfig: InterstitialAdConfig) {
        val normalized = nextConfig.normalized(UnconfiguredAdUnitId)
        if (normalized == config) {
            loader.setCallback(alias, runtimeCallback)
            return
        }
        config = normalized
        loader.configure(alias, config)
        loader.setCallback(alias, runtimeCallback)
        publish(
            InterstitialAdUiState(
                preloadBufferSize = config.preloadBufferSize,
            ),
        )
    }

    fun load(bufferSize: Int = config.preloadBufferSize) {
        val requestConfig = config.copy(preloadBufferSize = bufferSize.coerceAtLeast(1)).normalized(UnconfiguredAdUnitId)
        if (requestConfig != config) {
            config = requestConfig
            loader.configure(alias, config)
        }
        loader.setCallback(alias, runtimeCallback)
        publish(
            snapshot.copy(
                state = NativeAdState.Loading,
                loadingAdUnitIds = config.ids.toSet(),
                preloadBufferSize = config.preloadBufferSize,
            ),
        )
        loader.load(alias, config.preloadBufferSize) { result ->
            handleLoadResult(result)
        }
    }

    fun show(options: InterstitialShowOptions = InterstitialShowOptions()): Boolean {
        loader.setCallback(alias, runtimeCallback)
        return loader.show(alias, options)
    }

    fun hide() {
        loader.hide(alias)
    }

    fun destroy() {
        loader.setCallback(alias, null)
        loader.destroy(alias)
        config = InterstitialAdConfig(ids = listOf(UnconfiguredAdUnitId))
        publish(InterstitialAdUiState())
    }

    private fun handleLoadResult(result: NativeAdLoadResult) {
        when (result.state) {
            NativeAdState.Loading -> publish(
                snapshot.copy(
                    state = NativeAdState.Loading,
                    loadingAdUnitIds = snapshot.loadingAdUnitIds + result.adUnitId,
                    preloadBufferSize = config.preloadBufferSize,
                ),
            )

            NativeAdState.Loaded -> publish(
                snapshot.copy(
                    state = NativeAdState.Loaded,
                    activeAdUnitId = result.adUnitId.ifBlank { snapshot.activeAdUnitId },
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - result.adUnitId,
                    loadedAdUnitIds = if (result.adUnitId.isBlank()) {
                        snapshot.loadedAdUnitIds
                    } else {
                        snapshot.loadedAdUnitIds + result.adUnitId
                    },
                    preloadBufferSize = config.preloadBufferSize,
                ),
            )

            NativeAdState.Failed -> publish(
                snapshot.copy(
                    state = NativeAdState.Failed,
                    activeAdUnitId = result.adUnitId.ifBlank { snapshot.activeAdUnitId },
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - result.adUnitId,
                    preloadBufferSize = config.preloadBufferSize,
                    isShowing = false,
                ),
            )

            NativeAdState.Shown -> publish(snapshot.copy(state = NativeAdState.Shown, isShowing = true))
            NativeAdState.onClosed -> publish(snapshot.copy(state = NativeAdState.onClosed, isShowing = false))
            NativeAdState.Idle -> publish(snapshot.copy(state = NativeAdState.Idle, isShowing = false))
        }
    }

    private fun publish(nextSnapshot: InterstitialAdUiState) {
        snapshot = nextSnapshot
        onSnapshotChanged(nextSnapshot)
    }
}
