package com.hdc.adsmultiplatform.api.fullscreen.model

import com.hdc.adsmultiplatform.domain.defaults.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.NativeAdLayoutNames

data class NativeAdShowOptions(
    val instanceId: String = DefaultNativeAdInstanceId,
    val layoutName: String = NativeAdLayoutNames.default(),
    val durationSeconds: Double = 0.0,
    val autoClose: Boolean = false,
    val pauseGameplay: Boolean = true,
    val enableAdComeback: Boolean = true,
    val showTCD: Boolean = true,
    val delaySeconds: Double = 0.0,
    val timeUpCSeconds: Int = 0,
    val mode: FullscreenNativeAdMode = FullscreenNativeAdMode.SINGLE,
    val layoutNames: List<String> = emptyList(),
    val durationsSeconds: List<Double> = emptyList(),
    val clickAssets: NativeClickAssetOptions = NativeClickAssetOptions(),
    val assetVisibility: NativeAssetVisibilityOptions = NativeAssetVisibilityOptions(),
    val orientation: String = "auto",
)
