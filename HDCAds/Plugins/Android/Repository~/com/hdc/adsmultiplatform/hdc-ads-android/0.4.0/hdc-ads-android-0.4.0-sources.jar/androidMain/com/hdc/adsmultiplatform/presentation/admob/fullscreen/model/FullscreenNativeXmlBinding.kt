package com.hdc.adsmultiplatform.presentation.admob.fullscreen.model

import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAdView

internal data class FullscreenNativeXmlBinding(
    val adView: NativeAdView,
    val mediaView: MediaView?,
    val iconView: ImageView?,
    val closeIconView: ImageView?,
    val callToActionView: TextView?,
    val headlineView: TextView?,
    val closeHeadlineView: TextView?,
    val bodyView: TextView?,
    val advertiserView: TextView?,
    val adChoicesView: AdChoicesView?,
    val demoImageView: ImageView?,
    val backgroundImageView: ImageView?,
    val closeButtonView: View?,
    val countdownTextView: TextView?,
    val clsProgressView: ProgressBar?,
    val navProgressView: ProgressBar?,
    val prgsProgressView: ProgressBar?,
    val loopProgressView: ProgressBar?,
    val loopLoadingProgressView: ProgressBar?,
    val openStoreButtonView: View?,
)
