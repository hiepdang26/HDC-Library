package com.hdc.adsmultiplatform.api.fullscreen.model

import com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog

data class FullscreenNativeAdShowOptions(
    val layoutName: String = FullscreenLayoutCatalog.SingleDefault,
    val durationSeconds: Double = 5.0,
    val autoClose: Boolean = false,
    val pauseGameplay: Boolean = true,
    val mode: FullscreenNativeAdMode = FullscreenNativeAdMode.SINGLE,
    val layoutNames: List<String> = emptyList(),
    val durationsSeconds: List<Double> = emptyList(),
    val orientation: String = "auto",
    val enableAdComeback: Boolean = true,
    val showTCD: Boolean = true,
    val delaySeconds: Double = 0.0,
    val timeUpCSeconds: Int = 0,
    val clickAssets: NativeClickAssetOptions = NativeClickAssetOptions(),
    val assetVisibility: NativeAssetVisibilityOptions = NativeAssetVisibilityOptions(),
) {
    val normalizedLayoutNames: List<String> =
        normalizeLayoutNames(
            candidates = layoutNames.ifEmpty { listOf(layoutName) },
            keepDuplicates = mode.keepsDuplicateLayouts,
        )

    val normalizedLayoutName: String = normalizedLayoutNames.firstOrNull() ?: FullscreenLayoutCatalog.SingleDefault

    val normalizedDurationsSeconds: List<Double> =
        durationsSeconds.filter { it > 0.0 }

    val resolvedDurationSeconds: Double =
        when {
            mode == FullscreenNativeAdMode.SEQUENCE && normalizedDurationsSeconds.isNotEmpty() ->
                normalizedDurationsSeconds.first()
            durationSeconds > 0.0 -> durationSeconds
            normalizedDurationsSeconds.isNotEmpty() -> normalizedDurationsSeconds.first()
            else -> 0.0
        }

    companion object {
        private fun normalizeLayoutNames(candidates: List<String>, keepDuplicates: Boolean): List<String> {
            val normalized = candidates
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .map { FullscreenLayoutCatalog.normalize(it) }

            return if (keepDuplicates) normalized else normalized.distinct()
        }
    }
}
