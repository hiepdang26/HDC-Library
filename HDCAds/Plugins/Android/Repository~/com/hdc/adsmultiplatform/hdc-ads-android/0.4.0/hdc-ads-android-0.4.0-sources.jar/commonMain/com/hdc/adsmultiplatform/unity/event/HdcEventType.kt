package com.hdc.adsmultiplatform.unity.event

/** The `type` of a bridge event. */
internal object HdcEventType {
    const val Initialized = "Initialized"
    const val Loaded = "Loaded"
    const val LoadFailed = "LoadFailed"
    const val Shown = "Shown"
    const val ShowFailed = "ShowFailed"
    const val Impression = "Impression"
    const val Clicked = "Clicked"
    const val Paid = "Paid"
    const val Closed = "Closed"
}
