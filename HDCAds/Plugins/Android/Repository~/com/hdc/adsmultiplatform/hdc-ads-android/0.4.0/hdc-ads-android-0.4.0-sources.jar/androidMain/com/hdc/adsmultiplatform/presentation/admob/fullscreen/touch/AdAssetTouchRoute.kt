package com.hdc.adsmultiplatform.presentation.admob.fullscreen.touch

import android.view.View

internal class AdAssetTouchRoute private constructor(
    val target: View?,
    val consumeOnly: Boolean,
) {
    companion object {
        val Self = AdAssetTouchRoute(target = null, consumeOnly = false)
        val Consume = AdAssetTouchRoute(target = null, consumeOnly = true)
        fun Forward(target: View): AdAssetTouchRoute =
            AdAssetTouchRoute(target = target, consumeOnly = false)
    }
}
