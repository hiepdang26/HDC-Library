package com.hdc.adsmultiplatform.domain.model

internal data class NativeAdPlacement(
    val format: NativeAdFormat,
    val instanceId: String,
) {
    /** Popup and banner runtimes load with `"<alias>:<format>:<turn>:<key>"`; the host only knows `<alias>`. */
    fun hostAlias(): String {
        val marker = when (format) {
            NativeAdFormats.Popup -> ":popup:"
            NativeAdFormats.Banner -> ":banner:"
            else -> return instanceId
        }
        return if (instanceId.contains(marker)) instanceId.substringBefore(marker) else instanceId
    }
}
