package com.hdc.adsmultiplatform.presentation.popup.layouts.registry

object PopupNativeAdLayoutCatalog {
    const val PopupSingleManual01 = "popup_single_manual_01"
    const val PopupSingleManual02 = "popup_single_manual_02"
    const val PopupSingleManual03 = "popup_single_manual_03"
    const val PopupSingleManual04 = "popup_single_manual_04"
    const val PopupSingleManual05 = "popup_single_manual_05"
    const val PopupSingleManual06 = "popup_single_manual_06"
    const val PopupSingleManual07 = "popup_single_manual_07"
    const val PopupSingleManual08 = "popup_single_manual_08"
    const val PopupSingleManual09 = "popup_single_manual_09"
    const val PopupSingleManual10 = "popup_single_manual_10"
    const val PopupSingleManual11 = "popup_single_manual_11"
    const val PopupSingleManual12 = "popup_single_manual_12"
    const val PopupSingleManual13 = "popup_single_manual_13"
    const val PopupSingleManual14 = "popup_single_manual_14"
    const val PopupSingleManual15 = "popup_single_manual_15"
    const val Default = PopupSingleManual01
    const val MinWidthDp = 300f
    const val MinHeightDp = 250f
    const val MinCompactHeightDp = 66f

    val All: List<String> = PopupLayoutRegistry.entries.map { it.name }

    fun normalize(layoutName: String?): String {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        return if (key in All) key else Default
    }

    fun usesMediaView(layoutName: String?): Boolean =
        PopupLayoutRegistry.entry(normalize(layoutName))?.usesMediaView ?: true

    @Suppress("UNUSED_PARAMETER")
    fun usesAdChoicesView(layoutName: String?): Boolean = true

    fun minHeightDp(layoutName: String?): Float =
        if (usesMediaView(layoutName)) MinHeightDp else MinCompactHeightDp
}
