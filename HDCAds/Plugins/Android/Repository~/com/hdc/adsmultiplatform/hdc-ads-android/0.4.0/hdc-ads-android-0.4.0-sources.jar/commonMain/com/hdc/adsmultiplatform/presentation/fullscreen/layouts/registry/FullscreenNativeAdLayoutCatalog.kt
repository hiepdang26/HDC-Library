package com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry

// File này là danh sách tên layout fullscreen ad mà thư viện đang hỗ trợ.
// Nó giúp chọn đúng layout và có layout mặc định khi tên truyền vào không hợp lệ.
// Các danh sách đọc từ FullscreenLayoutRegistry, nên layout mới chỉ cần đăng ký ở đó.

object FullscreenNativeAdLayoutCatalog {
    const val Universal01 = "fs_single_universal_01"
    const val Universal02 = "fs_single_universal_02"
    const val Universal03 = "fs_single_universal_03"
    const val Universal04 = "fs_single_universal_04"
    const val Universal05 = "fs_single_universal_05"
    const val Universal06 = "fs_single_universal_06"
    const val Universal07 = "fs_single_universal_07"
    const val Universal08 = "fs_single_universal_08"
    const val Universal09 = "fs_single_universal_09"
    const val Universal10 = "fs_single_universal_10"
    const val Universal11 = "fs_single_universal_11"
    const val Universal12 = "fs_single_universal_12"
    const val Cls01 = "fs_single_cls_01"
    const val Cls02 = "fs_single_cls_02"
    const val Cls03 = "fs_single_cls_03"
    const val Cls04 = "fs_single_cls_04"
    const val Cls05 = "fs_single_cls_05"
    const val Cls06 = "fs_single_cls_06"
    const val Cls07 = "fs_single_cls_07"
    const val Cls08 = "fs_single_cls_08"
    const val Cls09 = "fs_single_cls_09"
    const val Cls10 = "fs_single_cls_10"
    const val Cls11 = "fs_single_cls_11"
    const val Nav01 = "fs_single_nav_01"
    const val Nav02 = "fs_single_nav_02"
    const val Nav03 = "fs_single_nav_03"
    const val Progress01 = "fs_single_prgs_01"
    const val ProgressCls01 = "fs_single_prgs_cls_01"
    const val ProgressOnly01 = "fs_single_prgso_01"
    const val ProgressOnly02 = "fs_single_prgso_02"
    const val ProgressOnly03 = "fs_single_prgso_03"
    const val ProgressOnly04 = "fs_single_prgso_04"
    const val Loop01 = "fs_single_loop_01"

    val universal: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.UNIVERSAL)
    val cls: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.CLS)
    val firstClsLayouts: List<String> = listOf(
        Cls01,
        Cls02,
        Cls03,
    )
    val nav: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.NAV)
    val progress: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.PROGRESS)
    val progressCls: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.PROGRESS_CLS)
    val loop: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.LOOP)

    /** The layouts with a Compose design of their own (universal, cls, nav, progress, prgs_cls, loop). */
    val supported: List<String> = FullscreenLayoutRegistry.names { it.family.hasOwnDesign }

    fun normalize(layoutName: String): String {
        val key = layoutName.trim().lowercase()
        return if (key in supported) key else Universal01
    }

    fun requiresDetachedLandscapeControl(layoutName: String): Boolean = false
}
