package com.hdc.adsmultiplatform.unity.compat

import android.app.Activity
import com.hdc.adsmultiplatform.api.fullscreen.model.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.api.fullscreen.registry.FullscreenNativeAdRegistry
import com.hdc.adsmultiplatform.data.source.AndroidNativeAdSource
import com.hdc.adsmultiplatform.platform.log.AdsLog
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.AndroidFullscreenNativeAdWindow
import com.hdc.adsmultiplatform.unity.callback.FullscreenNativeAdUnityCallbacks
import com.hdc.adsmultiplatform.unity.json.parseFullscreenShowOptionsJson
import java.util.concurrent.ConcurrentHashMap

/**
 * Fullscreen native ads created through the reference library's `AdsPublicApi`-style calls (`create("FULLSCREEN", ...)`, `preloadAll`,
 * `show(activity, alias, json)`), so the reference library's Unity flow drives this library without its own glue.
 */
internal class FullscreenNativeAdUnityCompat(
    private val ads: AndroidNativeAdSource,
    private val fullscreen: AndroidFullscreenNativeAdWindow,
    private val callbacks: FullscreenNativeAdUnityCallbacks,
) {
    private val configs = ConcurrentHashMap<String, FullscreenNativeAdConfig>()

    fun create(alias: String, config: FullscreenNativeAdConfig) {
        configs[alias] = config
        FullscreenNativeAdRegistry.create(alias = alias, config = config)
    }

    fun isFullscreen(alias: String): Boolean = configs.containsKey(alias)

    fun load(activity: Activity, alias: String, adUnitIds: List<String>? = null): Boolean {
        val config = configs[alias] ?: return false
        fullscreen.load(
            activity = activity,
            instanceId = alias,
            adUnitIdsCsv = (adUnitIds ?: config.ids).joinToString(","),
            enableReloadAfterShow = config.enableReloadAfterShow,
        )
        return true
    }

    /** False when there is no loaded ad to show: the reference library's glue then gets no callback for this show. */
    fun show(activity: Activity, alias: String, optionsJson: String?): Boolean {
        val config = configs[alias] ?: return false
        if (!ads.hasLoadedAd(alias)) {
            AdsLog.warn("Fullscreen native show rejected: alias=$alias reason=not_loaded")
            return false
        }
        val options = runCatching { parseFullscreenShowOptionsJson(optionsJson) }.getOrElse { error ->
            AdsLog.warn("Fullscreen native show rejected: alias=$alias reason=bad_options error=${error.message}")
            return false
        }
        fullscreen.show(
            activity = activity,
            instanceId = alias,
            options = options,
            fallbackAdUnitId = ads.loadedAdUnitId(alias) ?: config.ids.first(),
        )
        return true
    }

    fun destroy(alias: String) {
        configs.remove(alias)
        callbacks.remove(alias)
    }
}
