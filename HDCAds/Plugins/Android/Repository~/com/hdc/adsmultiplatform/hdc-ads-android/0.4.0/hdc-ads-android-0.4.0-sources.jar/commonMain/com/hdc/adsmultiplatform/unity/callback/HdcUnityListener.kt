@file:OptIn(ExperimentalObjCName::class)

package com.hdc.adsmultiplatform.unity.callback

import kotlin.experimental.ExperimentalObjCName
import kotlin.native.ObjCName

/** Receives bridge events. Each event is a JSON object: `{"id":…,"format":…,"type":…}` plus its fields. */
@ObjCName("HDCUnityListener", exact = true)
fun interface HdcUnityListener {
    fun onEvent(eventJson: String)
}
