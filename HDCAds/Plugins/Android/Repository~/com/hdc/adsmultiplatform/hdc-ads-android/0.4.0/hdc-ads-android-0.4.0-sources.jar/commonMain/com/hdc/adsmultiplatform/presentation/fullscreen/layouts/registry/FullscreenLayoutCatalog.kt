package com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry

object FullscreenLayoutCatalog {
    const val SingleDefault = "fs_single_universal_01"
    const val MultipleDefault = "fs_multi_01"
    const val SequenceDefault = "fs_sequence_01"
    const val SingleCtr = "fs_single_ctr_01"
    const val SingleCtrTransparent = "fs_single_ctr_transparent_01"
    const val ProgressDefault = "fs_single_prgs_01"
    const val ProgressOnly01 = "fs_single_prgso_01"
    const val ProgressOnly02 = "fs_single_prgso_02"
    const val ProgressOnly03 = "fs_single_prgso_03"
    const val ProgressOnly04 = "fs_single_prgso_04"
    const val LoopDefault = "fs_single_loop_01"
    const val ProgressClsDefault = "fs_single_prgs_cls_01"
    const val Nav01 = "fs_single_nav_01"
    const val Nav02 = "fs_single_nav_02"
    const val Nav03 = "fs_single_nav_03"

    val SingleLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.UNIVERSAL)
    val AarSingleUniversalLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.UNIVERSAL)
    val AarSingleTransparentLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.TRANSPARENT)
    val AarClsLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.CLS)
    val AarNavLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.NAV)
    val AarProgressLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.PROGRESS)
    val AarLoopLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.LOOP)

    /** The layouts Android draws from an XML design (universal, cls, nav, progress, loop). */
    val AndroidXmlParityLayouts: List<String> = FullscreenLayoutRegistry.names { it.family.hasAndroidXmlDesign }
    val AarProgressClsLayouts: List<String> = FullscreenLayoutRegistry.names(FullscreenLayoutFamily.PROGRESS_CLS)

    /** Every name the AAR accepts, in its order: the layout families, then ctr, ctr_transparent, multi and sequence. */
    val AarFullscreenLayouts: List<String> = FullscreenLayoutRegistry.entries.map { it.name }
    val AllLayouts: List<String> = AarFullscreenLayouts

    fun normalize(layoutName: String?): String {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        if (key.isBlank()) {
            return SingleDefault
        }

        return if (key in AarFullscreenLayouts) key else SingleDefault
    }

    fun isFullscreenLayoutName(layoutName: String?): Boolean {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        return key in AarFullscreenLayouts
    }

    fun isAndroidXmlParityLayoutName(layoutName: String?): Boolean {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        return key in AndroidXmlParityLayouts
    }
}
