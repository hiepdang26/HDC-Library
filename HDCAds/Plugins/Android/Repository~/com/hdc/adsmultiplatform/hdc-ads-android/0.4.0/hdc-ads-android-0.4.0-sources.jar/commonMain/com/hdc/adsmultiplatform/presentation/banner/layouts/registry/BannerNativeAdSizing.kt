package com.hdc.adsmultiplatform.presentation.banner.layouts.registry

object BannerNativeAdSizing {
    const val MinExpandedHeightPortraitDp = 260f
    const val MinExpandedHeightLandscapeDp = 260f
    const val HeightRatioPortrait = 0.08f
    const val HeightRatioLandscape = 0.15f
    const val ExpandedHeightRatioPortrait = 0.45f
    const val ExpandedHeightRatioLandscape = 0.55f

    /**
     * Height of the banner overlay in a viewport [viewportHeight] tall (dp, or points on iOS): a share of the viewport,
     * larger and with a minimum while expanded.
     */
    internal fun overlayHeight(isExpanded: Boolean, viewportHeight: Double, isLandscape: Boolean): Double {
        if (!isExpanded) {
            val ratio = if (isLandscape) HeightRatioLandscape else HeightRatioPortrait
            return viewportHeight * ratio
        }
        val ratio = if (isLandscape) ExpandedHeightRatioLandscape else ExpandedHeightRatioPortrait
        val minimum = (if (isLandscape) MinExpandedHeightLandscapeDp else MinExpandedHeightPortraitDp).toDouble()
        return (viewportHeight * ratio).coerceIn(minimum.coerceAtMost(viewportHeight), viewportHeight)
    }
}
