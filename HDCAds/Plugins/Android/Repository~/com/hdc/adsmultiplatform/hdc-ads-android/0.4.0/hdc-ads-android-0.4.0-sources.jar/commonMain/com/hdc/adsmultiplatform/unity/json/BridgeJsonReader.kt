package com.hdc.adsmultiplatform.unity.json

/**
 * Minimal JSON reader: objects become maps, arrays lists, numbers doubles. The show options nest objects whose
 * keys repeat (`cta` in both `clickAssets` and `assetVisibility`), which a key search cannot tell apart.
 */
internal class BridgeJsonReader(private val text: String) {
    private var index = 0

    fun readRoot(): Any? {
        val value = readValue()
        skipWhitespace()
        require(index == text.length) { "Unexpected trailing JSON at $index" }
        return value
    }

    private fun readValue(): Any? {
        skipWhitespace()
        require(index < text.length) { "Unexpected end of JSON" }
        return when (val char = text[index]) {
            '{' -> readObject()
            '[' -> readArray()
            '"' -> readString()
            't' -> readLiteral("true", true)
            'f' -> readLiteral("false", false)
            'n' -> readLiteral("null", null)
            else -> if (char == '-' || char.isDigit()) readNumber() else throw IllegalArgumentException("Unexpected '$char' at $index")
        }
    }

    private fun readObject(): Map<String, Any?> {
        index++ // {
        val result = LinkedHashMap<String, Any?>()
        skipWhitespace()
        if (peek() == '}') {
            index++
            return result
        }
        while (true) {
            skipWhitespace()
            val key = readString()
            skipWhitespace()
            expect(':')
            result[key] = readValue()
            skipWhitespace()
            when (next()) {
                ',' -> continue
                '}' -> return result
                else -> throw IllegalArgumentException("Expected ',' or '}' at ${index - 1}")
            }
        }
    }

    private fun readArray(): List<Any?> {
        index++ // [
        val result = ArrayList<Any?>()
        skipWhitespace()
        if (peek() == ']') {
            index++
            return result
        }
        while (true) {
            result += readValue()
            skipWhitespace()
            when (next()) {
                ',' -> continue
                ']' -> return result
                else -> throw IllegalArgumentException("Expected ',' or ']' at ${index - 1}")
            }
        }
    }

    private fun readString(): String {
        expect('"')
        val builder = StringBuilder()
        while (true) {
            val char = next()
            when (char) {
                '"' -> return builder.toString()
                '\\' -> when (val escaped = next()) {
                    '"', '\\', '/' -> builder.append(escaped)
                    'b' -> builder.append('\b')
                    'f' -> builder.append('\u000C')
                    'n' -> builder.append('\n')
                    'r' -> builder.append('\r')
                    't' -> builder.append('\t')
                    'u' -> {
                        require(index + 4 <= text.length) { "Bad unicode escape at $index" }
                        builder.append(text.substring(index, index + 4).toInt(16).toChar())
                        index += 4
                    }
                    else -> throw IllegalArgumentException("Bad escape '\\$escaped' at ${index - 1}")
                }
                else -> builder.append(char)
            }
        }
    }

    private fun readNumber(): Double {
        val start = index
        while (index < text.length && (text[index].isDigit() || text[index] in "+-.eE")) index++
        return text.substring(start, index).toDoubleOrNull()
            ?: throw IllegalArgumentException("Bad number at $start")
    }

    private fun readLiteral(literal: String, value: Any?): Any? {
        require(text.startsWith(literal, index)) { "Expected $literal at $index" }
        index += literal.length
        return value
    }

    private fun skipWhitespace() {
        while (index < text.length && text[index].isWhitespace()) index++
    }

    private fun peek(): Char? = text.getOrNull(index)

    private fun next(): Char {
        require(index < text.length) { "Unexpected end of JSON" }
        return text[index++]
    }

    private fun expect(char: Char) {
        val actual = next()
        require(actual == char) { "Expected '$char' at ${index - 1} but was '$actual'" }
    }
}
