package com.hdc.adsmultiplatform.api.popup.model

data class PopupNativeAdInfo(
    val alias: String,
    val instanceId: String,
    val adUnitId: String,
    val layoutName: String,
)
