package com.hdc.adsmultiplatform.unity.command

import com.hdc.adsmultiplatform.api.banner.model.BannerNativeAdConfig
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.model.NativeAdLoadResult
import com.hdc.adsmultiplatform.presentation.banner.layouts.registry.BannerNativeAdLayoutCatalog
import com.hdc.adsmultiplatform.unity.event.HdcEventType
import com.hdc.adsmultiplatform.unity.event.HdcEvents
import com.hdc.adsmultiplatform.unity.event.HdcFormat
import com.hdc.adsmultiplatform.unity.event.HdcNativeStateEvents
import com.hdc.adsmultiplatform.unity.json.HdcArgs
import com.hdc.adsmultiplatform.unity.port.HdcBannerHost
import com.hdc.adsmultiplatform.unity.thread.hdcQueryOnMain
import com.hdc.adsmultiplatform.unity.thread.hdcRunOnMainCatching

/**
 * `banner.*` commands for the native banner at the bottom of the screen.
 *
 * - `load` `{id, adUnitIds:[…], layoutNames?, timeReload?, timeCountdown?, timeCollapse?}`.
 * - `show`, `hide`, `collapse`, `destroy` `{id}`; `expand` `{id, enableClick?}` returns whether it expanded.
 */
internal object HdcBannerCommands {
    private val host: HdcBannerHost by lazy { adsGet() }

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val defaults = BannerNativeAdConfig(ids = adUnitIds)
        val config = defaults.copy(
            layoutNames = args.stringList("layoutNames").ifEmpty { BannerNativeAdLayoutCatalog.All },
            timeReloadSeconds = args.int("timeReload", defaults.timeReloadSeconds),
            timeCountdownSeconds = args.int("timeCountdown", defaults.timeCountdownSeconds),
            timeCollapseSeconds = args.int("timeCollapse", defaults.timeCollapseSeconds),
        )
        hdcRunOnMainCatching(
            onError = { error ->
                HdcEvents.emit(
                    id = id,
                    format = HdcFormat.Banner,
                    type = HdcEventType.LoadFailed,
                    fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
                )
            },
        ) {
            host.load(id, config, HdcNativeStateEvents(id, HdcFormat.Banner))
        }
        return true
    }

    fun show(args: HdcArgs): Boolean = run(args) { host.show(it) }

    fun hide(args: HdcArgs): Boolean = run(args) { host.hide(it) }

    fun collapse(args: HdcArgs): Boolean = run(args) { host.collapse(it) }

    fun destroy(args: HdcArgs): Boolean = run(args) { host.destroy(it) }

    fun expand(args: HdcArgs): Boolean {
        val id = args.id()
        val enableClick = args.boolean("enableClick", true)
        return hdcQueryOnMain(fallback = false) { host.expand(id, enableClick) }
    }

    private fun run(args: HdcArgs, block: (String) -> Unit): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { block(id) }
        return true
    }
}
