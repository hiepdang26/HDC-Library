package com.hdc.adsmultiplatform.platform.device

interface Platform {
    val name: String
}

expect fun getPlatform(): Platform
