package com.hdc.adsmultiplatform.api.annotation

/**
 * Marks library internals that only the ads console of the sample apps (module `console-test`) may use.
 * They are not part of the API that games call and can change without notice.
 */
@RequiresOptIn(
    message = "Only for the ads console of the sample apps; not part of the library API.",
    level = RequiresOptIn.Level.ERROR,
)
@Retention(AnnotationRetention.BINARY)
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.CONSTRUCTOR,
    AnnotationTarget.TYPEALIAS,
)
annotation class AdsConsoleSupportApi
