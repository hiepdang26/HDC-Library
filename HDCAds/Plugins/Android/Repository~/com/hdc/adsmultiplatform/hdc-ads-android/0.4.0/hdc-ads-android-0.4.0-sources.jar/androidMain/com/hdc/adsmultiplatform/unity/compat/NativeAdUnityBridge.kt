package com.hdc.adsmultiplatform.unity.compat

import android.app.Activity
import android.content.Context
import com.hdc.adsmultiplatform.api.interstitial.callback.InterstitialAdCallback
import com.hdc.adsmultiplatform.api.interstitial.defaults.DefaultInterstitialAdInstanceId
import com.hdc.adsmultiplatform.api.interstitial.sdk.AndroidInterstitialAdSdk
import com.hdc.adsmultiplatform.data.mediation.meta.sdk.AndroidMetaTestDeviceSdk
import com.hdc.adsmultiplatform.di.adsGet
import com.hdc.adsmultiplatform.domain.defaults.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.domain.defaults.UnconfiguredAdUnitId
import com.hdc.adsmultiplatform.platform.log.AdsLog
import com.hdc.adsmultiplatform.unity.callback.FullscreenNativeAdUnityCallback
import com.hdc.adsmultiplatform.unity.callback.FullscreenNativeAdUnityCallbacks
import com.hdc.adsmultiplatform.unity.json.parseFullscreenAdConfigJson
import com.hdc.adsmultiplatform.unity.json.parseInterstitialAdConfigJson
import com.hdc.adsmultiplatform.unity.json.parseInterstitialShowOptionsJson

object NativeAdUnityBridge {
    @JvmStatic
    @JvmOverloads
    fun load(activity: Activity, adUnitId: String = UnconfiguredAdUnitId) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.load(activity, adUnitId)
    }

    @JvmStatic
    @JvmOverloads
    fun loadFullscreen(
        activity: Activity,
        instanceId: String = DefaultNativeAdInstanceId,
        adUnitIdsCsv: String = UnconfiguredAdUnitId,
        enableReloadAfterShow: Boolean = true,
    ) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.loadFullscreen(
            activity = activity,
            instanceId = instanceId,
            adUnitIdsCsv = adUnitIdsCsv,
            enableReloadAfterShow = enableReloadAfterShow,
        )
    }

    @JvmStatic
    fun create(
        activity: Activity,
        type: String,
        alias: String,
        configJson: String,
    ): Boolean =
        when {
            type.equals("INTERSTITIAL", ignoreCase = true) -> createInterstitial(activity, alias, configJson)
            type.equals("FULLSCREEN", ignoreCase = true) -> createFullscreen(activity, alias, configJson)
            else -> false
        }

    /**
     * The reference library's `create(activity, "FULLSCREEN", alias, AndroidNAConfig json)`. With [setFullscreenNativeCallback],
     * `preloadAll`, `isReady`, `show(activity, alias, json)` and `destroy`, the reference library's Unity fullscreen native glue
     * (AndroidFSNativeInstance) runs on this library.
     */
    @JvmStatic
    fun createFullscreen(
        activity: Activity,
        alias: String,
        configJson: String,
    ): Boolean =
        runCatching {
            adsGet<FullscreenNativeAdUnityCompat>().create(alias, parseFullscreenAdConfigJson(configJson, UnconfiguredAdUnitId))
            true
        }.getOrElse { error ->
            AdsLog.warn("Fullscreen native create failed: alias=$alias error=${error.message}")
            false
        }

    @JvmStatic
    fun setFullscreenNativeCallback(alias: String, callback: FullscreenNativeAdUnityCallback?): Boolean {
        adsGet<FullscreenNativeAdUnityCallbacks>().set(alias, callback)
        return true
    }

    @JvmStatic
    fun getLatestNativeMediationAdapter(alias: String): String? =
        adsGet<FullscreenNativeAdUnityCallbacks>().latestMediationAdapter(alias)

    /**
     * The reference library's `show(activity, alias, optionsJson)` for an alias created as FULLSCREEN or INTERSTITIAL. False when
     * there is nothing loaded to show; no callback follows then.
     */
    @JvmStatic
    fun show(activity: Activity, alias: String, optionsJson: String?): Boolean =
        if (adsGet<FullscreenNativeAdUnityCompat>().isFullscreen(alias)) {
            adsGet<FullscreenNativeAdUnityCompat>().show(activity, alias, optionsJson)
        } else {
            showInterstitial(activity, alias, optionsJson)
        }

    @JvmStatic
    fun createInterstitial(
        activity: Activity,
        alias: String,
        configJson: String,
    ): Boolean =
        runCatching {
            val config = parseInterstitialAdConfigJson(configJson)
            AndroidInterstitialAdSdk.create(
                alias = alias,
                adUnitIdsCsv = config.ids.joinToString(","),
                preloadBufferSize = config.preloadBufferSize,
                autoReload = config.autoReload,
            )
            true
        }.getOrElse { error ->
            AdsLog.warn("Interstitial create failed: alias=$alias error=${error.message}")
            false
        }

    @JvmStatic
    @JvmOverloads
    fun createInterstitial(
        alias: String = DefaultInterstitialAdInstanceId,
        adUnitIdsCsv: String = UnconfiguredAdUnitId,
        preloadBufferSize: Int = 1,
        autoReload: Boolean = true,
    ) {
        AndroidInterstitialAdSdk.create(
            alias = alias,
            adUnitIdsCsv = adUnitIdsCsv,
            preloadBufferSize = preloadBufferSize,
            autoReload = autoReload,
        )
    }

    @JvmStatic
    fun setInterstitialCallback(
        activity: Activity,
        alias: String,
        callback: InterstitialAdCallback?,
    ): Boolean {
        AndroidInterstitialAdSdk.setCallback(alias, callback)
        return true
    }

    @JvmStatic
    @JvmOverloads
    fun setInterstitialCallback(
        alias: String = DefaultInterstitialAdInstanceId,
        callback: InterstitialAdCallback? = null,
    ) {
        AndroidInterstitialAdSdk.setCallback(alias, callback)
    }

    @JvmStatic
    @JvmOverloads
    fun loadInterstitial(
        activity: Activity,
        alias: String = DefaultInterstitialAdInstanceId,
    ): Boolean {
        AndroidInterstitialAdSdk.load(activity, alias)
        return true
    }

    @JvmStatic
    fun loadInterstitial(
        activity: Activity,
        alias: String,
        bufferSize: Int,
    ): Boolean {
        AndroidInterstitialAdSdk.load(activity, alias, bufferSize)
        return true
    }

    @JvmStatic
    fun preloadAll(activity: Activity, alias: String): Boolean =
        if (adsGet<FullscreenNativeAdUnityCompat>().isFullscreen(alias)) {
            adsGet<FullscreenNativeAdUnityCompat>().load(activity, alias)
        } else {
            loadInterstitial(activity, alias)
        }

    @JvmStatic
    fun preloadOne(activity: Activity, alias: String, adUnitId: String): Boolean {
        if (adsGet<FullscreenNativeAdUnityCompat>().isFullscreen(alias)) {
            return adsGet<FullscreenNativeAdUnityCompat>().load(activity, alias, listOf(adUnitId))
        }
        AndroidInterstitialAdSdk.create(
            alias = alias,
            adUnitIdsCsv = adUnitId,
            preloadBufferSize = 1,
            autoReload = true,
        )
        return loadInterstitial(activity, alias, bufferSize = 1)
    }

    @JvmStatic
    @JvmOverloads
    fun showInterstitial(
        activity: Activity,
        alias: String = DefaultInterstitialAdInstanceId,
        optionsJson: String? = null,
    ): Boolean =
        AndroidInterstitialAdSdk.show(
            activity = activity,
            alias = alias,
            options = parseInterstitialShowOptionsJson(optionsJson),
        )

    @JvmStatic
    @JvmOverloads
    fun destroyInterstitial(alias: String = DefaultInterstitialAdInstanceId): Boolean {
        AndroidInterstitialAdSdk.destroy(alias)
        return true
    }

    @JvmStatic
    @JvmOverloads
    fun isInterstitialReady(alias: String = DefaultInterstitialAdInstanceId): Boolean =
        AndroidInterstitialAdSdk.isReady(alias)

    @JvmStatic
    fun destroy(alias: String): Boolean {
        destroyInterstitial(alias)
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.destroyFullscreen(alias)
        adsGet<FullscreenNativeAdUnityCompat>().destroy(alias)
        return true
    }

    @JvmStatic
    fun isReady(alias: String): Boolean =
        AndroidInterstitialAdSdk.isReady(alias) ||
            com.hdc.adsmultiplatform.api.fullscreen.registry.FullscreenNativeAdRegistry.isReady(alias)

    @JvmStatic
    fun enableMetaTestMode(testDeviceIds: List<String>): Boolean =
        AndroidMetaTestDeviceSdk.enableMetaTestMode(testDeviceIds).isSuccess

    @JvmStatic
    fun enableMetaTestMode(vararg testDeviceIds: String): Boolean =
        enableMetaTestMode(testDeviceIds.toList())

    @JvmStatic
    fun getCurrentMetaTestDeviceHash(context: Context): String =
        AndroidMetaTestDeviceSdk.getCurrentMetaTestDeviceHash(context)

    @JvmStatic
    @JvmOverloads
    fun show(activity: Activity, adUnitId: String = UnconfiguredAdUnitId) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.show(activity, adUnitId)
    }

    @JvmStatic
    @JvmOverloads
    fun showFullscreen(
        activity: Activity,
        instanceId: String = DefaultNativeAdInstanceId,
        layoutName: String = com.hdc.adsmultiplatform.presentation.fullscreen.layouts.registry.FullscreenLayoutCatalog.SingleDefault,
        durationSeconds: Double = 0.0,
        fallbackAdUnitId: String = UnconfiguredAdUnitId,
        autoClose: Boolean = false,
        pauseGameplay: Boolean = true,
        enableAdComeback: Boolean = true,
        showTCD: Boolean = true,
        delaySeconds: Double = 0.0,
    ) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.showFullscreen(
            activity = activity,
            instanceId = instanceId,
            layoutName = layoutName,
            durationSeconds = durationSeconds,
            fallbackAdUnitId = fallbackAdUnitId,
            autoClose = autoClose,
            pauseGameplay = pauseGameplay,
            enableAdComeback = enableAdComeback,
            showTCD = showTCD,
            delaySeconds = delaySeconds,
        )
    }

    @JvmStatic
    fun showFullscreenWithOptions(
        activity: Activity,
        instanceId: String,
        mode: String,
        layoutNamesCsv: String,
        durationSeconds: Double,
        durationsSecondsCsv: String,
        orientation: String,
        autoClose: Boolean,
        pauseGameplay: Boolean,
        enableAdComeback: Boolean,
        showTCD: Boolean,
        delaySeconds: Double,
        timeUpCSeconds: Int,
        fallbackAdUnitId: String,
        cta: Boolean,
        headline: Boolean,
        body: Boolean,
        description: Boolean,
        icon: Boolean,
        advertiser: Boolean,
        media: Boolean,
        mediaImage: Boolean,
        mediaVideo: Boolean,
    ) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.showFullscreenWithOptions(
            activity = activity,
            instanceId = instanceId,
            mode = mode,
            layoutNamesCsv = layoutNamesCsv,
            durationSeconds = durationSeconds,
            durationsSecondsCsv = durationsSecondsCsv,
            orientation = orientation,
            autoClose = autoClose,
            pauseGameplay = pauseGameplay,
            enableAdComeback = enableAdComeback,
            showTCD = showTCD,
            delaySeconds = delaySeconds,
            timeUpCSeconds = timeUpCSeconds,
            fallbackAdUnitId = fallbackAdUnitId,
            cta = cta,
            headline = headline,
            body = body,
            description = description,
            icon = icon,
            advertiser = advertiser,
            media = media,
            mediaImage = mediaImage,
            mediaVideo = mediaVideo,
        )
    }

    @JvmStatic
    fun showFullscreenWithOptionsAndAssetVisibility(
        activity: Activity,
        instanceId: String,
        mode: String,
        layoutNamesCsv: String,
        durationSeconds: Double,
        durationsSecondsCsv: String,
        orientation: String,
        autoClose: Boolean,
        pauseGameplay: Boolean,
        enableAdComeback: Boolean,
        showTCD: Boolean,
        delaySeconds: Double,
        timeUpCSeconds: Int,
        fallbackAdUnitId: String,
        cta: Boolean,
        headline: Boolean,
        body: Boolean,
        description: Boolean,
        icon: Boolean,
        advertiser: Boolean,
        media: Boolean,
        mediaImage: Boolean,
        mediaVideo: Boolean,
        assetCta: Boolean,
        assetHeadline: Boolean,
        assetBody: Boolean,
        assetDescription: Boolean,
        assetIcon: Boolean,
        assetAdvertiser: Boolean,
        assetMedia: Boolean,
        assetMediaImage: Boolean,
        assetMediaVideo: Boolean,
        assetPrice: Boolean,
        assetStore: Boolean,
        assetStarRating: Boolean,
    ) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.showFullscreenWithOptionsAndAssetVisibility(
            activity = activity,
            instanceId = instanceId,
            mode = mode,
            layoutNamesCsv = layoutNamesCsv,
            durationSeconds = durationSeconds,
            durationsSecondsCsv = durationsSecondsCsv,
            orientation = orientation,
            autoClose = autoClose,
            pauseGameplay = pauseGameplay,
            enableAdComeback = enableAdComeback,
            showTCD = showTCD,
            delaySeconds = delaySeconds,
            timeUpCSeconds = timeUpCSeconds,
            fallbackAdUnitId = fallbackAdUnitId,
            cta = cta,
            headline = headline,
            body = body,
            description = description,
            icon = icon,
            advertiser = advertiser,
            media = media,
            mediaImage = mediaImage,
            mediaVideo = mediaVideo,
            assetCta = assetCta,
            assetHeadline = assetHeadline,
            assetBody = assetBody,
            assetDescription = assetDescription,
            assetIcon = assetIcon,
            assetAdvertiser = assetAdvertiser,
            assetMedia = assetMedia,
            assetMediaImage = assetMediaImage,
            assetMediaVideo = assetMediaVideo,
            assetPrice = assetPrice,
            assetStore = assetStore,
            assetStarRating = assetStarRating,
        )
    }

    @JvmStatic
    fun hide(activity: Activity) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.hide(activity)
    }

    @JvmStatic
    fun hideFullscreen(activity: Activity, instanceId: String?) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.hideFullscreen(activity, instanceId)
    }

    @JvmStatic
    @JvmOverloads
    fun destroyFullscreen(instanceId: String = DefaultNativeAdInstanceId) {
        com.hdc.adsmultiplatform.unity.bridge.NativeAdUnityBridge.destroyFullscreen(instanceId)
    }
}
