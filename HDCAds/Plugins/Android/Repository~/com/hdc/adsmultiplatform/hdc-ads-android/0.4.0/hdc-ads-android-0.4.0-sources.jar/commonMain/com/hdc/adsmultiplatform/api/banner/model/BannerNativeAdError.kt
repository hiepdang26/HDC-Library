package com.hdc.adsmultiplatform.api.banner.model

data class BannerNativeAdError(
    val alias: String,
    val adUnitId: String,
    val code: Int = -1,
    val message: String,
)
