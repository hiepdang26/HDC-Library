package com.hdc.adsmultiplatform.di

import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.ViewFullscreenNativeAdOverlays
import com.hdc.adsmultiplatform.presentation.fullscreen.view.window.port.FullscreenNativeAdOverlays
import org.koin.core.module.Module
import org.koin.dsl.module

/** The Unity library's twin of [androidComposeModule]: fullscreen shows as overlays of plain Android views. */
internal val androidViewModule: Module = module {
    single<FullscreenNativeAdOverlays> { ViewFullscreenNativeAdOverlays(hosts = get(), interactions = get()) }
}
