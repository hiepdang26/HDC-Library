package com.hdc.adsmultiplatform.unity

import android.app.Activity
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.MobileAds
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.banner.AndroidBannerNativeAdUnityHost
import com.hdc.adsmultiplatform.banner.BannerNativeAdConfig
import com.hdc.adsmultiplatform.console.runtime.AndroidMetaTestDeviceSdk
import com.hdc.adsmultiplatform.console.runtime.metaTestDeviceIdsFor
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.internal.preload.android.AndroidNativeAdRepository
import com.hdc.adsmultiplatform.internal.unity.android.NativeAdUnityBridge
import com.hdc.adsmultiplatform.interstitial.AndroidInterstitialAdSdk
import com.hdc.adsmultiplatform.interstitial.InterstitialAdConfig
import com.hdc.adsmultiplatform.interstitial.InterstitialShowOptions
import com.hdc.adsmultiplatform.popup.AndroidPopupNativeAdUnityHost
import com.hdc.adsmultiplatform.popup.PopupNativeAdConfig
import com.hdc.adsmultiplatform.popup.PopupNativeAdShown
import java.lang.reflect.Field
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

private const val MainQueryTimeoutMillis = 2_000L

private val mainHandler: Handler by lazy { Handler(Looper.getMainLooper()) }

private val isMainThread: Boolean
    get() = Looper.myLooper() == Looper.getMainLooper()

internal actual fun hdcRunOnMain(block: () -> Unit) {
    if (isMainThread) {
        block()
    } else {
        mainHandler.post(block)
    }
}

internal actual fun hdcPostToMain(block: () -> Unit) {
    mainHandler.post(block)
}

internal actual fun hdcIsMainThread(): Boolean = isMainThread

internal actual fun <T> hdcQueryOnMain(fallback: T, block: () -> T): T {
    if (isMainThread) {
        return block()
    }
    val done = CountDownLatch(1)
    var result = fallback
    var failure: Throwable? = null
    mainHandler.post {
        try {
            result = block()
        } catch (error: Throwable) {
            failure = error
        } finally {
            done.countDown()
        }
    }
    if (!done.await(MainQueryTimeoutMillis, TimeUnit.MILLISECONDS)) {
        HdcLog.warn("main thread query timed out")
        return fallback
    }
    failure?.let { throw it }
    return result
}

internal actual fun hdcInitializeAds(onComplete: () -> Unit) {
    val context = HdcUnityActivity.require().applicationContext
    // Off the main thread, as Google recommends, so SDK start-up cannot stall the UI.
    thread(name = "hdc-ads-init") {
        MobileAds.initialize(context) { hdcRunOnMain(onComplete) }
    }
}

internal actual fun hdcInterstitialHost(): HdcInterstitialHost = AndroidHdcInterstitialHost

private object AndroidHdcInterstitialHost : HdcInterstitialHost {
    override fun load(id: String, config: InterstitialAdConfig) {
        AndroidInterstitialAdSdk.create(
            alias = id,
            adUnitIdsCsv = config.ids.joinToString(","),
            preloadBufferSize = config.preloadBufferSize,
            autoReload = config.autoReload,
        )
        AndroidInterstitialAdSdk.load(HdcUnityActivity.require(), id)
    }

    override fun show(id: String, options: InterstitialShowOptions): Boolean =
        AndroidInterstitialAdSdk.show(HdcUnityActivity.require(), id, options)

    override fun isReady(id: String): Boolean = AndroidInterstitialAdSdk.isReady(id)

    override fun destroy(id: String) {
        AndroidInterstitialAdSdk.destroy(id)
    }
}

internal actual fun hdcFullscreenHost(): HdcFullscreenHost = AndroidHdcFullscreenHost

private object AndroidHdcFullscreenHost : HdcFullscreenHost {
    override fun load(id: String, adUnitIds: List<String>, reloadAfterShow: Boolean) {
        NativeAdUnityBridge.loadFullscreen(
            activity = HdcUnityActivity.require(),
            instanceId = id,
            adUnitIdsCsv = adUnitIds.joinToString(","),
            enableReloadAfterShow = reloadAfterShow,
        )
    }

    override fun show(id: String, options: FullscreenNativeAdShowOptions): Boolean {
        // The bridge reports a missing ad as a failed load, which a show's caller would not hear as a failed show.
        if (AndroidNativeAdRepository.loadedAd(id) == null) {
            return false
        }
        NativeAdUnityBridge.showFullscreen(
            activity = HdcUnityActivity.require(),
            instanceId = id,
            options = options,
            fallbackAdUnitId = "",
        )
        return true
    }

    override fun hide(id: String) {
        NativeAdUnityBridge.hideFullscreen(HdcUnityActivity.require(), id)
    }

    override fun destroy(id: String) {
        HdcUnityActivity.current()?.let { NativeAdUnityBridge.hideFullscreen(it, id) }
        NativeAdUnityBridge.destroyFullscreen(id)
    }
}

internal actual fun hdcPopupHost(): HdcPopupHost = AndroidHdcPopupHost

private object AndroidHdcPopupHost : HdcPopupHost {
    override fun load(id: String, config: PopupNativeAdConfig, onState: (NativeAdState) -> Unit) {
        AndroidPopupNativeAdUnityHost.load(HdcUnityActivity.require(), id, config, onState)
    }

    override fun updatePlacement(id: String, xDp: Float, yDp: Float, widthDp: Float, heightDp: Float) {
        AndroidPopupNativeAdUnityHost.updatePlacement(id, xDp, yDp, widthDp, heightDp)
    }

    override fun show(id: String) {
        AndroidPopupNativeAdUnityHost.show(HdcUnityActivity.require(), id)
    }

    override fun close(id: String) {
        AndroidPopupNativeAdUnityHost.close(id)
    }

    override fun hide(id: String) {
        AndroidPopupNativeAdUnityHost.hide(id)
    }

    override fun stop(id: String) {
        AndroidPopupNativeAdUnityHost.stop(id)
    }

    override fun destroy(id: String) {
        AndroidPopupNativeAdUnityHost.destroy(id)
    }

    override fun isReady(id: String): Boolean = AndroidPopupNativeAdUnityHost.isReady(id)

    override fun isDisplayable(id: String): Boolean = AndroidPopupNativeAdUnityHost.isDisplayable(id)

    override fun state(id: String): String = AndroidPopupNativeAdUnityHost.stateFor(id)

    override fun shown(id: String): PopupNativeAdShown? = AndroidPopupNativeAdUnityHost.shownAd(id)
}

internal actual fun hdcBannerHost(): HdcBannerHost = AndroidHdcBannerHost

private object AndroidHdcBannerHost : HdcBannerHost {
    override fun load(id: String, config: BannerNativeAdConfig, onState: (NativeAdState) -> Unit) {
        AndroidBannerNativeAdUnityHost.load(HdcUnityActivity.require(), id, config, onState)
    }

    override fun show(id: String) {
        AndroidBannerNativeAdUnityHost.show(HdcUnityActivity.require(), id)
    }

    override fun expand(id: String, enableClick: Boolean): Boolean =
        AndroidBannerNativeAdUnityHost.expand(id, enableClick)

    override fun collapse(id: String) {
        AndroidBannerNativeAdUnityHost.collapse(id)
    }

    override fun hide(id: String) {
        AndroidBannerNativeAdUnityHost.hide(id)
    }

    override fun destroy(id: String) {
        AndroidBannerNativeAdUnityHost.destroy(id)
    }
}

internal actual fun hdcMetaTestHost(): HdcMetaTestHost = AndroidHdcMetaTestHost

private object AndroidHdcMetaTestHost : HdcMetaTestHost {
    override fun deviceHash(): String =
        AndroidMetaTestDeviceSdk.getCurrentMetaTestDeviceHash(HdcUnityActivity.require().applicationContext)

    override fun enable(extraDeviceHashes: List<String>, testAdType: Int): Boolean {
        val deviceIds = metaTestDeviceIdsFor(extraDeviceHashes.joinToString(","), deviceHash())
        val enabled = AndroidMetaTestDeviceSdk.enableMetaTestMode(deviceIds).isSuccess
        if (enabled) {
            AndroidMetaTestDeviceSdk.setTestAdType(testAdType)
        }
        return enabled
    }

    override fun disable() {
        AndroidMetaTestDeviceSdk.disableMetaTestMode()
    }

    override fun isEnabled(): Boolean =
        AndroidMetaTestDeviceSdk.isTestModeEnabled(HdcUnityActivity.require().applicationContext)
}

/** The Unity player's current activity, read through reflection so the library does not depend on Unity. */
internal object HdcUnityActivity {
    private val currentActivityField: Field? by lazy {
        runCatching { Class.forName("com.unity3d.player.UnityPlayer").getField("currentActivity") }.getOrNull()
    }

    fun current(): Activity? = runCatching { currentActivityField?.get(null) as? Activity }.getOrNull()

    fun require(): Activity = current() ?: error("Unity activity is not available")
}
