package com.hdc.adsmultiplatform.console.runtime

internal fun metaTestDeviceIdsFor(
    hashesText: String,
    currentDeviceHash: String,
): List<String> =
    (parseMetaTestDeviceHashes(hashesText) + currentDeviceHash)
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .distinct()

internal fun parseMetaTestDeviceHashes(hashesText: String): List<String> =
    hashesText
        .split(',', '\n', ';')
        .map { it.trim() }
        .filter { it.isNotBlank() }
        .distinct()
