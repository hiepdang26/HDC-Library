package com.hdc.adsmultiplatform.popup

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.defaultNativeAdUnitId
import com.hdc.adsmultiplatform.internal.core.NativeAdFormats
import com.hdc.adsmultiplatform.internal.preload.android.AndroidNativeAdRepository
import kotlin.math.roundToInt

private const val PopupLogTag = "AdsMultiplatform"

/**
 * Native popups placed over an activity's content, typically Unity's: the Android side of
 * IosPopupNativeAdSdk. One runtime per alias; only one popup shows at a time. Call on the main thread.
 */
internal object AndroidPopupNativeAdUnityHost {
    private val runtimes = mutableMapOf<String, AndroidPopupRuntime>()
    private val destroyedAliases = mutableSetOf<String>()

    fun load(
        activity: Activity,
        alias: String,
        config: PopupNativeAdConfig,
        onStateChanged: (NativeAdState) -> Unit,
    ) {
        val safeAlias = normalizedAlias(alias)
        destroyedAliases.remove(safeAlias)
        runtime(safeAlias).apply {
            this.activity = activity
            stateCallback = onStateChanged
            configure(config)
            controller.load()
        }
    }

    fun updatePlacement(alias: String, xDp: Float, yDp: Float, adWidthDp: Float, adHeightDp: Float) {
        runtimes[normalizedAlias(alias)]?.updatePlacement(xDp, yDp, adWidthDp, adHeightDp)
    }

    fun show(activity: Activity, alias: String) {
        val safeAlias = normalizedAlias(alias)
        val runtime = runtimes[safeAlias]
        if (runtime == null) {
            popupLog("show skipped alias=$safeAlias reason=missing_runtime")
            return
        }
        if (runtime.isShowing()) {
            popupLog("show skipped alias=$safeAlias reason=already_showing")
            return
        }
        val showingAlias = runtimes.entries.firstOrNull { (key, value) -> key != safeAlias && value.isShowing() }?.key
        runtime.show(activity, showingAlias)
    }

    fun close(alias: String) {
        runtimes[normalizedAlias(alias)]?.controller?.close()
    }

    fun hide(alias: String) {
        runtimes[normalizedAlias(alias)]?.controller?.hide()
    }

    fun stop(alias: String) {
        runtimes[normalizedAlias(alias)]?.controller?.stop()
    }

    fun destroy(alias: String) {
        val safeAlias = normalizedAlias(alias)
        destroyedAliases += safeAlias
        runtimes.remove(safeAlias)?.destroy()
    }

    fun isReady(alias: String): Boolean = runtimes[normalizedAlias(alias)]?.isReady() == true

    fun isDisplayable(alias: String): Boolean = runtimes[normalizedAlias(alias)]?.isDisplayable() == true

    fun stateFor(alias: String): String {
        val safeAlias = normalizedAlias(alias)
        return runtimes[safeAlias]?.stateName()
            ?: if (safeAlias in destroyedAliases) {
                PopupNativeAdDisplayState.Destroyed.name
            } else {
                PopupNativeAdDisplayState.NotLoaded.name
            }
    }

    private fun runtime(alias: String): AndroidPopupRuntime =
        runtimes.getOrPut(alias) { AndroidPopupRuntime(alias) }

    private fun normalizedAlias(alias: String): String =
        alias.ifBlank { DefaultPopupNativeAdInstanceId }
}

private class AndroidPopupRuntime(private val alias: String) {
    private val handler = Handler(Looper.getMainLooper())
    var activity: Activity? = null
    var stateCallback: (NativeAdState) -> Unit = {}
    private var config = PopupNativeAdConfig(ids = listOf(defaultNativeAdUnitId()))
    private var hostView: AndroidPopupNativeViewAdHost? = null

    private val loader = object : PopupNativeAdRuntimeLoader {
        override fun load(instanceId: String, adUnitId: String, callback: (NativeAdLoadResult) -> Unit) {
            val context = activity ?: return callback(
                NativeAdLoadResult(
                    state = NativeAdState.Failed,
                    adUnitId = adUnitId,
                    code = NativeAdLoadResult.NoErrorCode,
                    message = "Missing activity",
                ),
            )
            AndroidNativeAdRepository.loadWithResult(
                format = NativeAdFormats.Popup,
                instanceId = instanceId,
                context = context,
                adUnitIds = listOf(adUnitId),
                callback = callback,
            )
        }

        override fun destroy(instanceId: String) {
            AndroidNativeAdRepository.destroy(NativeAdFormats.Popup, instanceId)
        }
    }

    private val scheduler = PopupNativeAdRuntimeScheduler { delayMillis, block ->
        val runnable = Runnable(block)
        handler.postDelayed(runnable, delayMillis)
        PopupNativeAdRuntimeCancellation { handler.removeCallbacks(runnable) }
    }

    val controller = PopupNativeAdRuntimeController(
        alias = alias,
        loader = loader,
        scheduler = scheduler,
        onSnapshotChanged = { next ->
            notifyState(next.state)
            if (next.isVisible) {
                try {
                    if (ensurePresented()) {
                        render(next)
                    }
                } catch (t: Throwable) {
                    fail("render failed alias=$alias", t)
                }
            } else if (next.state == NativeAdState.onClosed) {
                dismiss()
            }
        },
    )

    fun configure(nextConfig: PopupNativeAdConfig) {
        config = nextConfig.normalizedForPopupRuntime()
        controller.configure(config)
    }

    fun show(activity: Activity, showingAlias: String?) {
        if (!activity.hasWindowFocus()) {
            // Another screen is on top (an interstitial, a store page): showing now would put the popup
            // behind it. Skip without failing, so the loaded popup stays displayable for the next show.
            popupLog("show skipped alias=$alias reason=activity_not_focused")
            notifyState(NativeAdState.onClosed)
            return
        }
        val blockReason = showBlockReason(activity, showingAlias)
        if (blockReason != null) {
            fail("show skipped alias=$alias reason=$blockReason", null)
            return
        }
        this.activity = activity
        if (!ensurePresented()) {
            return
        }
        controller.show()
    }

    fun isReady(): Boolean = controller.isReady()

    fun isDisplayable(): Boolean =
        controller.isDisplayable() && hasLoadedDisplayableAd() && config.hasValidDimensions()

    fun isShowing(): Boolean = controller.isShowing()

    fun stateName(): String {
        val state = controller.stateName()
        return if (state == PopupNativeAdDisplayState.Displayable.name && !isDisplayable()) {
            PopupNativeAdDisplayState.Loaded.name
        } else {
            state
        }
    }

    fun updatePlacement(xDp: Float, yDp: Float, adWidthDp: Float, adHeightDp: Float) {
        if (!listOf(xDp, yDp, adWidthDp, adHeightDp).all { it.isFinite() }) {
            fail("placement update failed alias=$alias reason=non_finite", null)
            return
        }
        config = config.copy(
            xDp = xDp,
            yDp = yDp,
            adWidthDp = adWidthDp.coerceAtLeast(PopupNativeAdLayoutCatalog.MinWidthDp),
            adHeightDp = adHeightDp.coerceAtLeast(PopupNativeAdLayoutCatalog.minHeightDp(config.layoutName)),
        )
        applyPlacement()
    }

    fun destroy() {
        controller.destroy()
        dismiss()
    }

    private fun ensurePresented(): Boolean {
        if (hostView != null) {
            return true
        }
        val activity = activity ?: return false
        val content = activity.findViewById<ViewGroup>(android.R.id.content)
        if (content == null) {
            fail("attach skipped alias=$alias reason=missing_content_view", null)
            return false
        }
        val frame = placementFrame(content)
        if (frame == null) {
            fail("attach skipped alias=$alias reason=invalid_content_bounds", null)
            return false
        }
        val host = AndroidPopupNativeViewAdHost(activity)
        content.addView(host, frame.toLayoutParams(content.resources.displayMetrics.density))
        hostView = host
        return true
    }

    private fun render(current: PopupNativeAdRuntimeSnapshot) {
        val host = hostView ?: return
        val instanceId = current.activeInstanceId ?: return
        applyPlacement()
        host.bringToFront()
        host.render(
            instanceId = instanceId,
            fallbackAdUnitId = current.activeAdUnitId.orEmpty(),
            layoutName = current.layoutName,
            closeSecondsRemaining = current.closeSecondsRemaining,
            showClose = current.canClose,
            enableCtrOverlay = config.enableCtrOverlay,
            onStateChanged = ::notifyState,
            onCloseClick = {
                runCatching { controller.close() }.onFailure { fail("close click failed alias=$alias", it) }
            },
        )
    }

    private fun dismiss() {
        val host = hostView ?: return
        hostView = null
        host.release()
        (host.parent as? ViewGroup)?.removeView(host)
    }

    private fun fail(message: String, throwable: Throwable?) {
        popupLog(if (throwable == null) message else "$message throwable=${throwable.message.orEmpty()}")
        controller.markShowFailed(message)
        dismiss()
    }

    private fun showBlockReason(activity: Activity, showingAlias: String?): String? {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            return "not_main_thread"
        }
        if (activity.isFinishing || activity.isDestroyed) {
            return "activity_finishing"
        }
        if (!showingAlias.isNullOrBlank()) {
            return "another_popup_showing:$showingAlias"
        }
        if (!controller.isDisplayable()) {
            return "not_displayable_state=${controller.stateName()}"
        }
        if (!hasLoadedDisplayableAd()) {
            return "missing_native_ad"
        }
        if (!config.hasValidDimensions()) {
            return "invalid_layout_config"
        }
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return "missing_content_view"
        if (content.width <= 0 || content.height <= 0) {
            return "invalid_content_bounds"
        }
        if (placementFrame(content) == null) {
            return "invalid_popup_placement"
        }
        return null
    }

    private fun applyPlacement() {
        val host = hostView ?: return
        val content = host.parent as? ViewGroup ?: return
        val frame = placementFrame(content) ?: return
        host.layoutParams = frame.toLayoutParams(content.resources.displayMetrics.density)
    }

    private fun placementFrame(content: View): PopupPlacementFrame? {
        val density = content.resources.displayMetrics.density
        return config.placementFrame(
            viewportWidth = content.width / density.toDouble(),
            viewportHeight = content.height / density.toDouble(),
        )
    }

    private fun hasLoadedDisplayableAd(): Boolean {
        val instanceId = controller.displayableInstanceId() ?: return false
        return AndroidNativeAdRepository.loadedAd(NativeAdFormats.Popup, instanceId) != null
    }

    private fun notifyState(state: NativeAdState) {
        try {
            stateCallback(state)
        } catch (t: Throwable) {
            popupLog("state callback failed alias=$alias state=${state.name} message=${t.message.orEmpty()}")
        }
    }
}

private fun PopupNativeAdConfig.hasValidDimensions(): Boolean =
    listOf(xDp, yDp, adWidthDp, adHeightDp).all { it.isFinite() } && adWidthDp > 0f && adHeightDp > 0f

private fun PopupPlacementFrame.toLayoutParams(density: Float): FrameLayout.LayoutParams =
    FrameLayout.LayoutParams((width * density).roundToInt(), (height * density).roundToInt()).apply {
        gravity = Gravity.TOP or Gravity.START
        leftMargin = (x * density).roundToInt()
        topMargin = (y * density).roundToInt()
    }

private fun popupLog(message: String) {
    Log.d(PopupLogTag, "Android popup unity host $message")
}
