package com.hdc.adsmultiplatform.unity

import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.interstitial.InterstitialAdCallback
import com.hdc.adsmultiplatform.interstitial.InterstitialAdConfig
import com.hdc.adsmultiplatform.interstitial.InterstitialAdInfo
import com.hdc.adsmultiplatform.interstitial.InterstitialAdRegistry
import com.hdc.adsmultiplatform.interstitial.InterstitialShowOptions

/**
 * `interstitial.*` commands.
 *
 * - `load` `{id, adUnitIds:[…], bufferSize?, autoReload?}`: ad units are tried in order.
 * - `show` `{id, immersiveMode?}` returns whether a ready ad started to show.
 * - `isReady` `{id}`, `destroy` `{id}`.
 */
internal object HdcInterstitialCommands {
    private val host: HdcInterstitialHost by lazy { hdcInterstitialHost() }

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val config = InterstitialAdConfig(
            ids = adUnitIds,
            autoReload = args.boolean("autoReload", true),
            preloadBufferSize = args.int("bufferSize", 1).coerceAtLeast(1),
        )
        hdcRunOnMainCatching(
            onError = { error ->
                HdcEvents.emit(
                    id = id,
                    format = HdcFormat.Interstitial,
                    type = HdcEventType.LoadFailed,
                    fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
                )
            },
        ) {
            InterstitialAdRegistry.setCallback(id, HdcInterstitialEvents(id))
            host.load(id, config)
        }
        return true
    }

    fun show(args: HdcArgs): Boolean {
        val id = args.id()
        val options = InterstitialShowOptions(immersiveMode = args.boolean("immersiveMode", true))
        return hdcQueryOnMain(fallback = false) { host.show(id, options) }
    }

    fun isReady(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { host.isReady(id) }
    }

    fun destroy(args: HdcArgs): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { host.destroy(id) }
        return true
    }
}

/**
 * Forwards one interstitial instance's lifecycle callbacks to Unity. Impression, click and paid events come
 * from the shared tracking stream instead (HdcTracking), like every other format's.
 */
internal class HdcInterstitialEvents(private val id: String) : InterstitialAdCallback {
    override fun onInterstitialLoaded(ad: InterstitialAdInfo) = emit(HdcEventType.Loaded, ad.fields())

    override fun onInterstitialDisplayed(ad: InterstitialAdInfo) = emit(HdcEventType.Shown, ad.fields())

    override fun onInterstitialClosed(ad: InterstitialAdInfo) = emit(HdcEventType.Closed, ad.fields())

    override fun onInterstitialFailedToLoad(adUnit: String, errorCode: Int, error: String) =
        emit(HdcEventType.LoadFailed, mapOf("adUnitId" to adUnit) + HdcEvents.error(errorCode, error))

    override fun onInterstitialFailedToShow(adUnit: String, errorCode: Int, error: String) =
        emit(HdcEventType.ShowFailed, mapOf("adUnitId" to adUnit) + HdcEvents.error(errorCode, error))

    private fun emit(type: String, fields: Map<String, Any?>) {
        HdcEvents.emit(id = id, format = HdcFormat.Interstitial, type = type, fields = fields)
    }

    private fun InterstitialAdInfo.fields(): Map<String, Any?> =
        mapOf(
            "adUnitId" to adUnitId,
            "adapter" to mediationAdapter,
            "adSource" to adSource.orEmpty(),
            "responseId" to responseId,
        )
}
