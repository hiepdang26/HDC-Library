package com.hdc.adsmultiplatform.console.runtime

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.provider.Settings
import com.facebook.ads.AdSettings
import java.security.MessageDigest
import java.util.Locale

internal object AndroidMetaTestDeviceSdk {
    /** Whether the app ships Meta Audience Network: the Unity library leaves it to the game's mediation setup. */
    val isAvailable: Boolean by lazy {
        runCatching { Class.forName("com.facebook.ads.AdSettings") }.isSuccess
    }

    fun enableMetaTestMode(testDeviceIds: List<String>): Result<Unit> {
        val cleanDeviceIds = testDeviceIds
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()

        if (cleanDeviceIds.isEmpty()) {
            return Result.failure(IllegalArgumentException("Meta test device hash is blank"))
        }
        if (!isAvailable) {
            return Result.failure(IllegalStateException("Meta Audience Network is not in the app"))
        }

        return runCatching {
            AdSettings.setTestMode(true)
            cleanDeviceIds.forEach { deviceHash ->
                AdSettings.addTestDevice(deviceHash)
            }
        }
    }

    fun disableMetaTestMode() {
        if (!isAvailable) {
            return
        }
        runCatching {
            AdSettings.setTestMode(false)
            AdSettings.clearTestDevices()
            AdSettings.setTestAdType(AdSettings.TestAdType.DEFAULT)
        }
    }

    /** Picks Meta's test creative by its index in AdSettings.TestAdType; no index or an unknown one picks the default. */
    fun setTestAdType(index: Int? = null) {
        if (!isAvailable) {
            return
        }
        runCatching {
            val type = index?.let { AdSettings.TestAdType.entries.getOrNull(it) } ?: AdSettings.TestAdType.DEFAULT
            AdSettings.setTestAdType(type)
        }
    }

    fun isTestModeEnabled(context: Context): Boolean =
        isAvailable && runCatching { AdSettings.isTestMode(context) }.getOrDefault(false)

    fun getCurrentMetaTestDeviceHash(context: Context): String =
        getCurrentTestDeviceId(context).orEmpty()

    fun copyCurrentMetaTestDeviceHash(
        context: Context,
        currentHash: String = getCurrentMetaTestDeviceHash(context),
    ): Boolean {
        if (currentHash.isBlank()) {
            return false
        }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            ?: return false
        clipboard.setPrimaryClip(ClipData.newPlainText("Meta Test Device Hash", currentHash))
        return true
    }

    private fun getCurrentTestDeviceId(context: Context): String? {
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
            ?: return null
        return runCatching {
            val digest = MessageDigest.getInstance("MD5").digest(androidId.toByteArray())
            digest.joinToString(separator = "") { byte -> "%02x".format(byte) }
                .uppercase(Locale.US)
        }.getOrNull()
    }
}
