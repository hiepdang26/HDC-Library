package com.hdc.adsmultiplatform.fullscreen

import android.app.Activity
import android.app.Application
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Choreographer
import android.view.WindowInsets
import android.widget.FrameLayout
import com.hdc.adsmultiplatform.NativeAdLayoutNames
import com.hdc.adsmultiplatform.NativeAdShowOptions
import com.hdc.adsmultiplatform.durationMillis

/**
 * A full-screen native ad drawn with the XML layouts, without Compose: the View counterpart of
 * FullscreenNativeAdOverlay. It runs the control timeline frame by frame, moves through sequence layouts,
 * closes by itself when asked to, and closes when the player comes back from the ad if comeback is off.
 */
internal class AndroidFullscreenNativeOverlayView(
    private val activity: Activity,
    private val options: NativeAdShowOptions,
    private val adUnitId: String,
    private val onClose: () -> Unit,
) : FrameLayout(activity) {
    private val content = FrameLayout(activity)
    private val host = AndroidFullscreenNativeXmlAdHost(activity)
    private val handler = Handler(Looper.getMainLooper())
    private val layoutNames = normalizeOverlayLayoutNames(
        layoutName = options.layoutName,
        layoutNames = options.layoutNames,
        keepDuplicates = options.mode.keepsDuplicateLayouts,
    )
    private val durations = options.durationsSeconds.filter { it > 0.0 }
    private val mode = options.mode.withLayoutInferredOverlay(layoutNames)
    private var layoutIndex = 0
    private var timelineStart = 0L
    private var ticking = false
    private var closed = false
    private var previousOrientation: Int? = null
    private var lifecycleCallbacks: Application.ActivityLifecycleCallbacks? = null
    private val frameCallback = Choreographer.FrameCallback { tick() }

    init {
        setBackgroundColor(Color.TRANSPARENT)
        content.addView(host, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        addView(content, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    private val layoutName: String
        get() = layoutNames.getOrNull(layoutIndex) ?: NativeAdLayoutNames.default()

    private val activeDurationSeconds: Double
        get() = if (mode == FullscreenNativeAdMode.SEQUENCE && durations.isNotEmpty()) {
            durations.getOrElse(layoutIndex) { durations.last() }
        } else {
            options.durationSeconds
        }

    private val timelineMillis: Long
        get() = fullscreenControlTimelineMillis(
            mode = mode,
            countdownDurationSeconds = activeDurationSeconds,
            hiddenDelaySeconds = options.delaySeconds,
            timeUpCSeconds = options.timeUpCSeconds,
        )

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        applyOrientation()
        watchComeback()
        startLayout(0)
        scheduleSequence()
        scheduleAutoClose()
        requestApplyInsets()
    }

    override fun onDetachedFromWindow() {
        stopTicking()
        handler.removeCallbacksAndMessages(null)
        lifecycleCallbacks?.let(activity.application::unregisterActivityLifecycleCallbacks)
        lifecycleCallbacks = null
        restoreOrientation()
        FullscreenNativeAdInteractionRegistry.clear(options.instanceId)
        host.release()
        super.onDetachedFromWindow()
    }

    // Keeps the ad clear of the notch and of any system bar still on screen.
    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        var left = 0
        var top = 0
        var right = 0
        var bottom = 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val safe = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
            left = safe.left
            top = safe.top
            right = safe.right
            bottom = safe.bottom
        } else {
            @Suppress("DEPRECATION")
            run {
                left = insets.systemWindowInsetLeft
                top = insets.systemWindowInsetTop
                right = insets.systemWindowInsetRight
                bottom = insets.systemWindowInsetBottom
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                insets.displayCutout?.let { cutout ->
                    left = maxOf(left, cutout.safeInsetLeft)
                    top = maxOf(top, cutout.safeInsetTop)
                    right = maxOf(right, cutout.safeInsetRight)
                    bottom = maxOf(bottom, cutout.safeInsetBottom)
                }
            }
        }
        content.setPadding(left, top, right, bottom)
        return insets
    }

    private fun startLayout(index: Int) {
        layoutIndex = index
        timelineStart = SystemClock.uptimeMillis()
        render(0L)
        if (timelineMillis > 0L) {
            startTicking()
        }
    }

    private fun tick() {
        ticking = false
        if (closed) {
            return
        }
        val elapsed = (SystemClock.uptimeMillis() - timelineStart).coerceIn(0L, timelineMillis)
        render(elapsed)
        if (elapsed < timelineMillis) {
            startTicking()
        }
    }

    private fun render(elapsedMillis: Long) {
        host.render(
            instanceId = options.instanceId,
            fallbackAdUnitId = adUnitId,
            layoutName = layoutName,
            controlState = fullscreenNativeAdControlState(
                elapsedMillis = elapsedMillis,
                mode = mode,
                countdownDurationSeconds = activeDurationSeconds,
                hiddenDelaySeconds = options.delaySeconds,
                timeUpCSeconds = options.timeUpCSeconds,
                showTCD = options.showTCD,
                layoutName = layoutName,
            ),
            showControls = true,
            clickAssets = options.clickAssets,
            assetVisibility = options.assetVisibility,
            onStateChanged = {},
            onClose = ::close,
        )
    }

    private fun startTicking() {
        if (!ticking) {
            ticking = true
            Choreographer.getInstance().postFrameCallback(frameCallback)
        }
    }

    private fun stopTicking() {
        if (ticking) {
            ticking = false
            Choreographer.getInstance().removeFrameCallback(frameCallback)
        }
    }

    private fun scheduleSequence() {
        if (mode != FullscreenNativeAdMode.SEQUENCE || layoutNames.size < 2 || durations.isEmpty()) {
            return
        }
        var at = 0L
        for (index in 0 until minOf(layoutNames.lastIndex, durations.size)) {
            at += durationMillis(durations[index])
            handler.postDelayed({ if (!closed) startLayout(index + 1) }, at)
        }
    }

    private fun scheduleAutoClose() {
        if (!options.autoClose && mode != FullscreenNativeAdMode.LOOP) {
            return
        }
        val delay = if (mode == FullscreenNativeAdMode.SEQUENCE && durations.isNotEmpty()) {
            durationMillis(sequenceTotalDurationSeconds(layoutNames.size.coerceAtLeast(1), durations)) +
                durationMillis(options.delaySeconds)
        } else {
            timelineMillis
        }
        if (delay > 0L) {
            handler.postDelayed(::close, delay)
        }
    }

    // Without comeback, a player returning from the ad's destination finds the ad closed.
    private fun watchComeback() {
        if (options.enableAdComeback) {
            return
        }
        val callbacks = object : Application.ActivityLifecycleCallbacks {
            override fun onActivityResumed(resumed: Activity) {
                if (resumed === activity && FullscreenNativeAdInteractionRegistry.consumeInteraction(options.instanceId)) {
                    close()
                }
            }

            override fun onActivityCreated(created: Activity, savedInstanceState: Bundle?) = Unit
            override fun onActivityStarted(started: Activity) = Unit
            override fun onActivityPaused(paused: Activity) = Unit
            override fun onActivityStopped(stopped: Activity) = Unit
            override fun onActivitySaveInstanceState(saved: Activity, outState: Bundle) = Unit
            override fun onActivityDestroyed(destroyed: Activity) = Unit
        }
        lifecycleCallbacks = callbacks
        activity.application.registerActivityLifecycleCallbacks(callbacks)
    }

    // "auto" keeps the game's orientation.
    private fun applyOrientation() {
        val requested = requestedOrientation(options.orientation) ?: return
        previousOrientation = activity.requestedOrientation
        activity.requestedOrientation = requested
    }

    private fun restoreOrientation() {
        val previous = previousOrientation ?: return
        previousOrientation = null
        // Only undo our own change: the game may have set another orientation meanwhile.
        if (activity.requestedOrientation == requestedOrientation(options.orientation)) {
            activity.requestedOrientation = previous
        }
    }

    private fun requestedOrientation(orientation: String): Int? =
        when (orientation.trim().lowercase()) {
            "portrait" -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            else -> null
        }

    private fun close() {
        if (closed) {
            return
        }
        closed = true
        onClose()
    }
}
