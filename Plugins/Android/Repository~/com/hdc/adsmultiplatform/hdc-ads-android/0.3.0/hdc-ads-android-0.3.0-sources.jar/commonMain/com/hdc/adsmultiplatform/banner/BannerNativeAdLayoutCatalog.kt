package com.hdc.adsmultiplatform.banner

object BannerNativeAdLayoutCatalog {
    const val Default = "bn_single_transparent_01"

    val All: List<String> = (1..20).map { index ->
        "bn_single_transparent_${index.toString().padStart(2, '0')}"
    }

    fun normalize(layoutName: String?): String {
        val rawKey = layoutName?.trim()?.lowercase().orEmpty()
        val key = rawKey
            .removeSuffix("_collapse")
            .removeSuffix("_expand")
        if (key == "bn_single_compose_01") {
            return Default
        }
        return if (key in All) key else Default
    }

    fun collapseCountdownStyle(layoutName: String?): BannerCollapseCountdownStyle =
        when (All.indexOf(normalize(layoutName)) + 1) {
            in 11..15 -> BannerCollapseCountdownStyle.Ring
            in 16..17 -> BannerCollapseCountdownStyle.Horizontal
            in 18..20 -> BannerCollapseCountdownStyle.Segments
            else -> BannerCollapseCountdownStyle.None
        }

    fun hasCollapseCountdown(layoutName: String?): Boolean =
        collapseCountdownStyle(layoutName) != BannerCollapseCountdownStyle.None
}

enum class BannerCollapseCountdownStyle {
    None,
    Ring,
    Horizontal,
    Segments,
}

object BannerNativeAdSizing {
    const val MinExpandedHeightPortraitDp = 260f
    const val MinExpandedHeightLandscapeDp = 260f
    const val HeightRatioPortrait = 0.08f
    const val HeightRatioLandscape = 0.15f
    const val ExpandedHeightRatioPortrait = 0.45f
    const val ExpandedHeightRatioLandscape = 0.55f

    /**
     * Height of the banner overlay in a viewport [viewportHeight] tall (dp, or points on iOS): a share of
     * the viewport, larger and with a minimum while expanded.
     */
    fun overlayHeight(isExpanded: Boolean, viewportHeight: Double, isLandscape: Boolean): Double {
        if (!isExpanded) {
            val ratio = if (isLandscape) HeightRatioLandscape else HeightRatioPortrait
            return viewportHeight * ratio
        }
        val ratio = if (isLandscape) ExpandedHeightRatioLandscape else ExpandedHeightRatioPortrait
        val minimum = (if (isLandscape) MinExpandedHeightLandscapeDp else MinExpandedHeightPortraitDp).toDouble()
        return (viewportHeight * ratio).coerceIn(minimum.coerceAtMost(viewportHeight), viewportHeight)
    }
}
