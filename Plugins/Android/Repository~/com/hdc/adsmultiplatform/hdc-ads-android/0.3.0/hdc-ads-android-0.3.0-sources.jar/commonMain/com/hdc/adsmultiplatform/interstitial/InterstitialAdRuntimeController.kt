package com.hdc.adsmultiplatform.interstitial

import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState

internal data class InterstitialAdRuntimeSnapshot(
    val state: NativeAdState = NativeAdState.Idle,
    val activeAdUnitId: String? = null,
    val responseId: String = "",
    val mediationAdapter: String = "",
    val adSource: String? = null,
    val loadedAdUnitIds: Set<String> = emptySet(),
    val loadingAdUnitIds: Set<String> = emptySet(),
    val preloadBufferSize: Int = 1,
    val isShowing: Boolean = false,
)

internal class InterstitialAdRuntimeController(
    private val alias: String,
    private val loader: InterstitialAdLoader,
    private val callback: InterstitialAdCallback = object : InterstitialAdCallback {},
    private val onSnapshotChanged: (InterstitialAdRuntimeSnapshot) -> Unit = {},
) {
    private var config = InterstitialAdConfig(ids = listOf(defaultInterstitialAdUnitId()))
    private var snapshot = InterstitialAdRuntimeSnapshot()
    private val runtimeCallback = object : InterstitialAdCallback {
        override fun onInterstitialLoaded(ad: InterstitialAdInfo) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Loaded,
                    activeAdUnitId = ad.adUnitId,
                    responseId = ad.responseId,
                    mediationAdapter = ad.mediationAdapter,
                    adSource = ad.adSource,
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - ad.adUnitId,
                    loadedAdUnitIds = snapshot.loadedAdUnitIds + ad.adUnitId,
                    isShowing = false,
                ),
            )
            callback.onInterstitialLoaded(ad)
        }

        override fun onInterstitialDisplayed(ad: InterstitialAdInfo) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Shown,
                    activeAdUnitId = ad.adUnitId,
                    responseId = ad.responseId,
                    mediationAdapter = ad.mediationAdapter,
                    adSource = ad.adSource,
                    loadedAdUnitIds = snapshot.loadedAdUnitIds - ad.adUnitId,
                    isShowing = true,
                ),
            )
            callback.onInterstitialDisplayed(ad)
        }

        override fun onInterstitialOpened(ad: InterstitialAdInfo) {
            callback.onInterstitialOpened(ad)
        }

        override fun onInterstitialClosed(ad: InterstitialAdInfo) {
            publish(
                snapshot.copy(
                    state = NativeAdState.onClosed,
                    activeAdUnitId = ad.adUnitId.ifBlank { snapshot.activeAdUnitId },
                    responseId = ad.responseId.ifBlank { snapshot.responseId },
                    mediationAdapter = ad.mediationAdapter.ifBlank { snapshot.mediationAdapter },
                    adSource = ad.adSource ?: snapshot.adSource,
                    isShowing = false,
                ),
            )
            callback.onInterstitialClosed(ad)
        }

        override fun onInterstitialClicked(ad: InterstitialAdInfo) {
            callback.onInterstitialClicked(ad)
        }

        override fun onInterstitialFailedToLoad(adUnit: String, errorCode: Int, error: String) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Failed,
                    activeAdUnitId = adUnit.ifBlank { snapshot.activeAdUnitId },
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - adUnit,
                    isShowing = false,
                ),
            )
            callback.onInterstitialFailedToLoad(adUnit, errorCode, error)
        }

        override fun onInterstitialPaidImpression(ad: InterstitialAdInfo, paidInfo: InterstitialAdPaidInfo) {
            callback.onInterstitialPaidImpression(ad, paidInfo)
        }

        override fun onInterstitialDisplayable() {
            callback.onInterstitialDisplayable()
        }
    }

    init {
        loader.setCallback(alias, runtimeCallback)
    }

    fun configure(nextConfig: InterstitialAdConfig) {
        val normalized = nextConfig.normalized()
        if (normalized == config) {
            loader.setCallback(alias, runtimeCallback)
            return
        }
        config = normalized
        loader.configure(alias, config)
        loader.setCallback(alias, runtimeCallback)
        publish(
            InterstitialAdRuntimeSnapshot(
                preloadBufferSize = config.preloadBufferSize,
            ),
        )
    }

    fun load(bufferSize: Int = config.preloadBufferSize) {
        val requestConfig = config.copy(preloadBufferSize = bufferSize.coerceAtLeast(1)).normalized()
        if (requestConfig != config) {
            config = requestConfig
            loader.configure(alias, config)
        }
        loader.setCallback(alias, runtimeCallback)
        publish(
            snapshot.copy(
                state = NativeAdState.Loading,
                loadingAdUnitIds = config.ids.toSet(),
                preloadBufferSize = config.preloadBufferSize,
            ),
        )
        loader.load(alias, config.preloadBufferSize) { result ->
            handleLoadResult(result)
        }
    }

    fun show(options: InterstitialShowOptions = InterstitialShowOptions()): Boolean {
        loader.setCallback(alias, runtimeCallback)
        return loader.show(alias, options)
    }

    fun hide() {
        loader.hide(alias)
    }

    fun destroy() {
        loader.setCallback(alias, null)
        loader.destroy(alias)
        config = InterstitialAdConfig(ids = listOf(defaultInterstitialAdUnitId()))
        publish(InterstitialAdRuntimeSnapshot())
    }

    private fun handleLoadResult(result: NativeAdLoadResult) {
        when (result.state) {
            NativeAdState.Loading -> publish(
                snapshot.copy(
                    state = NativeAdState.Loading,
                    loadingAdUnitIds = snapshot.loadingAdUnitIds + result.adUnitId,
                    preloadBufferSize = config.preloadBufferSize,
                ),
            )

            NativeAdState.Loaded -> publish(
                snapshot.copy(
                    state = NativeAdState.Loaded,
                    activeAdUnitId = result.adUnitId.ifBlank { snapshot.activeAdUnitId },
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - result.adUnitId,
                    loadedAdUnitIds = if (result.adUnitId.isBlank()) {
                        snapshot.loadedAdUnitIds
                    } else {
                        snapshot.loadedAdUnitIds + result.adUnitId
                    },
                    preloadBufferSize = config.preloadBufferSize,
                ),
            )

            NativeAdState.Failed -> publish(
                snapshot.copy(
                    state = NativeAdState.Failed,
                    activeAdUnitId = result.adUnitId.ifBlank { snapshot.activeAdUnitId },
                    loadingAdUnitIds = snapshot.loadingAdUnitIds - result.adUnitId,
                    preloadBufferSize = config.preloadBufferSize,
                    isShowing = false,
                ),
            )

            NativeAdState.Shown -> publish(snapshot.copy(state = NativeAdState.Shown, isShowing = true))
            NativeAdState.onClosed -> publish(snapshot.copy(state = NativeAdState.onClosed, isShowing = false))
            NativeAdState.Idle -> publish(snapshot.copy(state = NativeAdState.Idle, isShowing = false))
        }
    }

    private fun publish(nextSnapshot: InterstitialAdRuntimeSnapshot) {
        snapshot = nextSnapshot
        onSnapshotChanged(nextSnapshot)
    }
}
