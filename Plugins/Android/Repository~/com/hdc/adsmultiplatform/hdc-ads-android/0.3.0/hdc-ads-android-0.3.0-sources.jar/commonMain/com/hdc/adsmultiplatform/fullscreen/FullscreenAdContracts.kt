package com.hdc.adsmultiplatform.fullscreen

object FullscreenLayoutCatalog {
    const val SingleDefault = "fs_single_universal_01"
    const val MultipleDefault = "fs_multi_01"
    const val SequenceDefault = "fs_sequence_01"
    const val SingleCtr = "fs_single_ctr_01"
    const val SingleCtrTransparent = "fs_single_ctr_transparent_01"
    const val ProgressDefault = "fs_single_prgs_01"
    const val ProgressOnly01 = "fs_single_prgso_01"
    const val ProgressOnly02 = "fs_single_prgso_02"
    const val ProgressOnly03 = "fs_single_prgso_03"
    const val ProgressOnly04 = "fs_single_prgso_04"
    const val LoopDefault = "fs_single_loop_01"
    const val ProgressClsDefault = "fs_single_prgs_cls_01"
    const val Nav01 = "fs_single_nav_01"
    const val Nav02 = "fs_single_nav_02"
    const val Nav03 = "fs_single_nav_03"

    val SingleLayouts: List<String> = (1..12).map { index ->
        "fs_single_universal_${index.toString().padStart(2, '0')}"
    }
    val AarSingleUniversalLayouts: List<String> = (1..12).map { index ->
        "fs_single_universal_${index.toString().padStart(2, '0')}"
    }
    val AarSingleTransparentLayouts: List<String> = (1..7).map { index ->
        "fs_single_transparent_${index.toString().padStart(2, '0')}"
    }
    private val AarClsNumberedLayouts: List<Int> = listOf(3, 4, 5, 6, 7, 8, 9, 10, 11)
    val AarClsLayouts: List<String> =
        listOf("fs_single_cls_01", "fs_single_cls_02") +
            AarClsNumberedLayouts.map { index ->
                val number = index.toString().padStart(2, '0')
                "fs_single_cls_$number"
            }
    val AarNavLayouts: List<String> =
        listOf(Nav01, Nav02, Nav03)
    val AarProgressLayouts: List<String> = listOf(ProgressDefault, ProgressOnly01, ProgressOnly02, ProgressOnly03, ProgressOnly04)
    val AarLoopLayouts: List<String> = listOf(LoopDefault)
    val AndroidXmlParityLayouts: List<String> =
        AarSingleUniversalLayouts + AarClsLayouts + AarNavLayouts + AarProgressLayouts + AarLoopLayouts
    val AarProgressClsLayouts: List<String> = listOf(ProgressClsDefault)
    val AarFullscreenLayouts: List<String> =
        AarSingleUniversalLayouts +
            AarSingleTransparentLayouts +
            AarClsLayouts +
            AarNavLayouts +
            AarProgressLayouts +
            AarProgressClsLayouts +
            AarLoopLayouts +
            listOf(
                SingleCtr,
                SingleCtrTransparent,
                MultipleDefault,
                SequenceDefault,
            )
    val AllLayouts: List<String> = AarFullscreenLayouts

    fun normalize(layoutName: String?): String {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        if (key.isBlank()) {
            return SingleDefault
        }

        return if (key in AarFullscreenLayouts) key else SingleDefault
    }

    fun isFullscreenLayoutName(layoutName: String?): Boolean {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        return key in AarFullscreenLayouts
    }

    fun isAndroidXmlParityLayoutName(layoutName: String?): Boolean {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        return key in AndroidXmlParityLayouts
    }
}
