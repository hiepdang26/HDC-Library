package com.hdc.adsmultiplatform.fullscreen

import android.app.Activity
import android.os.Build
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher

internal object AndroidFullscreenBackBlocker {
    private val callbacks = mutableMapOf<String, OnBackInvokedCallback>()

    fun register(activity: Activity, tag: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
            return
        }
        unregister(activity, tag)
        val callback = OnBackInvokedCallback {
            // Fullscreen native ads intentionally block system back until the explicit close button appears.
        }
        activity.onBackInvokedDispatcher.registerOnBackInvokedCallback(
            OnBackInvokedDispatcher.PRIORITY_DEFAULT,
            callback,
        )
        callbacks[tag] = callback
    }

    fun unregister(activity: Activity, tag: String?) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || tag.isNullOrBlank()) {
            return
        }
        val callback = callbacks.remove(tag) ?: return
        activity.onBackInvokedDispatcher.unregisterOnBackInvokedCallback(callback)
    }
}
