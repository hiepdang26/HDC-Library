@file:OptIn(ExperimentalObjCName::class)

package com.hdc.adsmultiplatform.unity

import kotlin.concurrent.Volatile
import kotlin.experimental.ExperimentalObjCName
import kotlin.jvm.JvmStatic
import kotlin.native.ObjCName

/** Receives bridge events. Each event is a JSON object: `{"id":…,"format":…,"type":…}` plus its fields. */
@ObjCName("HDCUnityListener", exact = true)
fun interface HdcUnityListener {
    fun onEvent(eventJson: String)
}

/**
 * The single entry point for Unity: [call] runs a command and the listener receives ad events.
 *
 * A command is `"<format>.<action>"`, for example `"interstitial.load"`, with a JSON object of arguments.
 * The result is a JSON object: `{"ok":true,"value":…}`, or `{"ok":false,"error":"…"}` when it fails.
 * Commands can be called from any thread; ad work runs on the main thread, and so do events.
 */
@ObjCName("HDCUnityBridge", exact = true)
object HdcUnityBridge {
    @Volatile
    private var listener: HdcUnityListener? = null

    init {
        HdcTracking.start()
    }

    @JvmStatic
    fun setListener(listener: HdcUnityListener?) {
        this.listener = listener
    }

    /** [setListener] for Objective-C callers, which pass a block. */
    fun setEventHandler(handler: ((String) -> Unit)?) {
        listener = handler?.let { HdcUnityListener(it) }
    }

    @JvmStatic
    fun call(method: String, argsJson: String): String =
        try {
            val value = HdcCommands.execute(method.trim(), HdcArgs.parse(argsJson))
            HdcJson.write(mapOf("ok" to true, "value" to value))
        } catch (error: Throwable) {
            HdcLog.warn("$method failed: ${error.message}")
            HdcJson.write(mapOf("ok" to false, "error" to (error.message ?: error::class.simpleName.orEmpty())))
        }

    internal fun emit(eventJson: String) {
        HdcLog.debug("event $eventJson")
        listener?.onEvent(eventJson)
    }
}

internal object HdcCommands {
    fun execute(method: String, args: HdcArgs): Any? {
        HdcLog.debug("call $method")
        return when (method) {
            "init" -> HdcSdkCommands.initialize(args)
            "interstitial.load" -> HdcInterstitialCommands.load(args)
            "interstitial.show" -> HdcInterstitialCommands.show(args)
            "interstitial.isReady" -> HdcInterstitialCommands.isReady(args)
            "interstitial.destroy" -> HdcInterstitialCommands.destroy(args)
            "fullscreen.load" -> HdcFullscreenCommands.load(args)
            "fullscreen.show" -> HdcFullscreenCommands.show(args)
            "fullscreen.hide" -> HdcFullscreenCommands.hide(args)
            "fullscreen.isReady" -> HdcFullscreenCommands.isReady(args)
            "fullscreen.destroy" -> HdcFullscreenCommands.destroy(args)
            "popup.load" -> HdcPopupCommands.load(args)
            "popup.updatePlacement" -> HdcPopupCommands.updatePlacement(args)
            "popup.show" -> HdcPopupCommands.show(args)
            "popup.close" -> HdcPopupCommands.close(args)
            "popup.hide" -> HdcPopupCommands.hide(args)
            "popup.stop" -> HdcPopupCommands.stop(args)
            "popup.destroy" -> HdcPopupCommands.destroy(args)
            "popup.isReady" -> HdcPopupCommands.isReady(args)
            "popup.isDisplayable" -> HdcPopupCommands.isDisplayable(args)
            "popup.state" -> HdcPopupCommands.state(args)
            "banner.load" -> HdcBannerCommands.load(args)
            "banner.show" -> HdcBannerCommands.show(args)
            "banner.hide" -> HdcBannerCommands.hide(args)
            "banner.expand" -> HdcBannerCommands.expand(args)
            "banner.collapse" -> HdcBannerCommands.collapse(args)
            "banner.destroy" -> HdcBannerCommands.destroy(args)
            "meta.enableTestMode" -> HdcMetaCommands.enableTestMode(args)
            "meta.disableTestMode" -> HdcMetaCommands.disableTestMode()
            "meta.isTestMode" -> HdcMetaCommands.isTestMode()
            "meta.deviceHash" -> HdcMetaCommands.deviceHash()
            else -> throw IllegalArgumentException("Unknown method: $method")
        }
    }
}

internal object HdcSdkCommands {
    @Volatile
    private var initialized = false

    /** Starts the ads SDK once; `Initialized` is sent every time, so a late caller still gets it. */
    fun initialize(args: HdcArgs): Boolean {
        HdcLog.enabled = args.boolean("debugLog", HdcLog.enabled)
        if (initialized) {
            hdcRunOnMain { HdcEvents.emit(id = "", format = HdcFormat.Sdk, type = HdcEventType.Initialized) }
            return true
        }
        hdcInitializeAds {
            initialized = true
            HdcEvents.emit(id = "", format = HdcFormat.Sdk, type = HdcEventType.Initialized)
        }
        return true
    }
}

internal object HdcLog {
    @Volatile
    var enabled = false

    fun debug(message: String) {
        if (enabled) println("HDCAds: $message")
    }

    fun warn(message: String) {
        println("HDCAds: $message")
    }
}
