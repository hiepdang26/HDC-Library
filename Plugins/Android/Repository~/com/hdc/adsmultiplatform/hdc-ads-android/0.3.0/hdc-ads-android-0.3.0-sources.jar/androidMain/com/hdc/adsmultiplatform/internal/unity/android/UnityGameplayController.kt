package com.hdc.adsmultiplatform.internal.unity.android

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import java.lang.reflect.Method

internal object UnityGameplayController {
    private var activeOwner: String? = null

    fun pause(activity: Activity, owner: String) {
        if (activeOwner == owner) {
            return
        }

        activeOwner = owner
        invokeUnityPlayer(activity, "pause")
    }

    fun resume(activity: Activity, owner: String) {
        if (activeOwner != owner) {
            return
        }

        activeOwner = null
        invokeUnityPlayer(activity, "resume")
    }

    fun clearOwner(owner: String) {
        if (activeOwner == owner) {
            activeOwner = null
        }
    }

    private fun invokeUnityPlayer(activity: Activity, methodName: String) {
        try {
            val unityPlayer = resolveUnityPlayer(activity) ?: return
            val method = unityPlayer.noArgMethod(methodName) ?: return
            method.isAccessible = true
            method.invoke(unityPlayer)
        } catch (_: Throwable) {
            // UnityPlayer is only available inside a Unity Android player.
        }
    }

    private fun resolveUnityPlayer(activity: Activity): Any? =
        activity.findFieldValue("mUnityPlayer")
            ?: findUnityPlayerInDecorView(activity.window?.decorView)

    private fun Any.findFieldValue(fieldName: String): Any? {
        javaClass.fields
            .firstOrNull { it.name == fieldName }
            ?.let { field ->
                return runCatching { field.get(this) }.getOrNull()
            }

        var type: Class<*>? = javaClass
        while (type != null) {
            val field = type.declaredFields.firstOrNull { it.name == fieldName }
            if (field != null) {
                return runCatching {
                    field.isAccessible = true
                    field.get(this)
                }.getOrNull()
            }
            type = type.superclass
        }

        return null
    }

    private fun findUnityPlayerInDecorView(view: View?): Any? {
        if (view == null) {
            return null
        }
        if (view.javaClass.name == "com.unity3d.player.UnityPlayer") {
            return view
        }
        val group = view as? ViewGroup ?: return null
        for (index in 0 until group.childCount) {
            findUnityPlayerInDecorView(group.getChildAt(index))?.let { return it }
        }
        return null
    }

    private fun Any.noArgMethod(name: String): Method? =
        javaClass.methods.firstOrNull { method ->
            method.name == name && method.parameterTypes.isEmpty()
        } ?: runCatching {
            javaClass.getDeclaredMethod(name)
        }.getOrNull()
}
