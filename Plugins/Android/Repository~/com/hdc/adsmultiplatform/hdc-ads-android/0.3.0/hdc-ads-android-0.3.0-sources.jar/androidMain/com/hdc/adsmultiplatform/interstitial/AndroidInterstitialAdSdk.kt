package com.hdc.adsmultiplatform.interstitial

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdValue
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.OnPaidEventListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.internal.core.AdTrackingEvent
import com.hdc.adsmultiplatform.internal.core.AdTrackingEventNames
import com.hdc.adsmultiplatform.internal.core.AdTrackingEvents

private const val AndroidTestInterstitialAdUnitId = "ca-app-pub-3940256099942544/1033173712"
private const val InterstitialAdTrackingFormat = "interstitial"

actual fun defaultInterstitialAdUnitId(): String = AndroidTestInterstitialAdUnitId

object AndroidInterstitialAdSdk {
    @JvmStatic
    @JvmOverloads
    fun create(
        alias: String = DefaultInterstitialAdInstanceId,
        adUnitIdsCsv: String = defaultInterstitialAdUnitId(),
        preloadBufferSize: Int = 1,
        autoReload: Boolean = true,
    ) {
        InterstitialAdRegistry.create(
            alias = alias,
            config = InterstitialAdConfig(
                ids = parseInterstitialCsv(adUnitIdsCsv),
                autoReload = autoReload,
                preloadBufferSize = preloadBufferSize,
            ),
        )
        AndroidInterstitialAdRepository.configure(alias, InterstitialAdRegistry.configFor(alias))
    }

    @JvmStatic
    fun setCallback(alias: String, callback: InterstitialAdCallback?) {
        InterstitialAdRegistry.setCallback(alias, callback)
    }

    @JvmStatic
    @JvmOverloads
    fun load(activity: Activity, alias: String = DefaultInterstitialAdInstanceId) {
        val config = InterstitialAdRegistry.configFor(alias)
        AndroidInterstitialAdRepository.loadWithResult(activity, alias, config.preloadBufferSize) {}
    }

    @JvmStatic
    fun load(activity: Activity, alias: String, bufferSize: Int) {
        AndroidInterstitialAdRepository.loadWithResult(activity, alias, bufferSize) {}
    }

    @JvmStatic
    @JvmOverloads
    fun show(
        activity: Activity,
        alias: String = DefaultInterstitialAdInstanceId,
        options: InterstitialShowOptions = InterstitialShowOptions(),
    ): Boolean =
        AndroidInterstitialAdRepository.show(activity, alias, options)

    @JvmStatic
    @JvmOverloads
    fun destroy(alias: String = DefaultInterstitialAdInstanceId) {
        AndroidInterstitialAdRepository.destroy(alias)
        InterstitialAdRegistry.destroy(alias)
    }

    @JvmStatic
    @JvmOverloads
    fun isReady(alias: String = DefaultInterstitialAdInstanceId): Boolean =
        AndroidInterstitialAdRepository.isReady(alias)
}

internal object AndroidInterstitialAdRepository {
    private val handler = Handler(Looper.getMainLooper())
    private val slots = mutableMapOf<String, AndroidInterstitialSlot>()

    fun configure(alias: String, config: InterstitialAdConfig) {
        runOnMain {
            val normalizedAlias = alias.normalizedInterstitialAlias()
            val normalizedConfig = config.normalized(defaultInterstitialAdUnitId())
            val slot = slots.getOrPut(normalizedAlias) { AndroidInterstitialSlot() }
            if (slot.config != normalizedConfig) {
                slot.requestVersion += 1
                slot.config = normalizedConfig
                slot.queues.clear()
                slot.loadingCounts.clear()
                slot.isShowing = false
            }
        }
    }

    fun loadWithResult(
        activity: Activity,
        alias: String,
        bufferSize: Int,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        runOnMain {
            val normalizedAlias = alias.normalizedInterstitialAlias()
            val registryConfig = InterstitialAdRegistry
                .configFor(normalizedAlias, defaultInterstitialAdUnitId())
                .copy(preloadBufferSize = bufferSize.coerceAtLeast(1))
                .normalized(defaultInterstitialAdUnitId())
            val slot = slots.getOrPut(normalizedAlias) { AndroidInterstitialSlot() }
            if (slot.config != registryConfig) {
                slot.requestVersion += 1
                slot.queues.clear()
                slot.loadingCounts.clear()
                slot.config = registryConfig
            }
            InterstitialAdRegistry.create(normalizedAlias, registryConfig)
            InterstitialAdRegistry.notifyLoading(normalizedAlias)
            callback(
                NativeAdLoadResult(
                    state = NativeAdState.Loading,
                    adUnitId = registryConfig.ids.firstOrNull().orEmpty(),
                ),
            )

            MobileAds.initialize(activity.applicationContext)
            ensureBufferCapacity(activity, normalizedAlias, slot, callback)
        }
    }

    fun show(activity: Activity, alias: String, options: InterstitialShowOptions): Boolean {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post { show(activity, alias, options) }
            return true
        }
        val normalizedAlias = alias.normalizedInterstitialAlias()
        val slot = slots[normalizedAlias]
        if (slot == null || slot.isShowing) {
            InterstitialAdRegistry.notifyFailedToShow(
                alias = normalizedAlias,
                adUnit = "",
                errorCode = NativeAdLoadResult.NoErrorCode,
                error = if (slot?.isShowing == true) "Interstitial is already showing" else "Interstitial not ready. Load first",
            )
            return false
        }
        val loaded = slot.pollReadyAd()
        if (loaded == null) {
            InterstitialAdRegistry.notifyFailedToShow(
                alias = normalizedAlias,
                adUnit = "",
                errorCode = NativeAdLoadResult.NoErrorCode,
                error = "Interstitial not ready. Load first",
            )
            return false
        }

        slot.isShowing = true
        loaded.ad.setImmersiveMode(options.immersiveMode)
        loaded.ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                InterstitialAdRegistry.notifyDisplayed(normalizedAlias, loaded.info)
                InterstitialAdRegistry.notifyOpened(normalizedAlias, loaded.info)
            }

            override fun onAdImpression() {
                InterstitialAdRegistry.notifyImpression(normalizedAlias, loaded.info)
                loaded.info.track(normalizedAlias, AdTrackingEventNames.Impression)
            }

            override fun onAdClicked() {
                InterstitialAdRegistry.notifyClicked(normalizedAlias, loaded.info)
                loaded.info.track(normalizedAlias, AdTrackingEventNames.Clicked)
            }

            override fun onAdDismissedFullScreenContent() {
                loaded.ad.fullScreenContentCallback = null
                slot.isShowing = false
                InterstitialAdRegistry.notifyClosed(normalizedAlias, loaded.info)
                if (slot.config.autoReload) {
                    loadWithResult(activity, normalizedAlias, slot.config.preloadBufferSize) {}
                }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                loaded.ad.fullScreenContentCallback = null
                slot.isShowing = false
                InterstitialAdRegistry.notifyFailedToShow(
                    alias = normalizedAlias,
                    adUnit = loaded.info.adUnitId,
                    errorCode = adError.code,
                    error = adError.message,
                )
                if (slot.config.autoReload) {
                    loadWithResult(activity, normalizedAlias, slot.config.preloadBufferSize) {}
                }
            }
        }
        loaded.ad.show(activity)
        return true
    }

    fun destroy(alias: String) {
        runOnMain {
            slots.remove(alias.normalizedInterstitialAlias())
        }
    }

    fun isReady(alias: String): Boolean {
        val slot = slots[alias.normalizedInterstitialAlias()] ?: return false
        return !slot.isShowing && slot.hasReadyAd()
    }

    private fun ensureBufferCapacity(
        activity: Activity,
        alias: String,
        slot: AndroidInterstitialSlot,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        val version = slot.requestVersion
        slot.config.ids.forEach { adUnitId ->
            while (slot.readyCount(adUnitId) + slot.loadingCount(adUnitId) < slot.config.preloadBufferSize) {
                loadOne(activity, alias, slot, adUnitId, version, callback)
            }
        }
    }

    private fun loadOne(
        activity: Activity,
        alias: String,
        slot: AndroidInterstitialSlot,
        adUnitId: String,
        version: Int,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        slot.incrementLoading(adUnitId)
        InterstitialAd.load(
            activity,
            adUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    if (version != slot.requestVersion) {
                        slot.decrementLoading(adUnitId)
                        return
                    }
                    val info = interstitialAd.toInterstitialInfo(adUnitId)
                    interstitialAd.onPaidEventListener = OnPaidEventListener { adValue ->
                        info.track(alias, AdTrackingEventNames.Paid, adValue)
                        InterstitialAdRegistry.notifyPaidImpression(
                            alias = alias,
                            ad = info,
                            paidInfo = InterstitialAdPaidInfo(
                                adUnitId = info.adUnitId,
                                revenueMicros = adValue.valueMicros,
                                currencyCode = adValue.currencyCode,
                                mediationAdapter = info.mediationAdapter,
                                adSource = info.adSource,
                                responseId = info.responseId,
                                precision = adValue.precisionType,
                            ),
                        )
                    }
                    slot.decrementLoading(adUnitId)
                    slot.enqueue(adUnitId, AndroidLoadedInterstitialAd(interstitialAd, info))
                    InterstitialAdRegistry.notifyLoaded(alias, info)
                    callback(NativeAdLoadResult(state = NativeAdState.Loaded, adUnitId = adUnitId))
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    if (version != slot.requestVersion) {
                        slot.decrementLoading(adUnitId)
                        return
                    }
                    slot.decrementLoading(adUnitId)
                    InterstitialAdRegistry.notifyFailedToLoad(
                        alias = alias,
                        adUnit = adUnitId,
                        errorCode = error.code,
                        error = error.message,
                    )
                    callback(
                        NativeAdLoadResult(
                            state = NativeAdState.Failed,
                            adUnitId = adUnitId,
                            code = error.code,
                            message = error.message,
                        ),
                    )
                }
            },
        )
    }

    private fun runOnMain(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            handler.post(block)
        }
    }
}

private data class AndroidLoadedInterstitialAd(
    val ad: InterstitialAd,
    val info: InterstitialAdInfo,
)

private class AndroidInterstitialSlot {
    var config: InterstitialAdConfig = InterstitialAdConfig(ids = listOf(defaultInterstitialAdUnitId()))
    var isShowing: Boolean = false
    var requestVersion: Int = 0
    val queues: MutableMap<String, java.util.ArrayDeque<AndroidLoadedInterstitialAd>> = mutableMapOf()
    val loadingCounts: MutableMap<String, Int> = mutableMapOf()

    fun enqueue(adUnitId: String, loaded: AndroidLoadedInterstitialAd) {
        queues.getOrPut(adUnitId) { java.util.ArrayDeque() }.addLast(loaded)
    }

    fun pollReadyAd(): AndroidLoadedInterstitialAd? {
        config.ids.forEach { adUnitId ->
            val loaded = queues[adUnitId]?.pollFirst()
            if (loaded != null) {
                return loaded
            }
        }
        return queues.values.firstNotNullOfOrNull { it.pollFirst() }
    }

    fun hasReadyAd(): Boolean =
        queues.values.any { it.isNotEmpty() }

    fun readyCount(adUnitId: String): Int =
        queues[adUnitId]?.size ?: 0

    fun loadingCount(adUnitId: String): Int =
        loadingCounts[adUnitId] ?: 0

    fun incrementLoading(adUnitId: String) {
        loadingCounts[adUnitId] = loadingCount(adUnitId) + 1
    }

    fun decrementLoading(adUnitId: String) {
        val next = (loadingCount(adUnitId) - 1).coerceAtLeast(0)
        if (next == 0) {
            loadingCounts.remove(adUnitId)
        } else {
            loadingCounts[adUnitId] = next
        }
    }
}

private fun InterstitialAdInfo.track(alias: String, name: String, value: AdValue? = null) {
    AdTrackingEvents.emit(
        AdTrackingEvent(
            instanceId = alias,
            format = InterstitialAdTrackingFormat,
            name = name,
            adUnitId = adUnitId,
            valueMicros = value?.valueMicros ?: 0L,
            currencyCode = value?.currencyCode.orEmpty(),
            precision = value?.precisionType ?: 0,
            adSourceName = adSource.orEmpty(),
            mediationAdapter = mediationAdapter,
            responseId = responseId,
        ),
    )
}

private fun InterstitialAd.toInterstitialInfo(adUnitId: String): InterstitialAdInfo {
    val response = responseInfo
    val loadedAdapter = response.loadedAdapterResponseInfo
    return InterstitialAdInfo(
        adUnitId = adUnitId,
        mediationAdapter = response.mediationAdapterClassName.orEmpty(),
        responseId = response.responseId.orEmpty(),
        adSource = loadedAdapter?.adSourceName,
    )
}

private fun Context.findActivity(): Activity? =
    when (this) {
        is Activity -> this
        is ContextWrapper -> baseContext.findActivity()
        else -> null
    }

private fun parseInterstitialCsv(value: String): List<String> =
    value.split(',', ';', '\n', '\r').map { it.trim() }.filter { it.isNotEmpty() }

private fun String.normalizedInterstitialAlias(): String =
    ifBlank { DefaultInterstitialAdInstanceId }
