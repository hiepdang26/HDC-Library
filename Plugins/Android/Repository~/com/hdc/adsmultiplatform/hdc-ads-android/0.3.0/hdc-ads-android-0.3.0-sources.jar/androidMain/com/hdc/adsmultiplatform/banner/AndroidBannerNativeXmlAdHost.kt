package com.hdc.adsmultiplatform.banner

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.internal.core.NativeAdFormats
import com.hdc.adsmultiplatform.internal.preload.android.AndroidNativeAdRepository
import com.hdc.adsmultiplatform.shared.R
import kotlin.math.roundToInt

/**
 * The native banner drawn from the XML layouts, without Compose: each layout has a `_collapse` and an
 * `_expand` variant. The collapsed banner counts down before its close button shows; the expanded one shows
 * its close button once it can collapse.
 */
internal class AndroidBannerNativeXmlAdHost(context: Context) : FrameLayout(context) {
    private var layoutKey: String? = null
    private var adView: NativeAdView? = null
    private var boundAd: NativeAd? = null
    private var lastMissingAdInstanceId: String? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)
    }

    fun render(
        instanceId: String,
        fallbackAdUnitId: String,
        layoutName: String,
        isExpanded: Boolean,
        showInternalExpandedClose: Boolean,
        enableExpandedCloseOverlay: Boolean,
        collapseCountdownSecondsRemaining: Int,
        collapseCountdownProgress: Float,
        showCollapsedClose: Boolean,
        onStateChanged: (NativeAdState) -> Unit,
        onCollapsedCloseClick: () -> Unit,
        onCollapseClick: () -> Unit,
    ) {
        val ad = AndroidNativeAdRepository.loadedAd(NativeAdFormats.Banner, instanceId)
        if (ad == null) {
            if (fallbackAdUnitId.isBlank()) {
                release()
            }
            if (lastMissingAdInstanceId != instanceId) {
                lastMissingAdInstanceId = instanceId
                onStateChanged(NativeAdState.Failed)
            }
            return
        }

        lastMissingAdInstanceId = null
        val isNewAd = boundAd !== ad
        val key = BannerNativeAdLayoutCatalog.normalize(layoutName) + if (isExpanded) "_expand" else "_collapse"
        val layoutChanged = key != layoutKey
        val view = if (layoutChanged) inflate(key, isExpanded) else adView ?: return
        if (isNewAd || layoutChanged) {
            bind(view, ad)
        }

        val closeButton = view.first<View>(R.id.ad_close_button, R.id.ad_expand_close_button)
        val countdownText = view.first<TextView>(R.id.txt_time_count, R.id.ad_expand_time_count)
        if (isExpanded) {
            countdownText?.visibility = View.GONE
            showCountdownVisual(view, visible = false, progress = 0f)
            // Where the close button sits is the layout's; enableExpandedCloseOverlay only matters to the Compose host.
            closeButton?.showClickable(showInternalExpandedClose, onCollapseClick)
        } else {
            val counting = !showCollapsedClose && collapseCountdownSecondsRemaining > 0
            countdownText?.apply {
                text = collapseCountdownSecondsRemaining.coerceAtLeast(0).toString()
                visibility = if (counting) View.VISIBLE else View.GONE
            }
            showCountdownVisual(view, visible = counting, progress = collapseCountdownProgress)
            closeButton?.showClickable(showCollapsedClose, onCollapsedCloseClick)
        }

        if (isNewAd) {
            onStateChanged(NativeAdState.Loaded)
        }
    }

    fun release() {
        removeAllViews()
        adView?.destroy()
        adView = null
        layoutKey = null
        boundAd = null
        lastMissingAdInstanceId = null
    }

    private fun inflate(key: String, isExpanded: Boolean): NativeAdView {
        removeAllViews()
        adView?.destroy()
        val fallback = "bn_single_transparent_01" + if (isExpanded) "_expand" else "_collapse"
        val resId = layoutId(key).takeIf { it != 0 } ?: layoutId(fallback)
        val root = LayoutInflater.from(context).inflate(resId, this, false)
        // One layout holds both variants in a shared root; the collapsed one is its own ad view.
        val view = root as? NativeAdView
            ?: root.first<NativeAdView>(if (isExpanded) R.id.banner_expand_ad_view else R.id.banner_collapse_ad_view, R.id.native_ad_view)
            ?: NativeAdView(context).also { wrapper -> wrapper.addView(root) }
        root.first<View>(if (isExpanded) R.id.banner_collapse_ad_view else R.id.banner_expand_ad_view)?.visibility = View.GONE
        addView(if (view.parent == null) view else root, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        layoutKey = key
        adView = view
        boundAd = null
        return view
    }

    // Looked up by resource name rather than R fields, which minified builds may strip.
    private fun layoutId(name: String): Int = resources.getIdentifier(name, "layout", context.packageName)

    private fun bind(view: NativeAdView, ad: NativeAd) {
        boundAd = ad
        view.first<TextView>(R.id.ad_headline)?.let { headline ->
            headline.setTextOrHide(ad.headline)
            view.headlineView = headline
        }
        view.first<TextView>(R.id.ad_body, R.id.ad_description)?.let { body ->
            body.setTextOrHide(ad.body ?: ad.store ?: ad.advertiser)
            view.bodyView = body
        }
        view.first<TextView>(R.id.ad_advertiser)?.let { advertiser ->
            advertiser.setTextOrHide(ad.advertiser)
            view.advertiserView = advertiser
        }
        view.first<TextView>(R.id.ad_call_to_action, R.id.ad_expand_call_to_action)?.let { cta ->
            cta.setTextOrHide(ad.callToAction)
            view.callToActionView = cta
        }
        view.first<ImageView>(R.id.ad_app_icon, R.id.ad_expand_app_icon)?.let { icon ->
            icon.setImageDrawable(ad.icon?.drawable)
            icon.visibility = if (ad.icon != null) View.VISIBLE else View.GONE
            view.iconView = icon
        }
        view.first<MediaView>(R.id.ad_media)?.let { media ->
            media.mediaContent = ad.mediaContent
            media.visibility = if (ad.mediaContent != null) View.VISIBLE else View.GONE
            view.mediaView = media
        }
        view.first<ImageView>(R.id.img_background)?.apply {
            setImageDrawable(ad.mediaContent?.mainImage ?: ad.icon?.drawable)
            isClickable = false
        }
        view.first<View>(R.id.img_view_demo)?.visibility = View.GONE
        view.first<ViewGroup>(R.id.ad_choices_container, R.id.ad_choices_media)?.let { container ->
            val choices = AdChoicesView(context)
            container.removeAllViews()
            container.addView(choices, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            view.adChoicesView = choices
        }
        view.post {
            if (boundAd === ad && adView === view) {
                view.setNativeAd(ad)
            }
        }
    }

    private fun showCountdownVisual(view: View, visible: Boolean, progress: Float) {
        val value = (progress.coerceIn(0f, 1f) * ProgressScale).roundToInt()
        listOfNotNull(
            view.first<ProgressBar>(R.id.banner_countdown_progress),
            view.first<ProgressBar>(R.id.banner_countdown_progress_glow),
        ).forEach { bar ->
            bar.max = ProgressScale
            bar.progress = value
            bar.visibility = if (visible) View.VISIBLE else View.GONE
        }
        view.first<LinearLayout>(R.id.banner_countdown_segments)?.let { segments ->
            segments.visibility = if (visible) View.VISIBLE else View.GONE
            val count = segments.childCount
            if (count == 0) {
                return@let
            }
            // Progress runs from 1 to 0 over the countdown; the lit segment moves left to right.
            val active = ((1f - progress.coerceIn(0f, 1f)) * count).toInt().coerceIn(0, count - 1)
            for (index in 0 until count) {
                val child = segments.getChildAt(index)
                child.isSelected = index == active
                child.alpha = when {
                    index < active -> 0.72f
                    index == active -> 1f
                    else -> 0.34f
                }
            }
        }
    }

    // Layouts differ in which views they have: every lookup can miss.
    private fun <T : View> View.first(vararg ids: Int): T? {
        for (id in ids) {
            val found: T? = findViewById(id)
            if (found != null) {
                return found
            }
        }
        return null
    }

    private fun View.showClickable(visible: Boolean, onClick: () -> Unit) {
        visibility = if (visible) View.VISIBLE else View.GONE
        isClickable = visible
        setOnClickListener(if (visible) View.OnClickListener { onClick() } else null)
        if (visible) {
            bringToFront()
        }
    }

    private fun TextView.setTextOrHide(value: String?) {
        text = value.orEmpty()
        visibility = if (value.isNullOrBlank()) View.GONE else View.VISIBLE
    }

    private companion object {
        const val ProgressScale = 1000
    }
}
