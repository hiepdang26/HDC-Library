package com.hdc.adsmultiplatform.internal.core

import kotlin.concurrent.Volatile

internal object AdTrackingEventNames {
    const val Impression = "Impression"
    const val Clicked = "Clicked"
    const val Paid = "Paid"
}

/** An impression, click or paid event of one ad. [instanceId] is the alias the host loaded the ad with. */
internal data class AdTrackingEvent(
    val instanceId: String,
    val format: String,
    val name: String,
    val adUnitId: String,
    val valueMicros: Long = 0L,
    val currencyCode: String = "",
    val precision: Int = 0,
    val adSourceName: String = "",
    val mediationAdapter: String = "",
    val responseId: String = "",
)

/** Impression, click and paid events of every ad format, on both platforms. The Unity bridge listens. */
internal object AdTrackingEvents {
    @Volatile
    var listener: ((AdTrackingEvent) -> Unit)? = null

    fun emit(event: AdTrackingEvent) {
        if (event.instanceId.isEmpty()) {
            return
        }
        listener?.invoke(event)
    }
}
