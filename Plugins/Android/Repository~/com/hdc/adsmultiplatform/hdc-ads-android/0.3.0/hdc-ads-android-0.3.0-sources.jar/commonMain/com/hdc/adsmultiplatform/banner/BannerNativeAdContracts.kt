package com.hdc.adsmultiplatform.banner

import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.defaultNativeAdUnitId

const val DefaultBannerNativeAdInstanceId = "banner_native_default"

data class BannerNativeAdRequest(
    val instanceId: String = DefaultBannerNativeAdInstanceId,
    val adUnitIds: List<String>,
)

data class BannerNativeAdShowOptions(
    val layoutName: String = BannerNativeAdLayoutCatalog.Default,
    val timeReloadSeconds: Int = 0,
    val timeCountdownSeconds: Int = 5,
    val timeCollapseSeconds: Int = 5,
)

data class BannerNativeAdConfig(
    val ids: List<String>,
    val layoutNames: List<String> = BannerNativeAdLayoutCatalog.All,
    val timeReloadSeconds: Int = 0,
    val timeCountdownSeconds: Int = 5,
    val timeCollapseSeconds: Int = 5,
)

data class BannerNativeAdInfo(
    val alias: String,
    val instanceId: String,
    val adUnitId: String,
    val layoutName: String = "",
)

data class BannerNativeAdError(
    val alias: String,
    val adUnitId: String,
    val code: Int = -1,
    val message: String,
)

interface BannerNativeAdCallback {
    fun onLoaded(ad: BannerNativeAdInfo) = Unit
    fun onDisplayable(alias: String) = Unit
    fun onDisplayed(ad: BannerNativeAdInfo) = Unit
    fun onOpened(ad: BannerNativeAdInfo) = Unit
    fun onClosed(ad: BannerNativeAdInfo) = Unit
    fun onClicked(ad: BannerNativeAdInfo) = Unit
    fun onFailedToLoad(error: BannerNativeAdError) = Unit
}

object BannerNativeAdReloadPolicy {
    fun isEnabled(timeReloadSeconds: Int): Boolean =
        timeReloadSeconds > 0

    fun intervalMillis(timeReloadSeconds: Int): Long =
        timeReloadSeconds.coerceAtLeast(0) * 1_000L
}

fun interface BannerNativeAdLoader {
    fun load(
        request: BannerNativeAdRequest,
        onStateChanged: (NativeAdState) -> Unit,
    )

    fun loadWithResult(
        request: BannerNativeAdRequest,
        onResult: (NativeAdLoadResult) -> Unit,
    ) {
        val fallbackAdUnitId = request.adUnitIds.firstOrNull().orEmpty()
        load(request) { state ->
            onResult(NativeAdLoadResult(state = state, adUnitId = fallbackAdUnitId))
        }
    }

    fun destroy(instanceId: String) = Unit

    fun load(adUnitId: String, onStateChanged: (NativeAdState) -> Unit) {
        load(
            BannerNativeAdRequest(adUnitIds = listOf(adUnitId)),
            onStateChanged,
        )
    }
}

