package com.hdc.adsmultiplatform.banner

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.internal.core.NativeAdFormats
import com.hdc.adsmultiplatform.internal.preload.android.AndroidNativeAdRepository
import kotlin.math.roundToInt

/**
 * Native banners along the bottom of an activity's content, typically Unity's: the Android side of
 * IosBannerNativeAdSdk. One runtime per alias. Call on the main thread.
 */
internal object AndroidBannerNativeAdUnityHost {
    private val runtimes = mutableMapOf<String, AndroidBannerRuntime>()

    fun load(
        activity: Activity,
        alias: String,
        config: BannerNativeAdConfig,
        onStateChanged: (NativeAdState) -> Unit,
    ) {
        runtime(alias).apply {
            this.activity = activity
            stateCallback = onStateChanged
            controller.configure(config)
            controller.load()
        }
    }

    fun show(activity: Activity, alias: String) {
        runtime(alias).apply {
            this.activity = activity
            ensurePresented()
            controller.show()
        }
    }

    fun expand(alias: String, enableClick: Boolean): Boolean =
        runtimes[normalizedAlias(alias)]?.controller?.expand(enableClick) == true

    fun collapse(alias: String) {
        runtimes[normalizedAlias(alias)]?.controller?.collapse()
    }

    fun hide(alias: String) {
        runtimes[normalizedAlias(alias)]?.controller?.hide()
    }

    fun destroy(alias: String) {
        runtimes.remove(normalizedAlias(alias))?.destroy()
    }

    private fun runtime(alias: String): AndroidBannerRuntime =
        runtimes.getOrPut(normalizedAlias(alias)) { AndroidBannerRuntime(normalizedAlias(alias)) }

    private fun normalizedAlias(alias: String): String =
        alias.ifBlank { DefaultBannerNativeAdInstanceId }
}

private class AndroidBannerRuntime(private val alias: String) {
    private val handler = Handler(Looper.getMainLooper())
    var activity: Activity? = null
    var stateCallback: (NativeAdState) -> Unit = {}
    private var snapshot = BannerNativeAdRuntimeSnapshot()
    private var hostView: AndroidBannerNativeXmlAdHost? = null

    private val loader = object : BannerNativeAdRuntimeLoader {
        override fun load(instanceId: String, adUnitId: String, callback: (NativeAdLoadResult) -> Unit) {
            val context = activity ?: return callback(
                NativeAdLoadResult(
                    state = NativeAdState.Failed,
                    adUnitId = adUnitId,
                    code = NativeAdLoadResult.NoErrorCode,
                    message = "Missing activity",
                ),
            )
            AndroidNativeAdRepository.loadWithResult(
                format = NativeAdFormats.Banner,
                instanceId = instanceId,
                context = context,
                adUnitIds = listOf(adUnitId),
                callback = callback,
            )
        }

        override fun destroy(instanceId: String) {
            AndroidNativeAdRepository.destroy(NativeAdFormats.Banner, instanceId)
        }
    }

    private val scheduler = BannerNativeAdRuntimeScheduler { delayMillis, block ->
        val runnable = Runnable(block)
        handler.postDelayed(runnable, delayMillis)
        BannerNativeAdRuntimeCancellation { handler.removeCallbacks(runnable) }
    }

    val controller = BannerNativeAdRuntimeController(
        alias = alias,
        loader = loader,
        scheduler = scheduler,
        onSnapshotChanged = { next ->
            snapshot = next
            stateCallback(next.state)
            if (next.isVisible) {
                ensurePresented()
                render(next)
            } else if (next.state == NativeAdState.onClosed) {
                dismiss()
            }
        },
    )

    fun ensurePresented() {
        val activity = activity ?: return
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        val current = hostView
        if (current != null && current.parent === content) {
            layoutBanner()
            return
        }
        if (current != null) {
            dismiss()
        }
        val host = AndroidBannerNativeXmlAdHost(activity)
        content.addView(
            host,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1, Gravity.BOTTOM),
        )
        hostView = host
        layoutBanner()
    }

    fun destroy() {
        controller.destroy()
        dismiss()
    }

    private fun render(current: BannerNativeAdRuntimeSnapshot) {
        val host = hostView ?: return
        val instanceId = current.activeInstanceId ?: return
        layoutBanner()
        host.bringToFront()
        host.render(
            instanceId = instanceId,
            fallbackAdUnitId = current.activeAdUnitId.orEmpty(),
            layoutName = current.activeLayoutName,
            isExpanded = current.isExpanded,
            showInternalExpandedClose = current.isExpanded && current.canCollapseExpanded,
            enableExpandedCloseOverlay = current.expandedCloseClickEnabled,
            collapseCountdownSecondsRemaining = current.collapseCountdownSecondsRemaining,
            collapseCountdownProgress = current.collapseCountdownProgress,
            showCollapsedClose = current.canCloseCollapsed,
            onStateChanged = stateCallback,
            onCollapsedCloseClick = { controller.hide() },
            onCollapseClick = { controller.collapse() },
        )
    }

    // The banner spans the width; its height is a share of the content height, larger while expanded.
    private fun layoutBanner() {
        val host = hostView ?: return
        val content = host.parent as? ViewGroup ?: return
        val metrics = content.resources.displayMetrics
        val widthPx = if (content.width > 0) content.width else metrics.widthPixels
        val heightPx = if (content.height > 0) content.height else metrics.heightPixels
        val bannerHeightDp = BannerNativeAdSizing.overlayHeight(
            isExpanded = snapshot.isExpanded,
            viewportHeight = heightPx / metrics.density.toDouble(),
            isLandscape = widthPx > heightPx,
        )
        val params = host.layoutParams as? FrameLayout.LayoutParams ?: return
        val bannerHeightPx = (bannerHeightDp * metrics.density).roundToInt()
        if (params.height != bannerHeightPx || params.gravity != Gravity.BOTTOM) {
            params.height = bannerHeightPx
            params.gravity = Gravity.BOTTOM
            host.layoutParams = params
        }
    }

    private fun dismiss() {
        val host = hostView ?: return
        hostView = null
        host.release()
        (host.parent as? ViewGroup)?.removeView(host)
    }
}
