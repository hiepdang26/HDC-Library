package com.hdc.adsmultiplatform.fullscreen

import android.content.Context
import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.internal.preload.android.AndroidNativeAdRepository
import com.hdc.adsmultiplatform.shared.R

internal class AndroidFullscreenNativeXmlAdHost(context: Context) : FrameLayout(context) {
    private var currentLayoutName: String? = null
    private var binding: FullscreenNativeXmlBinding? = null
    private var boundAd: NativeAd? = null
    private var boundClickAssets: NativeClickAssetOptions? = null
    private var boundAssetVisibility: NativeAssetVisibilityOptions? = null
    private var lastMissingAdInstanceId: String? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)
    }

    fun render(
        instanceId: String,
        fallbackAdUnitId: String,
        layoutName: String,
        controlState: FullscreenNativeAdControlState,
        showControls: Boolean = true,
        clickAssets: NativeClickAssetOptions = NativeClickAssetOptions(),
        assetVisibility: NativeAssetVisibilityOptions = NativeAssetVisibilityOptions(),
        onStateChanged: (NativeAdState) -> Unit,
        onClose: (() -> Unit)?,
    ) {
        val normalizedLayoutName = FullscreenLayoutCatalog.normalize(layoutName)
        val ad = AndroidNativeAdRepository.loadedAd(instanceId)
        if (ad == null) {
            if (fallbackAdUnitId.isBlank()) {
                clearLayout()
            }
            if (lastMissingAdInstanceId != instanceId) {
                lastMissingAdInstanceId = instanceId
                onStateChanged(NativeAdState.Failed)
            }
            return
        }

        lastMissingAdInstanceId = null
        val previousAd = boundAd
        val previousLayout = currentLayoutName
        val nextBinding = ensureLayout(normalizedLayoutName)
        val shouldRebind =
            previousAd !== ad ||
                previousLayout != normalizedLayoutName ||
                boundClickAssets != clickAssets ||
                boundAssetVisibility != assetVisibility
        if (shouldRebind) {
            bindNativeAd(ad, nextBinding, clickAssets, assetVisibility)
        }
        applyControls(nextBinding, controlState, showControls, onClose)
        if (previousAd !== ad || previousLayout != normalizedLayoutName) {
            onStateChanged(NativeAdState.Loaded)
        }
    }

    fun release() {
        lastMissingAdInstanceId = null
        boundAd = null
        boundClickAssets = null
        boundAssetVisibility = null
        clearLayout()
    }

    private fun ensureLayout(layoutName: String): FullscreenNativeXmlBinding {
        binding?.takeIf { currentLayoutName == layoutName }?.let { return it }

        clearLayout()
        val adView = LayoutInflater.from(context)
            .inflate(layoutResId(layoutName), this, false) as NativeAdView
        val adChoicesContainer = adView.findViewById<ViewGroup>(R.id.ad_choices_container)
        val adChoicesView = adChoicesContainer?.let { container ->
            AdChoicesView(context).also { view ->
                container.removeAllViews()
                container.addView(
                    view,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                    ),
                )
            }
        }
        val nextBinding = FullscreenNativeXmlBinding(
            adView = adView,
            mediaView = adView.findViewById(R.id.ad_media),
            iconView = adView.findViewById(R.id.ad_app_icon),
            closeIconView = adView.findViewById(R.id.ad_close_app_icon),
            callToActionView = adView.findViewById(R.id.ad_call_to_action),
            headlineView = adView.findViewById(R.id.ad_headline),
            closeHeadlineView = adView.findViewById(R.id.ad_close_app_name),
            bodyView = adView.findViewById(R.id.ad_body),
            advertiserView = adView.findViewById(R.id.ad_advertiser),
            adChoicesView = adChoicesView,
            demoImageView = adView.findViewById(R.id.img_view_demo),
            backgroundImageView = adView.findViewById(R.id.img_background),
            closeButtonView = adView.findViewById(R.id.ad_close_button),
            countdownTextView = adView.findViewById(R.id.txt_time_count),
            clsProgressView = adView.findViewById(R.id.cls_countdown_progress),
            navProgressView = adView.findViewById(R.id.nav_countdown_progress),
            prgsProgressView = adView.findViewById(R.id.prgs_countdown_progress),
            loopProgressView = adView.findViewById(R.id.loop_countdown_progress),
            loopLoadingProgressView = adView.findViewById(R.id.loop_loading_progress),
            openStoreButtonView = adView.findViewById(R.id.ad_open_store_button),
        )

        addView(adView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        currentLayoutName = layoutName
        binding = nextBinding
        return nextBinding
    }

    private fun bindNativeAd(
        ad: NativeAd,
        binding: FullscreenNativeXmlBinding,
        clickAssets: NativeClickAssetOptions,
        assetVisibility: NativeAssetVisibilityOptions,
    ) {
        boundAd = ad
        boundClickAssets = clickAssets
        boundAssetVisibility = assetVisibility
        val hasVideoMedia = ad.mediaContent?.hasVideoContent() == true
        val mediaVisible = assetVisibility.media && when {
            hasVideoMedia -> assetVisibility.mediaVideo
            else -> assetVisibility.mediaImage
        }

        binding.adView.clearRegisteredAssets()
        bindTextAsset(
            view = binding.headlineView,
            text = ad.headline,
            visible = assetVisibility.headline,
            clickEnabled = clickAssets.headline,
            register = { binding.adView.headlineView = it },
        )
        binding.closeHeadlineView?.apply {
            text = ad.headline ?: ad.advertiser ?: ad.store.orEmpty()
            visibility = if (text.isNullOrBlank()) View.GONE else View.VISIBLE
            isClickable = false
            isFocusable = false
        }
        bindTextAsset(
            view = binding.bodyView,
            text = ad.body ?: ad.store ?: ad.price ?: ad.advertiser,
            visible = assetVisibility.bodyOrDescriptionVisible,
            clickEnabled = clickAssets.bodyOrDescriptionClickEnabled,
            register = { binding.adView.bodyView = it },
        )
        bindTextAsset(
            view = binding.advertiserView,
            text = ad.advertiser,
            visible = assetVisibility.advertiser,
            clickEnabled = clickAssets.advertiser,
            register = { binding.adView.advertiserView = it },
        )
        bindTextAsset(
            view = binding.callToActionView,
            text = ad.callToAction,
            visible = assetVisibility.cta,
            clickEnabled = clickAssets.cta,
            register = { binding.adView.callToActionView = it },
        )

        binding.iconView?.apply {
            setImageDrawable(ad.icon?.drawable)
            visibility = if (assetVisibility.icon && ad.icon != null) View.VISIBLE else View.GONE
            applyAssetClickState(clickAssets.icon)
            if (visibility == View.VISIBLE && clickAssets.icon) {
                binding.adView.iconView = this
            }
        }
        binding.closeIconView?.apply {
            setImageDrawable(ad.icon?.drawable)
            visibility = if (assetVisibility.icon && ad.icon != null) View.VISIBLE else View.GONE
            isClickable = false
            isFocusable = false
        }
        binding.mediaView?.apply {
            mediaContent = ad.mediaContent
            visibility = if (mediaVisible && ad.mediaContent != null) View.VISIBLE else View.GONE
            applyAssetClickState(clickAssets.anyMediaClickEnabled)
            if (visibility == View.VISIBLE && clickAssets.anyMediaClickEnabled) {
                binding.adView.mediaView = this
            }
            post {
                requestLayout()
                invalidate()
            }
        }
        binding.demoImageView?.visibility = View.GONE
        bindBackground(ad, binding, mediaVisible)
        binding.adChoicesView?.let { binding.adView.adChoicesView = it }
        normalizeAdLabels(binding.adView)

        binding.adView.post {
            if (boundAd === ad && this.binding === binding) {
                binding.adView.setNativeAd(ad)
            }
        }
    }

    private fun bindTextAsset(
        view: TextView?,
        text: String?,
        visible: Boolean,
        clickEnabled: Boolean,
        register: (View) -> Unit,
    ) {
        view ?: return
        view.text = text.orEmpty()
        view.visibility = if (visible && !text.isNullOrBlank()) View.VISIBLE else View.GONE
        view.applyAssetClickState(clickEnabled)
        if (view.visibility == View.VISIBLE && clickEnabled) {
            register(view)
        }
    }

    private fun bindBackground(
        ad: NativeAd,
        binding: FullscreenNativeXmlBinding,
        mediaVisible: Boolean,
    ) {
        val background = binding.backgroundImageView ?: return
        background.isClickable = false
        background.isFocusable = false
        if (!mediaVisible) {
            background.setImageDrawable(null)
            background.clearBlurEffectCompat()
            background.visibility = View.GONE
            return
        }
        val drawable = ad.mediaContent?.mainImage ?: ad.icon?.drawable
        if (drawable != null) {
            background.setImageDrawable(drawable)
            background.applyBlurEffectCompat()
            background.alpha = BackgroundImageAlpha
            background.visibility = View.VISIBLE
        } else {
            background.setImageDrawable(null)
            background.background = ColorDrawable(Color.BLACK)
            background.clearBlurEffectCompat()
            background.alpha = 1f
            background.visibility = View.VISIBLE
        }
    }

    private fun applyControls(
        binding: FullscreenNativeXmlBinding,
        controlState: FullscreenNativeAdControlState,
        showControls: Boolean,
        onClose: (() -> Unit)?,
    ) {
        val showCountdown = showControls && controlState.showCountdown
        binding.countdownTextView?.apply {
            text = controlState.remainingSeconds.coerceAtLeast(0).toString()
            visibility = if (showCountdown) View.VISIBLE else View.GONE
        }
        val progress = (controlState.progress.coerceIn(0f, 1f) * ProgressScale).toInt()
        listOfNotNull(binding.clsProgressView, binding.navProgressView, binding.prgsProgressView).forEach { progressView ->
            progressView.max = ProgressScale
            progressView.progress = progress
            progressView.visibility = if (showControls && controlState.showProgress) View.VISIBLE else View.GONE
        }
        binding.loopProgressView?.apply {
            max = ProgressScale
            this.progress = progress
            visibility = if (
                showControls && controlState.showProgress &&
                controlState.phase == FullscreenNativeAdControlPhase.PROGRESS
            ) View.VISIBLE else View.GONE
        }
        binding.loopLoadingProgressView?.visibility =
            if (showControls && controlState.showProgress && controlState.phase == FullscreenNativeAdControlPhase.CLOSE_DELAY) {
                View.VISIBLE
            } else View.GONE
        binding.openStoreButtonView?.visibility =
            if (
                showControls &&
                (controlState.showOpenStoreButton || currentLayoutName in FullscreenLayoutCatalog.AarNavLayouts)
            ) {
                View.VISIBLE
            } else {
                View.GONE
            }
        binding.closeButtonView?.apply {
            visibility = if (showControls && controlState.showCloseButton) View.VISIBLE else View.GONE
            alpha = controlState.closeButtonAlpha
            isEnabled = controlState.closeButtonEnabled
            isClickable = controlState.closeButtonEnabled
            isFocusable = controlState.closeButtonEnabled
            setOnClickListener {
                if (controlState.closeButtonEnabled) {
                    onClose?.invoke()
                }
            }
            bringToFront()
        }
    }

    private fun normalizeAdLabels(root: View) {
        root.forEachTextViewDescendant { textView ->
            if (textView.text?.toString()?.trim()?.equals("ad", ignoreCase = true) == true) {
                textView.text = "Ad"
                textView.visibility = View.VISIBLE
                textView.isClickable = false
                textView.isFocusable = false
            }
        }
    }

    private fun clearLayout() {
        binding?.adView?.destroy()
        boundAd = null
        boundClickAssets = null
        boundAssetVisibility = null
        binding = null
        currentLayoutName = null
        removeAllViews()
    }

    // Looked up by resource name rather than R fields, which minified builds may strip.
    private fun layoutResId(layoutName: String): Int {
        val id = resources.getIdentifier(layoutName, "layout", context.packageName)
        return if (id != 0) id else R.layout.fs_single_universal_01
    }

    private fun NativeAdView.clearRegisteredAssets() {
        headlineView = null
        bodyView = null
        callToActionView = null
        iconView = null
        advertiserView = null
        mediaView = null
        adChoicesView = null
    }

    private fun View.applyAssetClickState(enabled: Boolean) {
        isClickable = enabled
        isFocusable = enabled
        setOnTouchListener(null)
    }

    private fun ImageView.applyBlurEffectCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            setRenderEffect(
                RenderEffect.createBlurEffect(
                    BackgroundBlurRadiusPx,
                    BackgroundBlurRadiusPx,
                    Shader.TileMode.CLAMP,
                ),
            )
        }
    }

    private fun ImageView.clearBlurEffectCompat() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            setRenderEffect(null)
        }
    }

    private fun View.forEachTextViewDescendant(action: (TextView) -> Unit) {
        if (this is TextView) {
            action(this)
        }
        if (this is ViewGroup) {
            for (index in 0 until childCount) {
                getChildAt(index).forEachTextViewDescendant(action)
            }
        }
    }

    private companion object {
        private const val ProgressScale = 1000
        private const val BackgroundImageAlpha = 0.05f
        private const val BackgroundBlurRadiusPx = 25f
    }
}

private data class FullscreenNativeXmlBinding(
    val adView: NativeAdView,
    val mediaView: MediaView?,
    val iconView: ImageView?,
    val closeIconView: ImageView?,
    val callToActionView: TextView?,
    val headlineView: TextView?,
    val closeHeadlineView: TextView?,
    val bodyView: TextView?,
    val advertiserView: TextView?,
    val adChoicesView: AdChoicesView?,
    val demoImageView: ImageView?,
    val backgroundImageView: ImageView?,
    val closeButtonView: View?,
    val countdownTextView: TextView?,
    val clsProgressView: ProgressBar?,
    val navProgressView: ProgressBar?,
    val prgsProgressView: ProgressBar?,
    val loopProgressView: ProgressBar?,
    val loopLoadingProgressView: ProgressBar?,
    val openStoreButtonView: View?,
)
