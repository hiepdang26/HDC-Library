package com.hdc.adsmultiplatform.fullscreen

import com.hdc.adsmultiplatform.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.NativeAdState

data class FullscreenNativeAdConfig(
    val ids: List<String>,
    val preloadBufferSize: Int = 1,
    val enableReloadAfterShow: Boolean = true,
)

enum class FullscreenNativeAdMode {
    SINGLE,
    TRANSPARENT,
    CTR,
    MULTIPLE,
    SEQUENCE,
    OVERLAY,
    OVERLAY_TRANSPARENT,
    OVERLAY_CTR,
    OVERLAY_CLS,
    OVERLAY_NAV,
    OVERLAY_PGRS,
    OVERLAY_PGRS_CLS,
    LOOP,
    ;

    val keepsDuplicateLayouts: Boolean
        get() = this == MULTIPLE || this == SEQUENCE

    val isProgressOverlay: Boolean
        get() = this == OVERLAY_PGRS || this == OVERLAY_PGRS_CLS

    val alwaysPausesGameplay: Boolean
        get() = when (this) {
            OVERLAY,
            OVERLAY_TRANSPARENT,
            OVERLAY_CLS,
            OVERLAY_NAV,
            OVERLAY_PGRS,
            OVERLAY_PGRS_CLS,
            LOOP,
            -> true

            else -> false
        }

    companion object {
        fun fromName(value: String?): FullscreenNativeAdMode {
            val normalized = value?.trim()?.uppercase().orEmpty()
            val alias = when (normalized) {
                "CLS" -> "OVERLAY_CLS"
                "NAV" -> "OVERLAY_NAV"
                "OVERLAY_PRGS" -> "OVERLAY_PGRS"
                "OVERLAY_PRGS_CLS" -> "OVERLAY_PGRS_CLS"
                else -> normalized
            }
            return entries.firstOrNull { it.name == alias } ?: SINGLE
        }
    }
}

internal fun FullscreenNativeAdMode.withLayoutInferredOverlay(layoutNames: List<String>): FullscreenNativeAdMode {
    if (keepsDuplicateLayouts) {
        return this
    }

    val normalized = layoutNames.map { FullscreenLayoutCatalog.normalize(it) }
    return when {
        normalized.any { it in FullscreenLayoutCatalog.AarLoopLayouts } ->
            FullscreenNativeAdMode.LOOP
        normalized.any { it in FullscreenLayoutCatalog.AarProgressClsLayouts } ->
            FullscreenNativeAdMode.OVERLAY_PGRS_CLS
        normalized.any { it in FullscreenLayoutCatalog.AarProgressLayouts } ->
            FullscreenNativeAdMode.OVERLAY_PGRS
        normalized.any { it in FullscreenLayoutCatalog.AarClsLayouts } ->
            FullscreenNativeAdMode.OVERLAY_CLS
        normalized.any { it in FullscreenLayoutCatalog.AarNavLayouts } ->
            FullscreenNativeAdMode.OVERLAY_NAV
        else -> this
    }
}

data class NativeClickAssetOptions(
    val cta: Boolean = true,
    val headline: Boolean = true,
    val body: Boolean = true,
    val description: Boolean = true,
    val icon: Boolean = true,
    val advertiser: Boolean = true,
    val media: Boolean = true,
    val mediaImage: Boolean = true,
    val mediaVideo: Boolean = true,
) {
    val bodyOrDescriptionClickEnabled: Boolean
        get() = body || description

    val mediaImageClickEnabled: Boolean
        get() = media && mediaImage

    val mediaVideoClickEnabled: Boolean
        get() = media && mediaVideo

    val anyMediaClickEnabled: Boolean
        get() = mediaImageClickEnabled || mediaVideoClickEnabled
}

data class NativeAssetVisibilityOptions(
    val cta: Boolean = true,
    val headline: Boolean = true,
    val body: Boolean = true,
    val description: Boolean = true,
    val icon: Boolean = true,
    val advertiser: Boolean = true,
    val media: Boolean = true,
    val mediaImage: Boolean = true,
    val mediaVideo: Boolean = true,
    val price: Boolean = true,
    val store: Boolean = true,
    val starRating: Boolean = true,
) {
    val bodyOrDescriptionVisible: Boolean
        get() = body || description

    val mediaImageVisible: Boolean
        get() = media && mediaImage

    val mediaVideoVisible: Boolean
        get() = media && mediaVideo

    val anyMediaVisible: Boolean
        get() = mediaImageVisible || mediaVideoVisible
}

data class FullscreenNativeAdShowOptions(
    val layoutName: String = FullscreenLayoutCatalog.SingleDefault,
    val durationSeconds: Double = 5.0,
    val autoClose: Boolean = false,
    val pauseGameplay: Boolean = true,
    val mode: FullscreenNativeAdMode = FullscreenNativeAdMode.SINGLE,
    val layoutNames: List<String> = emptyList(),
    val durationsSeconds: List<Double> = emptyList(),
    val orientation: String = "auto",
    val enableAdComeback: Boolean = true,
    val showTCD: Boolean = true,
    val delaySeconds: Double = 0.0,
    val timeUpCSeconds: Int = 0,
    val clickAssets: NativeClickAssetOptions = NativeClickAssetOptions(),
    val assetVisibility: NativeAssetVisibilityOptions = NativeAssetVisibilityOptions(),
) {
    val normalizedLayoutNames: List<String> =
        normalizeLayoutNames(
            candidates = layoutNames.ifEmpty { listOf(layoutName) },
            keepDuplicates = mode.keepsDuplicateLayouts,
        )

    val normalizedLayoutName: String = normalizedLayoutNames.firstOrNull() ?: FullscreenLayoutCatalog.SingleDefault

    val normalizedDurationsSeconds: List<Double> =
        durationsSeconds.filter { it > 0.0 }

    val resolvedDurationSeconds: Double =
        when {
            mode == FullscreenNativeAdMode.SEQUENCE && normalizedDurationsSeconds.isNotEmpty() ->
                normalizedDurationsSeconds.first()
            durationSeconds > 0.0 -> durationSeconds
            normalizedDurationsSeconds.isNotEmpty() -> normalizedDurationsSeconds.first()
            else -> 0.0
        }

    companion object {
        private fun normalizeLayoutNames(candidates: List<String>, keepDuplicates: Boolean): List<String> {
            val normalized = candidates
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .map { FullscreenLayoutCatalog.normalize(it) }

            return if (keepDuplicates) normalized else normalized.distinct()
        }
    }
}

/**
 * The options a host actually shows: the mode inferred from the layout names, single and transparent
 * shows that don't pause gameplay moved to their overlay variants, and gameplay paused for overlays.
 */
internal fun FullscreenNativeAdShowOptions.toEffectiveShowOptions(): FullscreenNativeAdShowOptions {
    val inferredMode = mode.withLayoutInferredOverlay(normalizedLayoutNames)
    val routedMode = when (inferredMode) {
        FullscreenNativeAdMode.SINGLE ->
            if (pauseGameplay) FullscreenNativeAdMode.SINGLE else FullscreenNativeAdMode.OVERLAY
        FullscreenNativeAdMode.TRANSPARENT ->
            if (pauseGameplay) FullscreenNativeAdMode.TRANSPARENT else FullscreenNativeAdMode.OVERLAY_TRANSPARENT
        FullscreenNativeAdMode.CTR -> FullscreenNativeAdMode.SINGLE
        FullscreenNativeAdMode.OVERLAY_CTR -> FullscreenNativeAdMode.OVERLAY
        else -> inferredMode
    }
    return copy(
        mode = routedMode,
        pauseGameplay = if (routedMode.alwaysPausesGameplay) true else pauseGameplay,
    )
}

data class FullscreenNativeAdInfo(
    val alias: String,
    val adUnitId: String,
    val layoutName: String = "",
)

data class FullscreenNativeAdError(
    val alias: String,
    val adUnitId: String,
    val code: Int = -1,
    val message: String,
)

interface FullscreenNativeAdCallback {
    fun onLoaded(ad: FullscreenNativeAdInfo) = Unit
    fun onDisplayable(alias: String) = Unit
    fun onDisplayed(ad: FullscreenNativeAdInfo) = Unit
    fun onOpened(ad: FullscreenNativeAdInfo) = Unit
    fun onClosed(ad: FullscreenNativeAdInfo) = Unit
    fun onClicked(ad: FullscreenNativeAdInfo) = Unit
    fun onFailedToLoad(error: FullscreenNativeAdError) = Unit
}

object FullscreenNativeAdRegistry {
    private val entries = mutableMapOf<String, FullscreenNativeAdEntry>()
    private val callbacks = mutableMapOf<String, FullscreenNativeAdCallback>()

    fun create(
        alias: String = DefaultNativeAdInstanceId,
        config: FullscreenNativeAdConfig,
    ) {
        entries[alias] = FullscreenNativeAdEntry(config = config)
    }

    fun setCallback(alias: String, callback: FullscreenNativeAdCallback?) {
        if (callback == null) {
            callbacks.remove(alias)
        } else {
            callbacks[alias] = callback
        }
    }

    fun configFor(alias: String, fallbackAdUnitId: String): FullscreenNativeAdConfig {
        val existing = entries[alias]?.config
        if (existing != null) {
            return existing.normalized(fallbackAdUnitId)
        }
        val config = FullscreenNativeAdConfig(ids = listOf(fallbackAdUnitId)).normalized(fallbackAdUnitId)
        entries[alias] = FullscreenNativeAdEntry(config = config)
        return config
    }

    fun stateFor(alias: String): NativeAdState =
        entries[alias]?.state ?: NativeAdState.Idle

    fun isReady(alias: String): Boolean =
        entries[alias]?.state == NativeAdState.Loaded

    /**
     * Takes the loaded ad out of the ready state as soon as its screen is built, so a second show
     * cannot reuse it. [notifyDisplayed] still runs once the ad is actually on screen.
     */
    fun markShowing(alias: String) {
        entry(alias).state = NativeAdState.Shown
    }

    fun loadedAdUnitId(alias: String): String? =
        entries[alias]?.loadedAdUnitId

    fun markLoading(alias: String) {
        entry(alias).state = NativeAdState.Loading
    }

    fun notifyState(
        alias: String,
        state: NativeAdState,
        adUnitId: String?,
        errorMessage: String? = null,
        errorCode: Int = -1,
    ) {
        when (state) {
            NativeAdState.Loading -> markLoading(alias)
            NativeAdState.Loaded -> notifyLoaded(alias, adUnitId.orEmpty())
            NativeAdState.Failed ->
                notifyFailed(alias, adUnitId.orEmpty(), errorMessage ?: "Native ad failed to load", errorCode)
            NativeAdState.Shown -> notifyDisplayed(alias, adUnitId.orEmpty(), "")
            NativeAdState.onClosed -> notifyClosed(alias)
            NativeAdState.Idle -> entry(alias).state = NativeAdState.Idle
        }
    }

    fun notifyLoaded(alias: String, adUnitId: String) {
        val entry = entry(alias)
        entry.state = NativeAdState.Loaded
        entry.loadedAdUnitId = adUnitId
        val info = FullscreenNativeAdInfo(alias = alias, adUnitId = adUnitId)
        callbacks[alias]?.onLoaded(info)
        callbacks[alias]?.onDisplayable(alias)
    }

    fun notifyFailed(alias: String, adUnitId: String, message: String, code: Int = -1) {
        val entry = entry(alias)
        entry.state = NativeAdState.Failed
        callbacks[alias]?.onFailedToLoad(
            FullscreenNativeAdError(
                alias = alias,
                adUnitId = adUnitId,
                code = code,
                message = message,
            ),
        )
    }

    fun notifyDisplayed(
        alias: String,
        adUnitId: String,
        layoutName: String,
    ) {
        val entry = entry(alias)
        entry.state = NativeAdState.Shown
        val resolvedAdUnitId = adUnitId.ifBlank { entry.loadedAdUnitId.orEmpty() }
        val normalizedLayoutName = FullscreenLayoutCatalog.normalize(layoutName)
        entry.displayedLayoutName = normalizedLayoutName
        val info = FullscreenNativeAdInfo(
            alias = alias,
            adUnitId = resolvedAdUnitId,
            layoutName = normalizedLayoutName,
        )
        callbacks[alias]?.onDisplayed(info)
        callbacks[alias]?.onOpened(info)
    }

    fun notifyClicked(alias: String) {
        val entry = entry(alias)
        callbacks[alias]?.onClicked(
            FullscreenNativeAdInfo(
                alias = alias,
                adUnitId = entry.loadedAdUnitId.orEmpty(),
                layoutName = entry.displayedLayoutName,
            ),
        )
    }

    fun notifyClosed(alias: String) {
        val entry = entry(alias)
        entry.state = NativeAdState.onClosed
        callbacks[alias]?.onClosed(
            FullscreenNativeAdInfo(
                alias = alias,
                adUnitId = entry.loadedAdUnitId.orEmpty(),
            ),
        )
    }

    fun shouldReloadAfterShow(alias: String): Boolean =
        entries[alias]?.config?.enableReloadAfterShow == true

    fun destroy(alias: String) {
        entries.remove(alias)
        callbacks.remove(alias)
    }

    private fun entry(alias: String): FullscreenNativeAdEntry =
        entries.getOrPut(alias) { FullscreenNativeAdEntry(FullscreenNativeAdConfig(ids = emptyList())) }

    private fun FullscreenNativeAdConfig.normalized(fallbackAdUnitId: String): FullscreenNativeAdConfig {
        val normalizedIds = ids.map { it.trim() }.filter { it.isNotEmpty() }
        return copy(
            ids = normalizedIds.ifEmpty { listOf(fallbackAdUnitId) },
            preloadBufferSize = preloadBufferSize.coerceAtLeast(1),
        )
    }
}

private data class FullscreenNativeAdEntry(
    val config: FullscreenNativeAdConfig,
    var state: NativeAdState = NativeAdState.Idle,
    var loadedAdUnitId: String? = null,
    var displayedLayoutName: String = "",
)
