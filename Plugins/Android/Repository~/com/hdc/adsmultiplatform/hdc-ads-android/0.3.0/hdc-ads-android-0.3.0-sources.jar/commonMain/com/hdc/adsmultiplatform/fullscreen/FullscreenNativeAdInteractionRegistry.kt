package com.hdc.adsmultiplatform.fullscreen

internal object FullscreenNativeAdInteractionRegistry {
    private val interactedInstances = mutableSetOf<String>()

    fun markInteraction(instanceId: String) {
        interactedInstances += instanceId
    }

    fun consumeInteraction(instanceId: String): Boolean =
        interactedInstances.remove(instanceId)

    fun clear(instanceId: String) {
        interactedInstances -= instanceId
    }
}
