package com.hdc.adsmultiplatform.fullscreen

internal class FullscreenNativeAdReloadPolicy {
    private var failureExponent = MinFailureExponent

    fun nextFailureRetryDelayMillis(): Long {
        val exponent = failureExponent.coerceAtMost(MaxFailureExponent)
        failureExponent = (failureExponent + 1).coerceAtMost(MaxFailureExponent)
        return (1L shl exponent) * 1_000L
    }

    fun resetAfterLoaded() {
        failureExponent = MinFailureExponent
    }

    companion object {
        private const val MinFailureExponent = 2
        private const val MaxFailureExponent = 6
    }
}
