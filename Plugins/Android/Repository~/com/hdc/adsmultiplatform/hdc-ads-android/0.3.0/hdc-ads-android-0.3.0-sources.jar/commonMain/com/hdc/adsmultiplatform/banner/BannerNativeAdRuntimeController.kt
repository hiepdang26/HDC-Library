package com.hdc.adsmultiplatform.banner

import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.defaultNativeAdUnitId

internal data class BannerNativeAdRuntimeSnapshot(
    val state: NativeAdState = NativeAdState.Idle,
    val isVisible: Boolean = false,
    val activeInstanceId: String? = null,
    val activeAdUnitId: String? = null,
    val activeLayoutName: String = BannerNativeAdLayoutCatalog.Default,
    val isExpanded: Boolean = false,
    val expandedCloseClickEnabled: Boolean = false,
    val canCollapseExpanded: Boolean = true,
    val collapseCountdownSecondsRemaining: Int = 0,
    val collapseCountdownProgress: Float = 0f,
    val canCloseCollapsed: Boolean = false,
    val loadingAdUnitIds: Set<String> = emptySet(),
    val readyAdUnitIds: Set<String> = emptySet(),
)

internal interface BannerNativeAdRuntimeLoader {
    fun load(
        instanceId: String,
        adUnitId: String,
        callback: (NativeAdLoadResult) -> Unit,
    )

    fun destroy(instanceId: String)
}

internal fun interface BannerNativeAdRuntimeScheduler {
    fun schedule(delayMillis: Long, block: () -> Unit): BannerNativeAdRuntimeCancellation
}

internal fun interface BannerNativeAdRuntimeCancellation {
    fun cancel()
}

internal class BannerNativeAdRuntimeController(
    private val alias: String,
    private val loader: BannerNativeAdRuntimeLoader,
    private val scheduler: BannerNativeAdRuntimeScheduler,
    private val callback: BannerNativeAdCallback = object : BannerNativeAdCallback {},
    private val onSnapshotChanged: (BannerNativeAdRuntimeSnapshot) -> Unit = {},
) {
    private var config = BannerNativeAdConfig(ids = listOf(defaultNativeAdUnitId()))
    private var snapshot = BannerNativeAdRuntimeSnapshot()
    private var pendingShowOnLoadSuccess = false
    private var loadTurn = 0
    private var nextAdUnitIndex = 0
    private var currentLayoutIndex = 0
    private var failureBackoff = BannerNativeAdFailureBackoffPolicy()
    private var reloadTimer: BannerNativeAdRuntimeCancellation? = null
    private var failureTimer: BannerNativeAdRuntimeCancellation? = null
    private var closeCountdownTimer: BannerNativeAdRuntimeCancellation? = null
    private var collapsedCountdownTimer: BannerNativeAdRuntimeCancellation? = null
    private val loadingByInstanceId = mutableMapOf<String, String>()
    private val readyQueue = mutableListOf<LoadedBannerTurn>()
    private val failedAdUnitIds = mutableSetOf<String>()
    private val retiredInstanceIds = mutableSetOf<String>()

    fun configure(nextConfig: BannerNativeAdConfig) {
        val normalized = nextConfig.normalized()
        if (normalized == config) {
            return
        }
        cancelTimers()
        readyQueue.forEach { destroyInstance(it.instanceId) }
        snapshot.activeInstanceId?.let(::destroyInstance)
        loadingByInstanceId.clear()
        readyQueue.clear()
        failedAdUnitIds.clear()
        pendingShowOnLoadSuccess = false
        nextAdUnitIndex = 0
        currentLayoutIndex = 0
        failureBackoff.resetAfterLoaded()
        config = normalized
        publish(
            BannerNativeAdRuntimeSnapshot(
                state = NativeAdState.Idle,
                activeLayoutName = config.layoutNames.first(),
            ),
        )
    }

    fun load() {
        pendingShowOnLoadSuccess = false
        requestLoadForNextTurn(reason = "manual")
    }

    fun show() {
        if (!snapshot.isVisible && snapshot.activeInstanceId != null && snapshot.activeAdUnitId != null) {
            pendingShowOnLoadSuccess = true
            cancelCloseCountdownTimer()
            publish(
                snapshot.copy(
                    state = NativeAdState.Shown,
                    isVisible = true,
                    isExpanded = false,
                    expandedCloseClickEnabled = false,
                    canCollapseExpanded = true,
                    collapseCountdownSecondsRemaining = 0,
                    collapseCountdownProgress = 0f,
                    canCloseCollapsed = false,
                ),
            )
            callback.onDisplayed(currentInfo())
            callback.onOpened(currentInfo())
            scheduleNextReload()
            restartCollapsedCountdown()
            return
        }
        pendingShowOnLoadSuccess = true
        val ready = readyQueue.firstOrNull()
        if (ready != null) {
            showLoaded(ready, scheduleReloadTimer = true)
            return
        }
        requestLoadForNextTurn(reason = "show")
    }

    fun expand(enableClick: Boolean = false): Boolean {
        if (!snapshot.isVisible || snapshot.activeInstanceId == null || snapshot.activeAdUnitId == null || snapshot.isExpanded) {
            return false
        }
        cancelCollapsedCountdownTimer()
        val countdownMillis = config.timeCollapseSeconds.coerceAtLeast(0) * 1_000L
        val canCollapseImmediately = countdownMillis == 0L
        publish(
            snapshot.copy(
                isExpanded = true,
                expandedCloseClickEnabled = enableClick,
                canCollapseExpanded = canCollapseImmediately,
            ),
        )
        if (!canCollapseImmediately) {
            closeCountdownTimer = scheduler.schedule(countdownMillis) {
                closeCountdownTimer = null
                if (snapshot.isExpanded) {
                    publish(snapshot.copy(canCollapseExpanded = true))
                }
            }
        }
        return true
    }

    fun collapse() {
        if (!snapshot.isExpanded || !snapshot.canCollapseExpanded) {
            return
        }
        cancelCloseCountdownTimer()
        publish(
            snapshot.copy(
                isExpanded = false,
                expandedCloseClickEnabled = false,
                canCollapseExpanded = true,
                collapseCountdownSecondsRemaining = 0,
                collapseCountdownProgress = 0f,
                canCloseCollapsed = false,
            ),
        )
        scheduleNextReload()
        restartCollapsedCountdown()
    }

    fun hide() {
        cancelReloadTimer()
        cancelCloseCountdownTimer()
        cancelCollapsedCountdownTimer()
        pendingShowOnLoadSuccess = false
        val currentInfo = currentInfo()
        publish(
            snapshot.copy(
                state = NativeAdState.onClosed,
                isVisible = false,
                isExpanded = false,
                expandedCloseClickEnabled = false,
                canCollapseExpanded = true,
                collapseCountdownSecondsRemaining = 0,
                collapseCountdownProgress = 0f,
                canCloseCollapsed = false,
            ),
        )
        callback.onClosed(currentInfo)
    }

    fun destroy() {
        cancelTimers()
        cancelCloseCountdownTimer()
        readyQueue.forEach { destroyInstance(it.instanceId) }
        readyQueue.clear()
        snapshot.activeInstanceId?.let(::destroyInstance)
        loadingByInstanceId.keys.toList().forEach(::destroyInstance)
        loadingByInstanceId.clear()
        failedAdUnitIds.clear()
        pendingShowOnLoadSuccess = false
        publish(BannerNativeAdRuntimeSnapshot())
    }

    private fun requestLoadForNextTurn(reason: String) {
        failureTimer?.cancel()
        failureTimer = null
        val adUnitId = nextLoadCandidate()
        if (adUnitId == null) {
            scheduleFailureBackoff(reason)
            return
        }
        failedAdUnitIds.remove(adUnitId)
        val instanceId = nextInstanceId(adUnitId)
        loadingByInstanceId[instanceId] = adUnitId
        publish(
            snapshot.copy(
                state = NativeAdState.Loading,
                loadingAdUnitIds = loadingByInstanceId.values.toSet(),
            ),
        )
        loader.load(instanceId, adUnitId) { result ->
            handleLoadResult(instanceId, adUnitId, result)
        }
    }

    private fun handleLoadResult(
        instanceId: String,
        adUnitId: String,
        result: NativeAdLoadResult,
    ) {
        if (loadingByInstanceId[instanceId] != adUnitId) {
            return
        }
        when (result.state) {
            NativeAdState.Loading -> publish(
                snapshot.copy(
                    state = NativeAdState.Loading,
                    loadingAdUnitIds = loadingByInstanceId.values.toSet(),
                ),
            )
            NativeAdState.Loaded -> {
                loadingByInstanceId.remove(instanceId)
                val loadedAdUnitId = result.adUnitId.ifBlank { adUnitId }
                failedAdUnitIds.remove(loadedAdUnitId)
                failureBackoff.resetAfterLoaded()
                val loaded = LoadedBannerTurn(instanceId = instanceId, adUnitId = loadedAdUnitId)
                readyQueue += loaded
                callback.onLoaded(loaded.info(layoutName = ""))
                callback.onDisplayable(alias)
                publish(
                    snapshot.copy(
                        state = NativeAdState.Loaded,
                        loadingAdUnitIds = loadingByInstanceId.values.toSet(),
                        readyAdUnitIds = readyQueue.map { it.adUnitId }.toSet(),
                    ),
                )
                if (pendingShowOnLoadSuccess) {
                    showLoaded(loaded, scheduleReloadTimer = true)
                }
            }
            NativeAdState.Failed -> {
                loadingByInstanceId.remove(instanceId)
                val failedAdUnitId = result.adUnitId.ifBlank { adUnitId }
                failedAdUnitIds += failedAdUnitId
                destroyInstance(instanceId)
                callback.onFailedToLoad(
                    BannerNativeAdError(
                        alias = alias,
                        adUnitId = failedAdUnitId,
                        code = result.code,
                        message = result.message.ifBlank { "Banner native ad failed to load" },
                    ),
                )
                publish(
                    snapshot.copy(
                        state = NativeAdState.Failed,
                        loadingAdUnitIds = loadingByInstanceId.values.toSet(),
                    ),
                )
                requestLoadForNextTurn(reason = "load_failed")
            }
            else -> Unit
        }
    }

    private fun showLoaded(
        loaded: LoadedBannerTurn,
        scheduleReloadTimer: Boolean,
    ) {
        readyQueue.removeAll { it.instanceId == loaded.instanceId }
        val previousInstanceId = snapshot.activeInstanceId
        val wasExpanded = snapshot.isExpanded
        val previousExpandedCloseClickEnabled = snapshot.expandedCloseClickEnabled
        val previousCanCollapseExpanded = snapshot.canCollapseExpanded
        val layoutName = nextLayoutName()
        val nextSnapshot = snapshot.copy(
            state = NativeAdState.Shown,
            isVisible = true,
            isExpanded = wasExpanded,
            expandedCloseClickEnabled = if (wasExpanded) previousExpandedCloseClickEnabled else false,
            canCollapseExpanded = if (wasExpanded) previousCanCollapseExpanded else true,
            collapseCountdownSecondsRemaining = 0,
            collapseCountdownProgress = 0f,
            canCloseCollapsed = false,
            activeInstanceId = loaded.instanceId,
            activeAdUnitId = loaded.adUnitId,
            activeLayoutName = layoutName,
            readyAdUnitIds = readyQueue.map { it.adUnitId }.toSet(),
        )
        publish(nextSnapshot)
        callback.onDisplayed(loaded.info(layoutName))
        callback.onOpened(loaded.info(layoutName))
        if (previousInstanceId != null && previousInstanceId != loaded.instanceId) {
            destroyInstance(previousInstanceId)
        }
        if (scheduleReloadTimer) {
            scheduleNextReload()
        }
        if (!wasExpanded) {
            restartCollapsedCountdown()
        }
    }

    private fun scheduleNextReload() {
        cancelReloadTimer()
        val seconds = config.timeReloadSeconds
        if (!snapshot.isVisible || !BannerNativeAdReloadPolicy.isEnabled(seconds)) {
            return
        }
        reloadTimer = scheduler.schedule(BannerNativeAdReloadPolicy.intervalMillis(seconds)) {
            reloadTimer = null
            if (snapshot.isVisible) {
                pendingShowOnLoadSuccess = true
                cancelCollapsedCountdownTimer()
                requestLoadForNextTurn(reason = "timeReload")
            }
        }
    }

    private fun restartCollapsedCountdown() {
        cancelCollapsedCountdownTimer()
        if (!snapshot.isVisible || snapshot.isExpanded || !BannerNativeAdLayoutCatalog.hasCollapseCountdown(snapshot.activeLayoutName)) {
            publish(
                snapshot.copy(
                    collapseCountdownSecondsRemaining = 0,
                    collapseCountdownProgress = 0f,
                    canCloseCollapsed = false,
                ),
            )
            return
        }

        val totalSeconds = config.timeCountdownSeconds.coerceAtLeast(0)
        if (totalSeconds == 0) {
            publish(
                snapshot.copy(
                    collapseCountdownSecondsRemaining = 0,
                    collapseCountdownProgress = 0f,
                    canCloseCollapsed = true,
                ),
            )
            return
        }

        publish(
            snapshot.copy(
                collapseCountdownSecondsRemaining = totalSeconds,
                collapseCountdownProgress = 1f,
                canCloseCollapsed = false,
            ),
        )
        scheduleCollapsedCountdownTick(totalSeconds)
    }

    private fun scheduleCollapsedCountdownTick(totalSeconds: Int) {
        collapsedCountdownTimer = scheduler.schedule(1_000L) {
            collapsedCountdownTimer = null
            if (!snapshot.isVisible || snapshot.isExpanded || !BannerNativeAdLayoutCatalog.hasCollapseCountdown(snapshot.activeLayoutName)) {
                return@schedule
            }

            val remaining = (snapshot.collapseCountdownSecondsRemaining - 1).coerceAtLeast(0)
            publish(
                snapshot.copy(
                    collapseCountdownSecondsRemaining = remaining,
                    collapseCountdownProgress = if (totalSeconds == 0) 0f else remaining.toFloat() / totalSeconds.toFloat(),
                    canCloseCollapsed = remaining == 0,
                ),
            )
            if (remaining > 0) {
                scheduleCollapsedCountdownTick(totalSeconds)
            }
        }
    }

    private fun scheduleFailureBackoff(reason: String) {
        if (failureTimer != null) {
            return
        }
        val delayMillis = failureBackoff.nextFailureRetryDelayMillis()
        failureTimer = scheduler.schedule(delayMillis) {
            failureTimer = null
            failedAdUnitIds.clear()
            requestLoadForNextTurn(reason = reason)
        }
    }

    private fun nextLoadCandidate(): String? {
        val ids = config.ids
        if (ids.isEmpty()) {
            return null
        }
        repeat(ids.size) {
            val index = (nextAdUnitIndex + it) % ids.size
            val candidate = ids[index]
            val isLoading = candidate in loadingByInstanceId.values
            val isFailed = candidate in failedAdUnitIds
            if (!isLoading && !isFailed) {
                nextAdUnitIndex = (index + 1) % ids.size
                return candidate
            }
        }
        return null
    }

    private fun nextLayoutName(): String {
        val layouts = config.layoutNames
        val layout = layouts[currentLayoutIndex % layouts.size]
        currentLayoutIndex = (currentLayoutIndex + 1) % layouts.size
        return layout
    }

    private fun nextInstanceId(adUnitId: String): String {
        loadTurn += 1
        return "$alias:banner:$loadTurn:${adUnitId.stableRuntimeKey()}"
    }

    private fun currentInfo(): BannerNativeAdInfo =
        BannerNativeAdInfo(
            alias = alias,
            instanceId = snapshot.activeInstanceId.orEmpty(),
            adUnitId = snapshot.activeAdUnitId.orEmpty(),
            layoutName = snapshot.activeLayoutName,
        )

    private fun LoadedBannerTurn.info(layoutName: String): BannerNativeAdInfo =
        BannerNativeAdInfo(
            alias = alias,
            instanceId = instanceId,
            adUnitId = adUnitId,
            layoutName = layoutName,
        )

    private fun publish(nextSnapshot: BannerNativeAdRuntimeSnapshot) {
        snapshot = nextSnapshot
        onSnapshotChanged(nextSnapshot)
    }

    private fun cancelTimers() {
        cancelReloadTimer()
        cancelCloseCountdownTimer()
        cancelCollapsedCountdownTimer()
        failureTimer?.cancel()
        failureTimer = null
    }

    private fun cancelReloadTimer() {
        reloadTimer?.cancel()
        reloadTimer = null
    }

    private fun cancelCloseCountdownTimer() {
        closeCountdownTimer?.cancel()
        closeCountdownTimer = null
    }

    private fun cancelCollapsedCountdownTimer() {
        collapsedCountdownTimer?.cancel()
        collapsedCountdownTimer = null
    }

    private fun destroyInstance(instanceId: String) {
        if (instanceId.isBlank() || !retiredInstanceIds.add(instanceId)) {
            return
        }
        loader.destroy(instanceId)
    }

    private fun BannerNativeAdConfig.normalized(): BannerNativeAdConfig {
        val normalizedIds = ids.map { it.trim() }.filter { it.isNotEmpty() }
        val normalizedLayouts = layoutNames
            .map { BannerNativeAdLayoutCatalog.normalize(it) }
            .distinct()
            .filter { it in BannerNativeAdLayoutCatalog.All }
        return copy(
            ids = normalizedIds.ifEmpty { listOf(defaultNativeAdUnitId()) },
            layoutNames = normalizedLayouts.ifEmpty { BannerNativeAdLayoutCatalog.All },
            timeReloadSeconds = timeReloadSeconds.coerceAtLeast(0),
            timeCountdownSeconds = timeCountdownSeconds.coerceAtLeast(0),
            timeCollapseSeconds = timeCollapseSeconds.coerceAtLeast(0),
        )
    }
}

private data class LoadedBannerTurn(
    val instanceId: String,
    val adUnitId: String,
)

private class BannerNativeAdFailureBackoffPolicy {
    private var failureExponent = MinFailureExponent

    fun nextFailureRetryDelayMillis(): Long {
        val exponent = failureExponent.coerceAtMost(MaxFailureExponent)
        failureExponent = (failureExponent + 1).coerceAtMost(MaxFailureExponent)
        return (1L shl exponent) * 1_000L
    }

    fun resetAfterLoaded() {
        failureExponent = MinFailureExponent
    }

    companion object {
        private const val MinFailureExponent = 2
        private const val MaxFailureExponent = 6
    }
}

private fun String.stableRuntimeKey(): String {
    var hash = 0
    forEach { char ->
        hash = 31 * hash + char.code
    }
    return hash.toString()
}
