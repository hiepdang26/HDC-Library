package com.hdc.adsmultiplatform.interstitial

import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState

const val DefaultInterstitialAdInstanceId = "interstitial"

data class InterstitialAdConfig(
    val ids: List<String> = emptyList(),
    val autoReload: Boolean = true,
    val preloadBufferSize: Int = 1,
)

data class InterstitialShowOptions(
    val immersiveMode: Boolean = true,
)

data class InterstitialAdInfo(
    val adUnitId: String,
    val mediationAdapter: String = "",
    val responseId: String = "",
    val adSource: String? = null,
)

data class InterstitialAdPaidInfo(
    val adUnitId: String,
    val revenueMicros: Long,
    val currencyCode: String,
    val mediationAdapter: String = "",
    val adSource: String? = null,
    val responseId: String = "",
    /** The SDK's precision type for the value (unknown, estimated, publisher provided, precise). */
    val precision: Int = 0,
)

interface InterstitialAdCallback {
    fun onInterstitialLoaded(ad: InterstitialAdInfo) = Unit
    fun onInterstitialDisplayed(ad: InterstitialAdInfo) = Unit
    fun onInterstitialOpened(ad: InterstitialAdInfo) = Unit
    fun onInterstitialImpression(ad: InterstitialAdInfo) = Unit
    fun onInterstitialClosed(ad: InterstitialAdInfo) = Unit
    fun onInterstitialClicked(ad: InterstitialAdInfo) = Unit
    fun onInterstitialFailedToLoad(adUnit: String, errorCode: Int, error: String) = Unit

    /** A show that failed. Defaults to [onInterstitialFailedToLoad], which used to receive show failures too. */
    fun onInterstitialFailedToShow(adUnit: String, errorCode: Int, error: String) =
        onInterstitialFailedToLoad(adUnit, errorCode, error)

    fun onInterstitialPaidImpression(ad: InterstitialAdInfo, paidInfo: InterstitialAdPaidInfo) = Unit
    fun onInterstitialDisplayable() = Unit
}

interface InterstitialAdLoader {
    fun configure(alias: String, config: InterstitialAdConfig)
    fun setCallback(alias: String, callback: InterstitialAdCallback?)
    fun load(
        alias: String,
        onResult: (NativeAdLoadResult) -> Unit,
    )

    fun load(
        alias: String,
        bufferSize: Int,
        onResult: (NativeAdLoadResult) -> Unit,
    )

    fun show(
        alias: String,
        options: InterstitialShowOptions = InterstitialShowOptions(),
    ): Boolean

    fun hide(alias: String) = Unit
    fun destroy(alias: String)
    fun isReady(alias: String): Boolean
}

expect fun defaultInterstitialAdUnitId(): String

object InterstitialAdRegistry {
    private val entries = mutableMapOf<String, InterstitialAdEntry>()
    private val callbacks = mutableMapOf<String, InterstitialAdCallback>()

    fun create(
        alias: String = DefaultInterstitialAdInstanceId,
        config: InterstitialAdConfig,
    ) {
        entries[alias.normalizedAlias()] = InterstitialAdEntry(
            config = config.normalized(defaultInterstitialAdUnitId()),
        )
    }

    fun setCallback(alias: String, callback: InterstitialAdCallback?) {
        val normalizedAlias = alias.normalizedAlias()
        if (callback == null) {
            callbacks.remove(normalizedAlias)
        } else {
            callbacks[normalizedAlias] = callback
        }
    }

    fun configFor(
        alias: String = DefaultInterstitialAdInstanceId,
        fallbackAdUnitId: String = defaultInterstitialAdUnitId(),
    ): InterstitialAdConfig {
        val normalizedAlias = alias.normalizedAlias()
        val existing = entries[normalizedAlias]?.config
        if (existing != null) {
            return existing.normalized(fallbackAdUnitId)
        }
        val config = InterstitialAdConfig(ids = listOf(fallbackAdUnitId)).normalized(fallbackAdUnitId)
        entries[normalizedAlias] = InterstitialAdEntry(config = config)
        return config
    }

    fun stateFor(alias: String = DefaultInterstitialAdInstanceId): NativeAdState =
        entries[alias.normalizedAlias()]?.state ?: NativeAdState.Idle

    fun isReady(alias: String = DefaultInterstitialAdInstanceId): Boolean =
        entries[alias.normalizedAlias()]?.state == NativeAdState.Loaded

    fun loadedAdUnitId(alias: String = DefaultInterstitialAdInstanceId): String? =
        entries[alias.normalizedAlias()]?.loadedAdUnitId

    fun notifyLoading(alias: String) {
        entry(alias).state = NativeAdState.Loading
    }

    fun notifyLoaded(alias: String, ad: InterstitialAdInfo) {
        val entry = entry(alias)
        entry.state = NativeAdState.Loaded
        entry.loadedAdUnitId = ad.adUnitId
        callbacks[alias.normalizedAlias()]?.onInterstitialLoaded(ad)
        callbacks[alias.normalizedAlias()]?.onInterstitialDisplayable()
    }

    fun notifyDisplayed(alias: String, ad: InterstitialAdInfo) {
        val entry = entry(alias)
        entry.state = NativeAdState.Shown
        entry.loadedAdUnitId = ad.adUnitId
        callbacks[alias.normalizedAlias()]?.onInterstitialDisplayed(ad)
    }

    fun notifyOpened(alias: String, ad: InterstitialAdInfo) {
        callbacks[alias.normalizedAlias()]?.onInterstitialOpened(ad)
    }

    fun notifyClosed(alias: String, ad: InterstitialAdInfo) {
        val entry = entry(alias)
        entry.state = NativeAdState.onClosed
        callbacks[alias.normalizedAlias()]?.onInterstitialClosed(ad)
    }

    fun notifyImpression(alias: String, ad: InterstitialAdInfo) {
        callbacks[alias.normalizedAlias()]?.onInterstitialImpression(ad)
    }

    fun notifyClicked(alias: String, ad: InterstitialAdInfo) {
        callbacks[alias.normalizedAlias()]?.onInterstitialClicked(ad)
    }

    fun notifyFailedToLoad(
        alias: String,
        adUnit: String,
        errorCode: Int,
        error: String,
    ) {
        entry(alias).state = NativeAdState.Failed
        callbacks[alias.normalizedAlias()]?.onInterstitialFailedToLoad(adUnit, errorCode, error)
    }

    fun notifyFailedToShow(
        alias: String,
        adUnit: String,
        errorCode: Int,
        error: String,
    ) {
        entry(alias).state = NativeAdState.Failed
        callbacks[alias.normalizedAlias()]?.onInterstitialFailedToShow(adUnit, errorCode, error)
    }

    fun notifyPaidImpression(
        alias: String,
        ad: InterstitialAdInfo,
        paidInfo: InterstitialAdPaidInfo,
    ) {
        callbacks[alias.normalizedAlias()]?.onInterstitialPaidImpression(ad, paidInfo)
    }

    fun destroy(alias: String = DefaultInterstitialAdInstanceId) {
        val normalizedAlias = alias.normalizedAlias()
        entries.remove(normalizedAlias)
        callbacks.remove(normalizedAlias)
    }

    private fun entry(alias: String): InterstitialAdEntry =
        entries.getOrPut(alias.normalizedAlias()) {
            InterstitialAdEntry(InterstitialAdConfig(ids = listOf(defaultInterstitialAdUnitId())))
        }
}

internal fun InterstitialAdConfig.normalized(fallbackAdUnitId: String = defaultInterstitialAdUnitId()): InterstitialAdConfig =
    copy(
        ids = ids.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(fallbackAdUnitId) },
        preloadBufferSize = preloadBufferSize.coerceAtLeast(1),
    )

private data class InterstitialAdEntry(
    val config: InterstitialAdConfig,
    var state: NativeAdState = NativeAdState.Idle,
    var loadedAdUnitId: String? = null,
)

private fun String.normalizedAlias(): String =
    ifBlank { DefaultInterstitialAdInstanceId }
