package com.hdc.adsmultiplatform.internal.preload

import com.hdc.adsmultiplatform.internal.core.NativeAdFormat
import com.hdc.adsmultiplatform.internal.core.NativeAdFormats

internal data class NativeAdPlacement(
    val format: NativeAdFormat,
    val instanceId: String,
)

/** Popup/banner runtimes load with `"<alias>:<format>:<turn>:<key>"`; the host only knows `<alias>`. */
internal fun NativeAdPlacement.hostAlias(): String {
    val marker = when (format) {
        NativeAdFormats.Popup -> ":popup:"
        NativeAdFormats.Banner -> ":banner:"
        else -> return instanceId
    }
    return if (instanceId.contains(marker)) instanceId.substringBefore(marker) else instanceId
}

internal class NativeAdUnitWaterfall private constructor(
    val ids: List<String>,
) {
    companion object {
        fun fromCsv(raw: String): NativeAdUnitWaterfall =
            fromList(raw.split(',', ';', '\n'))

        fun fromList(raw: List<String>): NativeAdUnitWaterfall =
            NativeAdUnitWaterfall(raw.map { it.trim() }.filter { it.isNotEmpty() })
    }

    fun withFallback(fallbackAdUnitId: String): NativeAdUnitWaterfall =
        if (ids.isEmpty()) {
            fromList(listOf(fallbackAdUnitId))
        } else {
            this
        }
}
