package com.hdc.adsmultiplatform.fullscreen

import com.hdc.adsmultiplatform.NativeAdLayoutNames

/** Layout and timing helpers shared by the Compose and the View overlays. */
internal fun normalizeOverlayLayoutNames(
    layoutName: String,
    layoutNames: List<String>,
    keepDuplicates: Boolean,
): List<String> {
    val candidates = layoutNames.ifEmpty { listOf(layoutName) }
    val normalized = candidates
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .map { NativeAdLayoutNames.normalize(it) }
    return if (keepDuplicates) normalized else normalized.distinct()
}

internal fun sequenceTotalDurationSeconds(layoutCount: Int, durationsSeconds: List<Double>): Double {
    if (durationsSeconds.isEmpty()) {
        return 0.0
    }

    return (0 until layoutCount).sumOf { index ->
        durationsSeconds.getOrElse(index) { durationsSeconds.last() }
    }
}
