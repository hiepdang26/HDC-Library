package com.hdc.adsmultiplatform.popup

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import com.google.android.gms.ads.nativead.AdChoicesView
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.internal.core.NativeAdFormats
import com.hdc.adsmultiplatform.internal.preload.android.AndroidNativeAdRepository
import com.hdc.adsmultiplatform.shared.R

internal class AndroidPopupNativeViewAdHost(context: Context) : FrameLayout(context) {
    private var currentLayoutName: String? = null
    private var binding: PopupNativeXmlBinding? = null
    private var boundAd: NativeAd? = null
    private var lastMissingAdInstanceId: String? = null

    init {
        setBackgroundColor(Color.TRANSPARENT)
    }

    fun render(
        instanceId: String,
        fallbackAdUnitId: String,
        layoutName: String,
        closeSecondsRemaining: Int,
        showClose: Boolean,
        enableCtrOverlay: Boolean,
        onStateChanged: (NativeAdState) -> Unit,
        onCloseClick: () -> Unit,
    ) {
        val ad = AndroidNativeAdRepository.loadedAd(NativeAdFormats.Popup, instanceId)
        if (ad == null) {
            if (fallbackAdUnitId.isBlank()) {
                clearLayout()
            }
            if (lastMissingAdInstanceId != instanceId) {
                lastMissingAdInstanceId = instanceId
                onStateChanged(NativeAdState.Failed)
            }
            return
        }

        lastMissingAdInstanceId = null
        val previousAd = boundAd
        val nextBinding = ensureLayout(PopupNativeAdLayoutCatalog.normalize(layoutName))
        if (previousAd !== ad || boundAd == null) {
            bindNativeAd(ad, nextBinding)
        }
        if (previousAd !== ad) {
            onStateChanged(NativeAdState.Loaded)
        }
        updateCloseControls(nextBinding, closeSecondsRemaining, showClose, onCloseClick)
    }

    fun release() {
        lastMissingAdInstanceId = null
        boundAd = null
        clearLayout()
    }

    private fun ensureLayout(layoutName: String): PopupNativeXmlBinding {
        binding?.takeIf { currentLayoutName == layoutName }?.let { return it }

        clearLayout()
        val adView = LayoutInflater.from(context)
            .inflate(layoutResId(layoutName), this, false) as NativeAdView
        val nextBinding = PopupNativeXmlBinding(
            adView = adView,
            mediaView = adView.findViewById(R.id.ad_media),
            iconView = adView.findViewById(R.id.ad_app_icon),
            callToActionView = adView.findViewById(R.id.ad_call_to_action),
            headlineView = adView.findViewById(R.id.ad_headline),
            bodyView = adView.findViewById(R.id.ad_description) ?: adView.findViewById(R.id.ad_body),
            advertiserView = adView.findViewById(R.id.ad_advertiser),
            adChoicesView = adView.findViewById(R.id.ad_choices_media),
            demoImageView = adView.findViewById(R.id.img_view_demo),
            closeButtonView = adView.findViewById(R.id.ad_close_button),
            closeTimerView = adView.findViewById(R.id.txt_time_count),
        )

        adView.headlineView = nextBinding.headlineView
        adView.bodyView = nextBinding.bodyView
        adView.iconView = nextBinding.iconView
        adView.callToActionView = nextBinding.callToActionView
        adView.advertiserView = nextBinding.advertiserView
        adView.mediaView = nextBinding.mediaView
        adView.adChoicesView = nextBinding.adChoicesView
        nextBinding.closeButtonView?.visibility = View.GONE
        nextBinding.closeTimerView?.visibility = View.GONE
        nextBinding.demoImageView?.visibility = View.GONE

        addView(adView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        currentLayoutName = layoutName
        binding = nextBinding
        return nextBinding
    }

    private fun bindNativeAd(ad: NativeAd, binding: PopupNativeXmlBinding) {
        boundAd = ad
        binding.headlineView?.text = ad.headline.orEmpty()
        binding.bodyView?.apply {
            val description = ad.body ?: ad.store ?: ad.price ?: ad.advertiser
            text = description.orEmpty()
            visibility = if (description.isNullOrBlank()) View.GONE else View.VISIBLE
        }
        binding.advertiserView?.apply {
            text = ad.advertiser.orEmpty()
            visibility = if (ad.advertiser.isNullOrBlank()) View.GONE else View.VISIBLE
        }
        binding.iconView?.apply {
            setImageDrawable(ad.icon?.drawable)
            visibility = if (ad.icon == null) View.GONE else View.VISIBLE
        }
        binding.callToActionView?.apply {
            text = ad.callToAction.orEmpty()
            visibility = if (ad.callToAction.isNullOrBlank()) View.GONE else View.VISIBLE
        }
        binding.demoImageView?.visibility = View.GONE
        binding.closeButtonView?.visibility = View.GONE
        binding.closeTimerView?.visibility = View.GONE
        binding.mediaView?.apply {
            mediaContent = ad.mediaContent
            visibility = if (ad.mediaContent == null) View.GONE else View.VISIBLE
            post {
                bringToFront()
                requestLayout()
                invalidate()
            }
        }

        binding.adView.post {
            if (boundAd === ad && this.binding === binding) {
                binding.adView.setNativeAd(ad)
            }
        }
    }

    // The countdown shows until the popup can be closed; then the close button replaces it.
    private fun updateCloseControls(
        binding: PopupNativeXmlBinding,
        closeSecondsRemaining: Int,
        showClose: Boolean,
        onCloseClick: () -> Unit,
    ) {
        val isCounting = !showClose && closeSecondsRemaining > 0
        binding.closeTimerView?.apply {
            visibility = if (isCounting) View.VISIBLE else View.GONE
            (this as? TextView)?.text = closeSecondsRemaining.toString()
        }
        binding.closeButtonView?.apply {
            visibility = if (showClose) View.VISIBLE else View.GONE
            setOnClickListener(if (showClose) View.OnClickListener { onCloseClick() } else null)
        }
    }

    private fun clearLayout() {
        binding?.adView?.destroy()
        boundAd = null
        binding = null
        currentLayoutName = null
        removeAllViews()
    }

    private fun layoutResId(layoutName: String): Int =
        when (layoutName) {
            PopupNativeAdLayoutCatalog.PopupSingleManual02 -> R.layout.popup_single_manual_02
            PopupNativeAdLayoutCatalog.PopupSingleManual03 -> R.layout.popup_single_manual_03
            PopupNativeAdLayoutCatalog.PopupSingleManual04 -> R.layout.popup_single_manual_04
            PopupNativeAdLayoutCatalog.PopupSingleManual05 -> R.layout.popup_single_manual_05
            PopupNativeAdLayoutCatalog.PopupSingleManual06 -> R.layout.popup_single_manual_06
            PopupNativeAdLayoutCatalog.PopupSingleManual07 -> R.layout.popup_single_manual_07
            PopupNativeAdLayoutCatalog.PopupSingleManual08 -> R.layout.popup_single_manual_08
            PopupNativeAdLayoutCatalog.PopupSingleManual09 -> R.layout.popup_single_manual_09
            PopupNativeAdLayoutCatalog.PopupSingleManual10 -> R.layout.popup_single_manual_10
            PopupNativeAdLayoutCatalog.PopupSingleManual11 -> R.layout.popup_single_manual_11
            PopupNativeAdLayoutCatalog.PopupSingleManual12 -> R.layout.popup_single_manual_12
            PopupNativeAdLayoutCatalog.PopupSingleManual13 -> R.layout.popup_single_manual_13
            PopupNativeAdLayoutCatalog.PopupSingleManual14 -> R.layout.popup_single_manual_14
            PopupNativeAdLayoutCatalog.PopupSingleManual15 -> R.layout.popup_single_manual_15
            else -> R.layout.popup_single_manual_01
        }
}

private data class PopupNativeXmlBinding(
    val adView: NativeAdView,
    val mediaView: MediaView?,
    val iconView: ImageView?,
    val callToActionView: TextView?,
    val headlineView: TextView?,
    val bodyView: TextView?,
    val advertiserView: TextView?,
    val adChoicesView: AdChoicesView?,
    val demoImageView: ImageView?,
    val closeButtonView: View?,
    val closeTimerView: View?,
)
