package com.hdc.adsmultiplatform

private const val AndroidTestNativeAdUnitId = "ca-app-pub-3940256099942544/2247696110"
private const val AndroidTestNativeVideoAdUnitId = "ca-app-pub-3940256099942544/1044960115"

actual fun defaultNativeAdUnitId(): String = AndroidTestNativeAdUnitId

actual fun defaultNativeVideoAdUnitId(): String = AndroidTestNativeVideoAdUnitId
