package com.hdc.adsmultiplatform.internal.core

internal data class NativeAdFormat(val key: String)

internal object NativeAdFormats {
    val Fullscreen = NativeAdFormat("fullscreen")
    val Banner = NativeAdFormat("banner")
    val Popup = NativeAdFormat("popup")
}

internal object NativeAdDurations {
    fun toMillis(durationSeconds: Double): Long =
        when {
            durationSeconds <= 0.0 -> 0L
            durationSeconds > 3_600.0 -> 3_600_000L
            else -> (durationSeconds * 1_000.0).toLong()
        }
}
