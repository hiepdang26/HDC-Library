package com.hdc.adsmultiplatform.unity

import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.banner.BannerNativeAdConfig
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.interstitial.InterstitialAdConfig
import com.hdc.adsmultiplatform.interstitial.InterstitialShowOptions
import com.hdc.adsmultiplatform.popup.PopupNativeAdConfig

/** Runs [block] on the main thread: right away when already on it, otherwise posted. */
internal expect fun hdcRunOnMain(block: () -> Unit)

/** Posts [block] to the main thread, to run after the current main loop work. */
internal expect fun hdcPostToMain(block: () -> Unit)

/** Runs [block] on the main thread and waits for its result, or returns [fallback] if it takes too long. */
internal expect fun <T> hdcQueryOnMain(fallback: T, block: () -> T): T

/** Starts the Google Mobile Ads SDK; [onComplete] runs on the main thread. */
internal expect fun hdcInitializeAds(onComplete: () -> Unit)

// Each host is called on the main thread only.

internal expect fun hdcInterstitialHost(): HdcInterstitialHost

internal expect fun hdcFullscreenHost(): HdcFullscreenHost

internal expect fun hdcPopupHost(): HdcPopupHost

internal expect fun hdcBannerHost(): HdcBannerHost

internal expect fun hdcMetaTestHost(): HdcMetaTestHost

internal interface HdcInterstitialHost {
    fun load(id: String, config: InterstitialAdConfig)

    fun show(id: String, options: InterstitialShowOptions): Boolean

    fun isReady(id: String): Boolean

    fun destroy(id: String)
}

/** Fullscreen native ads. Load, display and close are reported through FullscreenNativeAdRegistry. */
internal interface HdcFullscreenHost {
    fun load(id: String, adUnitIds: List<String>, reloadAfterShow: Boolean)

    /** Starts showing a loaded ad; false when it cannot be shown. */
    fun show(id: String, options: FullscreenNativeAdShowOptions): Boolean

    fun hide(id: String)

    fun destroy(id: String)
}

internal interface HdcPopupHost {
    fun load(id: String, config: PopupNativeAdConfig, onState: (NativeAdState) -> Unit)

    fun updatePlacement(id: String, xDp: Float, yDp: Float, widthDp: Float, heightDp: Float)

    fun show(id: String)

    fun close(id: String)

    fun hide(id: String)

    fun stop(id: String)

    fun destroy(id: String)

    fun isReady(id: String): Boolean

    fun isDisplayable(id: String): Boolean

    fun state(id: String): String
}

/** Meta Audience Network test mode: test devices get Meta test ads. */
internal interface HdcMetaTestHost {
    /** This device's Meta test device hash. */
    fun deviceHash(): String

    /**
     * Registers this device and [extraDeviceHashes] as test devices with the test creative [testAdType]
     * (0 is the default creative). Returns whether Meta accepted them.
     */
    fun enable(extraDeviceHashes: List<String>, testAdType: Int): Boolean

    fun disable()

    fun isEnabled(): Boolean
}

internal interface HdcBannerHost {
    fun load(id: String, config: BannerNativeAdConfig, onState: (NativeAdState) -> Unit)

    fun show(id: String)

    fun expand(id: String, enableClick: Boolean): Boolean

    fun collapse(id: String)

    fun hide(id: String)

    fun destroy(id: String)
}
