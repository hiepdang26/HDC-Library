package com.hdc.adsmultiplatform.internal.preload.android

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdapterResponseInfo
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdValue
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.NativeAd
import com.hdc.adsmultiplatform.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.defaultNativeAdUnitId
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdReloadPolicy
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdInteractionRegistry
import com.hdc.adsmultiplatform.internal.core.AdTrackingEvent
import com.hdc.adsmultiplatform.internal.core.AdTrackingEventNames
import com.hdc.adsmultiplatform.internal.core.AdTrackingEvents
import com.hdc.adsmultiplatform.internal.core.NativeAdFormat
import com.hdc.adsmultiplatform.internal.core.NativeAdFormats
import com.hdc.adsmultiplatform.internal.preload.NativeAdPlacement
import com.hdc.adsmultiplatform.internal.preload.NativeAdUnitWaterfall
import com.hdc.adsmultiplatform.internal.preload.hostAlias

private const val AndroidNativeAdLogTag = "AdsMultiplatform"

private data class AndroidNativeAdSlot(
    var nativeAd: NativeAd? = null,
    var loadedAdUnitId: String? = null,
    var requestVersion: Int = 0,
    val reloadPolicy: FullscreenNativeAdReloadPolicy = FullscreenNativeAdReloadPolicy(),
    var retryRunnable: Runnable? = null,
)

internal object AndroidNativeAdRepository {
    private val slots = mutableMapOf<NativeAdPlacement, AndroidNativeAdSlot>()
    private val handler = Handler(Looper.getMainLooper())

    fun load(context: Context, adUnitId: String, callback: (NativeAdState) -> Unit) {
        load(DefaultNativeAdInstanceId, context, listOf(adUnitId), callback)
    }

    fun loadWithResult(
        context: Context,
        adUnitId: String,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        loadWithResult(DefaultNativeAdInstanceId, context, listOf(adUnitId), callback)
    }

    fun load(
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdState) -> Unit,
    ) {
        loadWithResult(NativeAdFormats.Fullscreen, instanceId, context, adUnitIds) { result ->
            callback(result.state)
        }
    }

    fun loadWithResult(
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        loadWithResult(NativeAdFormats.Fullscreen, instanceId, context, adUnitIds, callback)
    }

    fun load(
        format: NativeAdFormat,
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdState) -> Unit,
    ) {
        loadWithResult(format, instanceId, context, adUnitIds) { result ->
            callback(result.state)
        }
    }

    fun loadWithResult(
        format: NativeAdFormat,
        instanceId: String,
        context: Context,
        adUnitIds: List<String>,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        val waterfall = NativeAdUnitWaterfall.fromList(adUnitIds).withFallback(defaultNativeAdUnitId())
        val placement = placement(format, instanceId)
        val slot = slots.getOrPut(placement) { AndroidNativeAdSlot() }
        val version = slot.requestVersion + 1
        slot.requestVersion = version
        slot.retryRunnable?.let(handler::removeCallbacks)
        slot.retryRunnable = null
        slot.reloadPolicy.resetAfterLoaded()
        slot.nativeAd?.destroy()
        slot.nativeAd = null
        slot.loadedAdUnitId = null
        callback(NativeAdLoadResult(state = NativeAdState.Loading, adUnitId = waterfall.ids.firstOrNull().orEmpty()))

        MobileAds.initialize(context.applicationContext)
        loadNext(context, placement, waterfall.ids, index = 0, version = version, callback = callback)
    }

    fun loadedAd(instanceId: String): NativeAd? =
        loadedAd(NativeAdFormats.Fullscreen, instanceId)

    fun loadedAd(format: NativeAdFormat, instanceId: String): NativeAd? =
        slots[placement(format, instanceId)]?.nativeAd

    fun loadedAdUnitId(instanceId: String): String? =
        loadedAdUnitId(NativeAdFormats.Fullscreen, instanceId)

    fun loadedAdUnitId(format: NativeAdFormat, instanceId: String): String? =
        slots[placement(format, instanceId)]?.loadedAdUnitId

    fun clearLoaded(instanceId: String) {
        clearLoaded(NativeAdFormats.Fullscreen, instanceId)
    }

    fun clearLoaded(format: NativeAdFormat, instanceId: String) {
        slots[placement(format, instanceId)]?.let { slot ->
            slot.nativeAd?.destroy()
            slot.nativeAd = null
            slot.loadedAdUnitId = null
        }
    }

    fun destroy(instanceId: String) {
        destroy(NativeAdFormats.Fullscreen, instanceId)
    }

    fun destroy(format: NativeAdFormat, instanceId: String) {
        slots.remove(placement(format, instanceId))?.let { slot ->
            slot.retryRunnable?.let(handler::removeCallbacks)
            slot.nativeAd?.destroy()
        }
    }

    private fun loadNext(
        context: Context,
        placement: NativeAdPlacement,
        adUnitIds: List<String>,
        index: Int,
        version: Int,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        val slot = slots[placement] ?: return
        val adUnitId = adUnitIds.getOrNull(index)
        if (adUnitId == null) {
            callback(
                NativeAdLoadResult(
                    state = NativeAdState.Failed,
                    code = NativeAdLoadResult.NoErrorCode,
                    message = "No native ad unit id available",
                ),
            )
            return
        }

        val tracking = AndroidNativeAdTracking(placement, adUnitId)
        AdLoader.Builder(context, adUnitId)
            .forNativeAd { ad ->
                if (version != slot.requestVersion) {
                    ad.destroy()
                    return@forNativeAd
                }
                tracking.attach(ad)
                slot.retryRunnable?.let(handler::removeCallbacks)
                slot.retryRunnable = null
                slot.reloadPolicy.resetAfterLoaded()
                slot.nativeAd = ad
                slot.loadedAdUnitId = adUnitId
                logLoadedNativeAd(placement, adUnitId, ad)
                callback(NativeAdLoadResult(state = NativeAdState.Loaded, adUnitId = adUnitId))
            }
            .withAdListener(
                object : AdListener() {
                    override fun onAdImpression() {
                        tracking.emit(AdTrackingEventNames.Impression)
                    }

                    override fun onAdClicked() {
                        logNativeAdClickEvent("clicked", placement, slot.nativeAd)
                        markFullscreenAdInteraction(placement)
                        tracking.emit(AdTrackingEventNames.Clicked)
                    }

                    override fun onAdOpened() {
                        logNativeAdClickEvent("opened", placement, slot.nativeAd)
                        markFullscreenAdInteraction(placement)
                    }

                    override fun onAdFailedToLoad(error: LoadAdError) {
                        if (version != slot.requestVersion) {
                            return
                        }
                        callback(
                            NativeAdLoadResult(
                                state = NativeAdState.Failed,
                                adUnitId = adUnitId,
                                code = error.code,
                                message = error.message,
                            ),
                        )
                        if (index + 1 < adUnitIds.size) {
                            callback(
                                NativeAdLoadResult(
                                    state = NativeAdState.Loading,
                                    adUnitId = adUnitIds.getOrNull(index + 1).orEmpty(),
                                ),
                            )
                            loadNext(context, placement, adUnitIds, index + 1, version, callback)
                        } else {
                            if (placement.format == NativeAdFormats.Fullscreen) {
                                scheduleRetry(context, placement, adUnitIds, version, callback)
                            }
                        }
                    }
                },
            )
            .build()
            .loadAd(AdRequest.Builder().build())
    }

    private fun scheduleRetry(
        context: Context,
        placement: NativeAdPlacement,
        adUnitIds: List<String>,
        version: Int,
        callback: (NativeAdLoadResult) -> Unit,
    ) {
        val slot = slots[placement] ?: return
        val delayMillis = slot.reloadPolicy.nextFailureRetryDelayMillis()
        val retry = Runnable {
            val activeSlot = slots[placement] ?: return@Runnable
            if (version != activeSlot.requestVersion) {
                return@Runnable
            }
            callback(NativeAdLoadResult(state = NativeAdState.Loading, adUnitId = adUnitIds.firstOrNull().orEmpty()))
            loadNext(context, placement, adUnitIds, index = 0, version = version, callback = callback)
        }
        slot.retryRunnable = retry
        handler.postDelayed(retry, delayMillis)
    }

    private fun placement(format: NativeAdFormat, instanceId: String): NativeAdPlacement =
        NativeAdPlacement(format, instanceId)

    private fun markFullscreenAdInteraction(placement: NativeAdPlacement) {
        if (placement.format == NativeAdFormats.Fullscreen) {
            FullscreenNativeAdInteractionRegistry.markInteraction(placement.instanceId)
        }
    }

    @Suppress("DEPRECATION")
    private fun logLoadedNativeAd(
        placement: NativeAdPlacement,
        adUnitId: String,
        ad: NativeAd,
    ) {
        runCatching {
            val media = ad.mediaContent
            val videoController = media?.videoController
            val responseInfo = ad.responseInfo
            Log.d(
                AndroidNativeAdLogTag,
                "Android native ad loaded detail basic: " +
                    "format=${placement.format} instance=${placement.instanceId} adUnitId=$adUnitId " +
                    "responseId=${responseInfo?.responseId.orNullLabel()} " +
                    "mediationAdapter=${responseInfo?.mediationAdapterClassName.orNullLabel()} " +
                    "headline=${ad.headline.debugValue()} cta=${ad.callToAction.debugValue()} " +
                    "body=${ad.body.debugValue()} advertiser=${ad.advertiser.debugValue()} " +
                    "store=${ad.store.debugValue()} price=${ad.price.debugValue()} starRating=${ad.starRating?.toString().orNullLabel()} " +
                    "icon=${ad.icon.debugImageValue()} images=${ad.images.debugImagesValue()} " +
                    "adChoices=${ad.adChoicesInfo?.text?.toString().debugValue()} " +
                    "adChoicesImages=${ad.adChoicesInfo?.images.debugImagesValue()}",
            )
            Log.d(
                AndroidNativeAdLogTag,
                "Android native ad loaded detail media: " +
                    "format=${placement.format} instance=${placement.instanceId} responseId=${responseInfo?.responseId.orNullLabel()} " +
                    "mediaHasVideo=${media?.hasVideoContent().orFalseLabel()} " +
                    "mediaAspectRatio=${media?.aspectRatio?.toString().orNullLabel()} " +
                    "mediaDuration=${media?.duration?.toString().orNullLabel()} " +
                    "mediaCurrentTime=${media?.currentTime?.toString().orNullLabel()} " +
                    "mediaMainImage=${(media?.mainImage != null)} " +
                    "videoMuted=${videoController?.isMuted?.toString().orNullLabel()} " +
                    "videoPlaybackState=${videoController?.playbackState?.toString().orNullLabel()} " +
                    "videoCustomControls=${videoController?.isCustomControlsEnabled?.toString().orNullLabel()} " +
                    "videoClickToExpand=${videoController?.isClickToExpandEnabled?.toString().orNullLabel()} " +
                    "customClickGesture=${ad.isCustomClickGestureEnabled} customMute=${ad.isCustomMuteThisAdEnabled}",
            )
            Log.d(
                AndroidNativeAdLogTag,
                "Android native ad loaded detail response: " +
                    "format=${placement.format} instance=${placement.instanceId} responseId=${responseInfo?.responseId.orNullLabel()} " +
                    "extras=${ad.extras.debugBundleValue()} " +
                    "responseExtras=${responseInfo?.responseExtras.debugBundleValue()} " +
                    "loadedAdapter=${responseInfo?.loadedAdapterResponseInfo.debugAdapterValue()}",
            )
            logLongAndroidNativeAdDetail(
                "Android native ad loaded responseInfo: " +
                    "format=${placement.format} instance=${placement.instanceId} responseId=${responseInfo?.responseId.orNullLabel()} ",
                responseInfo.debugObjectValue(maxLength = 6_000),
            )
            responseInfo?.adapterResponses.orEmpty().forEachIndexed { adapterIndex, adapter ->
                Log.d(
                    AndroidNativeAdLogTag,
                    "Android native ad loaded adapter[$adapterIndex]: " +
                        "format=${placement.format} instance=${placement.instanceId} " +
                        adapter.debugAdapterValue(),
                )
            }
        }.onFailure { error ->
            Log.w(
                AndroidNativeAdLogTag,
                "Android native ad loaded detail failed: format=${placement.format} " +
                    "instance=${placement.instanceId} adUnitId=$adUnitId error=${error.message}",
            )
        }
    }

    private fun logNativeAdClickEvent(
        event: String,
        placement: NativeAdPlacement,
        ad: NativeAd?,
    ) {
        val responseInfo = ad?.responseInfo
        Log.d(
            AndroidNativeAdLogTag,
            "Android native ad $event: format=${placement.format} instance=${placement.instanceId} " +
                "responseId=${responseInfo?.responseId.orNullLabel()} " +
                "loadedAdapter=${responseInfo?.loadedAdapterResponseInfo.debugAdapterValue()}",
        )
    }
}

/** Impression, click and paid events of the ad that one load request produced. */
private class AndroidNativeAdTracking(
    private val placement: NativeAdPlacement,
    private val adUnitId: String,
) {
    private var isLoaded = false
    private var responseId = ""
    private var mediationAdapter = ""
    private var adSourceName = ""

    fun attach(ad: NativeAd) {
        val response = ad.responseInfo
        responseId = response?.responseId.orEmpty()
        mediationAdapter = response?.mediationAdapterClassName.orEmpty()
        adSourceName = response?.loadedAdapterResponseInfo?.adSourceName.orEmpty()
        isLoaded = true
        ad.setOnPaidEventListener { value -> emit(AdTrackingEventNames.Paid, value) }
    }

    fun emit(name: String, value: AdValue? = null) {
        if (!isLoaded) {
            return
        }
        AdTrackingEvents.emit(
            AdTrackingEvent(
                instanceId = placement.hostAlias(),
                format = placement.format.key,
                name = name,
                adUnitId = adUnitId,
                valueMicros = value?.valueMicros ?: 0L,
                currencyCode = value?.currencyCode.orEmpty(),
                precision = value?.precisionType ?: 0,
                adSourceName = adSourceName,
                mediationAdapter = mediationAdapter,
                responseId = responseId,
            ),
        )
    }
}

private fun String?.debugValue(maxLength: Int = 180): String =
    orNullLabel()
        .replace("\n", "\\n")
        .let { if (it.length > maxLength) it.take(maxLength) + "..." else it }

private fun String?.orNullLabel(): String =
    this ?: "null"

private fun Boolean?.orFalseLabel(): String =
    this?.toString() ?: "null"

@Suppress("DEPRECATION")
private fun Bundle?.debugBundleValue(maxLength: Int = 700): String =
    if (this == null) {
        "null"
    } else {
        keySet()
            .sorted()
            .joinToString(prefix = "{", postfix = "}") { key -> "$key=${get(key)}" }
            .replace("\n", "\\n")
            .let { if (it.length > maxLength) it.take(maxLength) + "..." else it }
    }

private fun Any?.debugObjectValue(maxLength: Int = 900): String =
    if (this == null) {
        "null"
    } else {
        toString()
            .replace("\n", "\\n")
            .let { if (it.length > maxLength) it.take(maxLength) + "..." else it }
    }

private fun NativeAd.Image?.debugImageValue(): String =
    if (this == null) {
        "null"
    } else {
        "uri=${uri?.toString().orNullLabel()},scale=$scale," +
            "drawable=${drawable?.intrinsicWidth ?: 0}x${drawable?.intrinsicHeight ?: 0}"
    }

private fun List<NativeAd.Image>?.debugImagesValue(maxItems: Int = 4): String =
    if (this == null) {
        "null"
    } else {
        take(maxItems)
            .mapIndexed { index, image -> "$index(${image.debugImageValue()})" }
            .joinToString(prefix = "[size=$size ", postfix = "]")
    }

private fun AdapterResponseInfo?.debugAdapterValue(): String =
    if (this == null) {
        "null"
    } else {
        "adapterClass=${adapterClassName.orNullLabel()} " +
            "latencyMs=$latencyMillis " +
            "adSourceName=${adSourceName.orNullLabel()} " +
            "adSourceId=${adSourceId.orNullLabel()} " +
            "adSourceInstanceName=${adSourceInstanceName.orNullLabel()} " +
            "adSourceInstanceId=${adSourceInstanceId.orNullLabel()} " +
            "error=${adError?.toString().orNullLabel()} " +
            "credentials=${credentials.debugBundleValue()}"
    }

private fun logLongAndroidNativeAdDetail(prefix: String, value: String) {
    val chunkSize = 2_500
    value.chunked(chunkSize).forEachIndexed { index, chunk ->
        Log.d(AndroidNativeAdLogTag, "$prefix chunk=$index $chunk")
    }
}
