package com.hdc.adsmultiplatform.internal.unity.android

import android.app.Activity
import android.content.Context
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import com.hdc.adsmultiplatform.DefaultNativeAdInstanceId
import com.hdc.adsmultiplatform.NativeAdLayoutNames
import com.hdc.adsmultiplatform.NativeAdShowOptions
import com.hdc.adsmultiplatform.defaultNativeAdUnitId
import com.hdc.adsmultiplatform.fullscreen.AndroidFullscreenBackBlocker
import com.hdc.adsmultiplatform.fullscreen.AndroidFullscreenNativeOverlayView
import com.hdc.adsmultiplatform.fullscreen.AndroidFullscreenSystemUi
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdConfig
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdRegistry
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.fullscreen.toEffectiveShowOptions
import com.hdc.adsmultiplatform.internal.preload.android.AndroidNativeAdRepository
import com.hdc.adsmultiplatform.parseAdUnitIdsCsv

private const val UnityOverlayTagPrefix = "AdsMultiplatform.FullscreenNativeAdOverlay."

/**
 * Shows fullscreen native ads over an activity, typically Unity's: an overlay of plain Android views,
 * drawn from the XML layouts, added to the activity's content view, with the back button blocked, the
 * system bars hidden and, when asked, the Unity player paused. Load, display and close are reported
 * through FullscreenNativeAdRegistry.
 */
internal object NativeAdUnityBridge {

    fun loadFullscreen(
        activity: Activity,
        instanceId: String = DefaultNativeAdInstanceId,
        adUnitIdsCsv: String = defaultNativeAdUnitId(),
        enableReloadAfterShow: Boolean = true,
    ) {
        activity.runOnUiThread {
            hideNow(activity, instanceId, reloadAfterClose = false)
            val adUnitIds = parseAdUnitIdsCsv(adUnitIdsCsv).ifEmpty { listOf(defaultNativeAdUnitId()) }
            FullscreenNativeAdRegistry.create(
                alias = instanceId,
                config = FullscreenNativeAdConfig(
                    ids = adUnitIds,
                    enableReloadAfterShow = enableReloadAfterShow,
                ),
            )
            load(activity, instanceId, adUnitIds)
        }
    }

    fun showFullscreen(
        activity: Activity,
        instanceId: String = DefaultNativeAdInstanceId,
        options: FullscreenNativeAdShowOptions = FullscreenNativeAdShowOptions(),
        fallbackAdUnitId: String = defaultNativeAdUnitId(),
    ) {
        activity.runOnUiThread {
            hideNow(activity, instanceId, reloadAfterClose = false)
            showFullscreenNow(
                activity = activity,
                instanceId = instanceId,
                options = options,
                fallbackAdUnitId = fallbackAdUnitId,
            )
        }
    }

    fun hideFullscreen(activity: Activity, instanceId: String?) {
        activity.runOnUiThread {
            hideNow(activity, instanceId)
        }
    }

    fun destroyFullscreen(instanceId: String = DefaultNativeAdInstanceId) {
        UnityGameplayController.clearOwner(instanceId)
        AndroidNativeAdRepository.destroy(instanceId)
        FullscreenNativeAdRegistry.destroy(instanceId)
    }

    private fun load(context: Context, instanceId: String, adUnitIds: List<String>) {
        AndroidNativeAdRepository.loadWithResult(
            instanceId = instanceId,
            context = context,
            adUnitIds = adUnitIds,
            callback = { result ->
                FullscreenNativeAdRegistry.notifyState(
                    alias = instanceId,
                    state = result.state,
                    adUnitId = AndroidNativeAdRepository.loadedAdUnitId(instanceId) ?: result.adUnitId,
                    errorMessage = result.message.ifBlank { null },
                    errorCode = result.code,
                    adSourceId = result.adSourceId,
                    adSourceName = result.adSourceName,
                )
            },
        )
    }

    private fun showFullscreenNow(
        activity: Activity,
        instanceId: String,
        options: FullscreenNativeAdShowOptions,
        fallbackAdUnitId: String,
    ) {
        if (AndroidNativeAdRepository.loadedAd(instanceId) == null) {
            FullscreenNativeAdRegistry.notifyFailed(
                alias = instanceId,
                adUnitId = fallbackAdUnitId,
                message = "No loaded fullscreen native ad to show",
            )
            return
        }
        val effectiveOptions = options.toEffectiveShowOptions()
        val normalizedLayoutName = NativeAdLayoutNames.normalize(effectiveOptions.normalizedLayoutName)
        val loadedAdUnitId = AndroidNativeAdRepository.loadedAdUnitId(instanceId) ?: fallbackAdUnitId
        val overlayOptions = NativeAdShowOptions(
            instanceId = instanceId,
            layoutName = normalizedLayoutName,
            durationSeconds = effectiveOptions.resolvedDurationSeconds,
            autoClose = effectiveOptions.autoClose,
            orientation = effectiveOptions.orientation,
            pauseGameplay = effectiveOptions.pauseGameplay,
            enableAdComeback = effectiveOptions.enableAdComeback,
            showTCD = effectiveOptions.showTCD,
            delaySeconds = effectiveOptions.delaySeconds,
            timeUpCSeconds = effectiveOptions.timeUpCSeconds,
            mode = effectiveOptions.mode,
            layoutNames = effectiveOptions.normalizedLayoutNames,
            durationsSeconds = effectiveOptions.normalizedDurationsSeconds,
            clickAssets = effectiveOptions.clickAssets,
            assetVisibility = effectiveOptions.assetVisibility,
        )
        val tag = overlayTag(instanceId)
        FullscreenNativeAdRegistry.notifyDisplayed(
            alias = instanceId,
            adUnitId = loadedAdUnitId,
            layoutName = overlayOptions.layoutName,
        )
        AndroidFullscreenSystemUi.enter(activity)
        val view = AndroidFullscreenNativeOverlayView(
            activity = activity,
            options = overlayOptions,
            adUnitId = loadedAdUnitId,
            onClose = { hideFullscreen(activity, instanceId) },
        ).apply {
            this.tag = tag
            isFocusable = true
            isFocusableInTouchMode = true
            setOnKeyListener { _, keyCode, event ->
                keyCode == KeyEvent.KEYCODE_BACK && event.action == KeyEvent.ACTION_UP
            }
        }
        activity.addContentView(
            view,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ),
        )
        view.requestFocus()
        AndroidFullscreenBackBlocker.register(activity, tag)
        if (effectiveOptions.pauseGameplay) {
            UnityGameplayController.pause(activity, instanceId)
        }
    }

    private fun hideNow(
        activity: Activity,
        instanceId: String? = null,
        reloadAfterClose: Boolean = true,
    ) {
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        for (index in content.childCount - 1 downTo 0) {
            val child = content.getChildAt(index)
            val tag = child.tag as? String
            if (shouldRemoveOverlay(tag, instanceId)) {
                content.removeViewAt(index)
                AndroidFullscreenBackBlocker.unregister(activity, tag)
                val removedInstanceId = instanceIdFromOverlayTag(tag)
                if (removedInstanceId != null) {
                    UnityGameplayController.resume(activity, removedInstanceId)
                    val shouldReloadAfterShow =
                        reloadAfterClose && FullscreenNativeAdRegistry.shouldReloadAfterShow(removedInstanceId)
                    AndroidNativeAdRepository.clearLoaded(removedInstanceId)
                    FullscreenNativeAdRegistry.notifyClosed(removedInstanceId)
                    if (shouldReloadAfterShow) {
                        val config = FullscreenNativeAdRegistry.configFor(removedInstanceId, defaultNativeAdUnitId())
                        load(activity.applicationContext, removedInstanceId, config.ids)
                    }
                }
            }
        }
        if (!hasFullscreenNativeAdOverlay(content)) {
            AndroidFullscreenSystemUi.exit(activity)
        }
    }

    private fun overlayTag(instanceId: String): String =
        "$UnityOverlayTagPrefix$instanceId"

    private fun shouldRemoveOverlay(tag: String?, instanceId: String?): Boolean {
        if (tag?.startsWith(UnityOverlayTagPrefix) != true) {
            return false
        }
        return instanceId == null || tag == overlayTag(instanceId)
    }

    private fun hasFullscreenNativeAdOverlay(content: ViewGroup): Boolean {
        for (index in 0 until content.childCount) {
            val tag = content.getChildAt(index).tag as? String
            if (tag?.startsWith(UnityOverlayTagPrefix) == true) {
                return true
            }
        }
        return false
    }

    private fun instanceIdFromOverlayTag(tag: String?): String? =
        tag?.takeIf { it.startsWith(UnityOverlayTagPrefix) }
            ?.removePrefix(UnityOverlayTagPrefix)
            ?.takeIf { it.isNotBlank() }
}
