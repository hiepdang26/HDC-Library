package com.hdc.adsmultiplatform

import com.hdc.adsmultiplatform.fullscreen.FullscreenLayoutCatalog
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdMode
import com.hdc.adsmultiplatform.fullscreen.NativeAssetVisibilityOptions
import com.hdc.adsmultiplatform.fullscreen.NativeClickAssetOptions
import com.hdc.adsmultiplatform.internal.core.NativeAdDurations
import com.hdc.adsmultiplatform.internal.preload.NativeAdUnitWaterfall

const val DefaultNativeAdInstanceId = "fullscreen_native_default"

enum class NativeAdState {
    Idle,
    Loading,
    Loaded,
    Failed,
    Shown,
    onClosed,
}

data class NativeAdLoadResult(
    val state: NativeAdState,
    val adUnitId: String = "",
    val code: Int = NoErrorCode,
    val message: String = "",
    /** The ad source (mediation network) that filled a loaded ad, as AdMob reports it. */
    val adSourceId: String = "",
    val adSourceName: String = "",
) {
    val hasErrorCode: Boolean
        get() = code != NoErrorCode

    companion object {
        const val NoErrorCode = -1
    }
}

object NativeAdLayoutNames {
    const val Default = FullscreenLayoutCatalog.SingleDefault
    val All: List<String> = FullscreenLayoutCatalog.AllLayouts

    fun default(): String = Default

    fun normalize(layoutName: String?): String =
        FullscreenLayoutCatalog.normalize(layoutName)
}

data class FullscreenNativeAdRequest(
    val instanceId: String = DefaultNativeAdInstanceId,
    val adUnitIds: List<String>,
)

data class NativeAdShowOptions(
    val instanceId: String = DefaultNativeAdInstanceId,
    val layoutName: String = NativeAdLayoutNames.default(),
    val durationSeconds: Double = 0.0,
    val autoClose: Boolean = false,
    val pauseGameplay: Boolean = true,
    val enableAdComeback: Boolean = true,
    val showTCD: Boolean = true,
    val delaySeconds: Double = 0.0,
    val timeUpCSeconds: Int = 0,
    val mode: FullscreenNativeAdMode = FullscreenNativeAdMode.SINGLE,
    val layoutNames: List<String> = emptyList(),
    val durationsSeconds: List<Double> = emptyList(),
    val clickAssets: NativeClickAssetOptions = NativeClickAssetOptions(),
    val assetVisibility: NativeAssetVisibilityOptions = NativeAssetVisibilityOptions(),
    val orientation: String = "auto",
)

fun interface NativeAdLoader {
    fun load(adUnitId: String, onStateChanged: (NativeAdState) -> Unit)

    fun loadWithResult(
        adUnitId: String,
        onResult: (NativeAdLoadResult) -> Unit,
    ) {
        load(adUnitId) { state ->
            onResult(NativeAdLoadResult(state = state, adUnitId = adUnitId))
        }
    }

    fun load(
        request: FullscreenNativeAdRequest,
        onStateChanged: (NativeAdState) -> Unit,
    ) {
        load(request.adUnitIds.firstOrNull().orEmpty(), onStateChanged)
    }

    fun loadWithResult(
        request: FullscreenNativeAdRequest,
        onResult: (NativeAdLoadResult) -> Unit,
    ) {
        val fallbackAdUnitId = request.adUnitIds.firstOrNull().orEmpty()
        load(request) { state ->
            onResult(NativeAdLoadResult(state = state, adUnitId = fallbackAdUnitId))
        }
    }
}

expect fun defaultNativeAdUnitId(): String

expect fun defaultNativeVideoAdUnitId(): String

internal fun parseAdUnitIdsCsv(adUnitIdsCsv: String): List<String> =
    NativeAdUnitWaterfall.fromCsv(adUnitIdsCsv).ids

internal fun durationMillis(durationSeconds: Double): Long =
    NativeAdDurations.toMillis(durationSeconds)
