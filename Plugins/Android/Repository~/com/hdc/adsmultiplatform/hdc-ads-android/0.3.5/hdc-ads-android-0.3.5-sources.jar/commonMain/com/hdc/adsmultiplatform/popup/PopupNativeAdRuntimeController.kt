package com.hdc.adsmultiplatform.popup

import com.hdc.adsmultiplatform.NativeAdLoadFailures
import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.defaultNativeAdUnitId

internal enum class PopupNativeAdDisplayState {
    NotLoaded,
    Loading,
    Loaded,
    Displayable,
    Showing,
    Hidden,
    Closed,
    Failed,
    Destroyed,
}

internal data class PopupNativeAdRuntimeSnapshot(
    val state: NativeAdState = NativeAdState.Idle,
    val displayState: PopupNativeAdDisplayState = PopupNativeAdDisplayState.NotLoaded,
    val isVisible: Boolean = false,
    val activeInstanceId: String? = null,
    val activeAdUnitId: String? = null,
    val activeAdSourceId: String = "",
    val activeAdSourceName: String = "",
    val layoutName: String = PopupNativeAdLayoutCatalog.Default,
    val enableCtrOverlay: Boolean = false,
    val closeSecondsRemaining: Int = 0,
    val canClose: Boolean = true,
)

internal interface PopupNativeAdRuntimeLoader {
    fun load(
        instanceId: String,
        adUnitId: String,
        callback: (NativeAdLoadResult) -> Unit,
    )

    fun destroy(instanceId: String)
}

internal fun interface PopupNativeAdRuntimeScheduler {
    fun schedule(delayMillis: Long, block: () -> Unit): PopupNativeAdRuntimeCancellation
}

internal fun interface PopupNativeAdRuntimeCancellation {
    fun cancel()
}

internal class PopupNativeAdRuntimeController(
    private val alias: String,
    private val loader: PopupNativeAdRuntimeLoader,
    private val scheduler: PopupNativeAdRuntimeScheduler,
    private val callback: PopupNativeAdCallback = object : PopupNativeAdCallback {},
    private val onSnapshotChanged: (PopupNativeAdRuntimeSnapshot) -> Unit = {},
) {
    private var config = PopupNativeAdConfig(ids = listOf(defaultNativeAdUnitId()))
    private var snapshot = PopupNativeAdRuntimeSnapshot()
    private var pendingShowOnLoadSuccess = false
    private var loadTurn = 0
    private var nextAdUnitIndex = 0
    private var failureBackoff = PopupNativeAdFailureBackoffPolicy()
    private var reloadTimer: PopupNativeAdRuntimeCancellation? = null
    private var closeTimer: PopupNativeAdRuntimeCancellation? = null
    private var failureTimer: PopupNativeAdRuntimeCancellation? = null
    private val loadingByInstanceId = mutableMapOf<String, String>()
    private val readyQueue = mutableListOf<LoadedPopupTurn>()
    private val failedAdUnitIds = mutableSetOf<String>()
    private val retiredInstanceIds = mutableSetOf<String>()

    fun configure(nextConfig: PopupNativeAdConfig) {
        val normalized = nextConfig.normalized()
        if (normalized == config) {
            return
        }
        cancelTimers()
        readyQueue.forEach { destroyInstance(it.instanceId) }
        snapshot.activeInstanceId?.let(::destroyInstance)
        loadingByInstanceId.clear()
        readyQueue.clear()
        failedAdUnitIds.clear()
        pendingShowOnLoadSuccess = false
        nextAdUnitIndex = 0
        failureBackoff.resetAfterLoaded()
        config = normalized
        publish(
            PopupNativeAdRuntimeSnapshot(
                layoutName = config.layoutName,
                enableCtrOverlay = config.enableCtrOverlay,
            ),
        )
    }

    fun load() {
        pendingShowOnLoadSuccess = false
        requestLoadForNextTurn(reason = "manual")
    }

    fun isReady(): Boolean =
        snapshot.displayState == PopupNativeAdDisplayState.Loaded ||
            snapshot.displayState == PopupNativeAdDisplayState.Displayable ||
            snapshot.displayState == PopupNativeAdDisplayState.Showing ||
            hasHiddenAd()

    fun isDisplayable(): Boolean =
        (snapshot.displayState == PopupNativeAdDisplayState.Displayable && readyQueue.isNotEmpty()) || hasHiddenAd()

    fun isShowing(): Boolean =
        snapshot.displayState == PopupNativeAdDisplayState.Showing && snapshot.isVisible

    fun displayableInstanceId(): String? =
        readyQueue.firstOrNull()?.instanceId ?: snapshot.activeInstanceId?.takeIf { hasHiddenAd() }

    private fun hasHiddenAd(): Boolean =
        snapshot.displayState == PopupNativeAdDisplayState.Hidden && snapshot.activeInstanceId != null

    fun stateName(): String =
        snapshot.displayState.name

    /** The layout and ad source of the ad on screen, or of the last one shown. */
    fun shownAd(): PopupNativeAdShown =
        PopupNativeAdShown(snapshot.layoutName, snapshot.activeAdSourceId, snapshot.activeAdSourceName)

    fun markShowFailed(message: String) {
        cancelCloseTimer()
        pendingShowOnLoadSuccess = false
        publish(
            snapshot.copy(
                state = NativeAdState.Failed,
                displayState = if (readyQueue.isNotEmpty()) {
                    PopupNativeAdDisplayState.Displayable
                } else {
                    PopupNativeAdDisplayState.Failed
                },
                isVisible = false,
                closeSecondsRemaining = 0,
                canClose = true,
            ),
        )
        callback.onFailedToLoad(
            PopupNativeAdError(
                alias = alias,
                adUnitId = snapshot.activeAdUnitId.orEmpty(),
                message = message,
            ),
        )
    }

    fun show() {
        if (isShowing()) {
            return
        }
        pendingShowOnLoadSuccess = true
        val ready = readyQueue.firstOrNull()
        if (ready != null) {
            showLoaded(ready)
            return
        }
        if (hasHiddenAd() && snapshot.activeAdUnitId != null) {
            publish(
                snapshot.copy(
                    state = NativeAdState.Shown,
                    displayState = PopupNativeAdDisplayState.Showing,
                    isVisible = true,
                    layoutName = config.layoutName,
                    enableCtrOverlay = config.enableCtrOverlay,
                ),
            )
            callback.onDisplayed(currentInfo())
            callback.onOpened(currentInfo())
            restartCloseTimer()
            scheduleReload()
            return
        }
        requestLoadForNextTurn(reason = "show")
    }

    fun close() {
        if (!snapshot.isVisible && !hasHiddenAd()) {
            return
        }
        closeInternal()
    }

    fun hide() {
        pendingShowOnLoadSuccess = false
        if (!snapshot.isVisible || snapshot.activeInstanceId == null) {
            return
        }
        cancelCloseTimer()
        cancelReloadTimer()
        val currentInfo = currentInfo()
        publish(
            snapshot.copy(
                state = NativeAdState.onClosed,
                displayState = PopupNativeAdDisplayState.Hidden,
                isVisible = false,
                closeSecondsRemaining = 0,
                canClose = true,
            ),
        )
        callback.onClosed(currentInfo)
    }

    fun stop() {
        cancelTimers()
        pendingShowOnLoadSuccess = false
        publish(
            snapshot.copy(
                state = NativeAdState.onClosed,
                displayState = PopupNativeAdDisplayState.Closed,
                isVisible = false,
                closeSecondsRemaining = 0,
                canClose = true,
            ),
        )
    }

    fun destroy() {
        cancelTimers()
        readyQueue.forEach { destroyInstance(it.instanceId) }
        readyQueue.clear()
        snapshot.activeInstanceId?.let(::destroyInstance)
        loadingByInstanceId.keys.toList().forEach(::destroyInstance)
        loadingByInstanceId.clear()
        failedAdUnitIds.clear()
        pendingShowOnLoadSuccess = false
        publish(PopupNativeAdRuntimeSnapshot(displayState = PopupNativeAdDisplayState.Destroyed))
    }

    private fun closeInternal() {
        cancelCloseTimer()
        val currentInfo = currentInfo()
        publish(
            snapshot.copy(
                state = NativeAdState.onClosed,
                displayState = PopupNativeAdDisplayState.Closed,
                isVisible = false,
                closeSecondsRemaining = 0,
                canClose = true,
            ),
        )
        callback.onClosed(currentInfo)
    }

    private fun requestLoadForNextTurn(reason: String) {
        failureTimer?.cancel()
        failureTimer = null
        val adUnitId = nextLoadCandidate()
        if (adUnitId == null) {
            scheduleFailureBackoff(reason)
            return
        }
        failedAdUnitIds.remove(adUnitId)
        val instanceId = nextInstanceId(adUnitId)
        loadingByInstanceId[instanceId] = adUnitId
        publish(
            snapshot.copy(
                state = NativeAdState.Loading,
                displayState = PopupNativeAdDisplayState.Loading,
            ),
        )
        loader.load(instanceId, adUnitId) { result ->
            handleLoadResult(instanceId, adUnitId, result)
        }
    }

    private fun handleLoadResult(
        instanceId: String,
        adUnitId: String,
        result: NativeAdLoadResult,
    ) {
        if (loadingByInstanceId[instanceId] != adUnitId) {
            return
        }
        when (result.state) {
            NativeAdState.Loading -> publish(
                snapshot.copy(
                    state = NativeAdState.Loading,
                    displayState = PopupNativeAdDisplayState.Loading,
                ),
            )
            NativeAdState.Loaded -> {
                loadingByInstanceId.remove(instanceId)
                val loadedAdUnitId = result.adUnitId.ifBlank { adUnitId }
                failedAdUnitIds.remove(loadedAdUnitId)
                failureBackoff.resetAfterLoaded()
                val loaded = LoadedPopupTurn(
                    instanceId = instanceId,
                    adUnitId = loadedAdUnitId,
                    adSourceId = result.adSourceId,
                    adSourceName = result.adSourceName,
                    layoutName = config.layoutFor(result.adSourceId),
                )
                readyQueue += loaded
                callback.onLoaded(loaded.info())
                callback.onDisplayable(alias)
                publish(
                    snapshot.copy(
                        state = NativeAdState.Loaded,
                        displayState = PopupNativeAdDisplayState.Displayable,
                    ),
                )
                if (pendingShowOnLoadSuccess) {
                    showLoaded(loaded)
                }
            }
            NativeAdState.Failed -> {
                loadingByInstanceId.remove(instanceId)
                val failedAdUnitId = result.adUnitId.ifBlank { adUnitId }
                val message = result.message.ifBlank { "Popup native ad failed to load" }
                failedAdUnitIds += failedAdUnitId
                destroyInstance(instanceId)
                NativeAdLoadFailures.record(alias, result.copy(adUnitId = failedAdUnitId, message = message))
                callback.onFailedToLoad(
                    PopupNativeAdError(
                        alias = alias,
                        adUnitId = failedAdUnitId,
                        code = result.code,
                        message = message,
                    ),
                )
                publish(
                    snapshot.copy(
                        state = NativeAdState.Failed,
                        displayState = PopupNativeAdDisplayState.Failed,
                    ),
                )
                requestLoadForNextTurn(reason = "load_failed")
            }
            else -> Unit
        }
    }

    private fun showLoaded(loaded: LoadedPopupTurn) {
        readyQueue.removeAll { it.instanceId == loaded.instanceId }
        val previousInstanceId = snapshot.activeInstanceId
        val nextSnapshot = snapshot.copy(
            state = NativeAdState.Shown,
            displayState = PopupNativeAdDisplayState.Showing,
            isVisible = true,
            activeInstanceId = loaded.instanceId,
            activeAdUnitId = loaded.adUnitId,
            activeAdSourceId = loaded.adSourceId,
            activeAdSourceName = loaded.adSourceName,
            layoutName = loaded.layoutName,
            enableCtrOverlay = config.enableCtrOverlay,
            closeSecondsRemaining = config.timeShowSeconds,
            canClose = config.timeShowSeconds == 0,
        )
        publish(nextSnapshot)
        callback.onDisplayed(loaded.info())
        callback.onOpened(loaded.info())
        if (previousInstanceId != null && previousInstanceId != loaded.instanceId) {
            destroyInstance(previousInstanceId)
        }
        restartCloseTimer()
        scheduleReload()
    }

    private fun restartCloseTimer() {
        cancelCloseTimer()
        val seconds = config.timeShowSeconds.coerceAtLeast(0)
        if (!snapshot.isVisible || seconds == 0) {
            publish(snapshot.copy(closeSecondsRemaining = 0, canClose = true))
            return
        }
        publish(snapshot.copy(closeSecondsRemaining = seconds, canClose = false))
        scheduleCloseTick(seconds)
    }

    private fun scheduleCloseTick(totalSeconds: Int) {
        closeTimer = scheduler.schedule(1_000L) {
            closeTimer = null
            if (!snapshot.isVisible) {
                return@schedule
            }
            val remaining = (snapshot.closeSecondsRemaining - 1).coerceAtLeast(0)
            publish(snapshot.copy(closeSecondsRemaining = remaining, canClose = remaining == 0))
            if (remaining > 0) {
                scheduleCloseTick(totalSeconds)
            } else if (config.autoClose) {
                closeInternal()
            }
        }
    }

    private fun scheduleReload() {
        cancelReloadTimer()
        val seconds = config.timeReloadSeconds
        if (!snapshot.isVisible || seconds <= 0) {
            return
        }
        reloadTimer = scheduler.schedule(seconds * 1_000L) {
            reloadTimer = null
            if (snapshot.isVisible) {
                pendingShowOnLoadSuccess = true
                requestLoadForNextTurn(reason = "timeReload")
            }
        }
    }

    private fun scheduleFailureBackoff(reason: String) {
        if (failureTimer != null) {
            return
        }
        val delayMillis = failureBackoff.nextFailureRetryDelayMillis()
        failureTimer = scheduler.schedule(delayMillis) {
            failureTimer = null
            failedAdUnitIds.clear()
            requestLoadForNextTurn(reason = reason)
        }
    }

    private fun nextLoadCandidate(): String? {
        val ids = config.ids
        repeat(ids.size) {
            val index = (nextAdUnitIndex + it) % ids.size
            val candidate = ids[index]
            val isLoading = candidate in loadingByInstanceId.values
            val isFailed = candidate in failedAdUnitIds
            if (!isLoading && !isFailed) {
                nextAdUnitIndex = (index + 1) % ids.size
                return candidate
            }
        }
        return null
    }

    private fun nextInstanceId(adUnitId: String): String {
        loadTurn += 1
        return "$alias:popup:$loadTurn:${adUnitId.stableRuntimeKey()}"
    }

    private fun currentInfo(): PopupNativeAdInfo =
        PopupNativeAdInfo(
            alias = alias,
            instanceId = snapshot.activeInstanceId.orEmpty(),
            adUnitId = snapshot.activeAdUnitId.orEmpty(),
            layoutName = snapshot.layoutName,
        )

    private fun LoadedPopupTurn.info(): PopupNativeAdInfo =
        PopupNativeAdInfo(alias, instanceId, adUnitId, layoutName)

    private fun publish(nextSnapshot: PopupNativeAdRuntimeSnapshot) {
        snapshot = nextSnapshot
        onSnapshotChanged(nextSnapshot)
    }

    private fun cancelTimers() {
        cancelReloadTimer()
        cancelCloseTimer()
        failureTimer?.cancel()
        failureTimer = null
    }

    private fun cancelReloadTimer() {
        reloadTimer?.cancel()
        reloadTimer = null
    }

    private fun cancelCloseTimer() {
        closeTimer?.cancel()
        closeTimer = null
    }

    private fun destroyInstance(instanceId: String) {
        if (instanceId.isBlank() || !retiredInstanceIds.add(instanceId)) {
            return
        }
        loader.destroy(instanceId)
    }

    private fun PopupNativeAdConfig.normalized(): PopupNativeAdConfig =
        normalizedForPopupRuntime()
}

private data class LoadedPopupTurn(
    val instanceId: String,
    val adUnitId: String,
    val adSourceId: String,
    val adSourceName: String,
    val layoutName: String,
)

internal data class PopupNativeAdShown(
    val layoutName: String,
    val adSourceId: String,
    val adSourceName: String,
)

private class PopupNativeAdFailureBackoffPolicy {
    private var failureExponent = MinFailureExponent

    fun nextFailureRetryDelayMillis(): Long {
        val exponent = failureExponent.coerceAtMost(MaxFailureExponent)
        failureExponent = (failureExponent + 1).coerceAtMost(MaxFailureExponent)
        return (1L shl exponent) * 1_000L
    }

    fun resetAfterLoaded() {
        failureExponent = MinFailureExponent
    }

    companion object {
        private const val MinFailureExponent = 2
        private const val MaxFailureExponent = 6
    }
}

private fun String.stableRuntimeKey(): String {
    var hash = 0
    forEach { char ->
        hash = 31 * hash + char.code
    }
    return hash.toString()
}
