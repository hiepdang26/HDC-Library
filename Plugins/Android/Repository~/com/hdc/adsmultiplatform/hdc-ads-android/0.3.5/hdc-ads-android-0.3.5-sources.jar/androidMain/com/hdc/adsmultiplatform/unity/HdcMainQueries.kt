package com.hdc.adsmultiplatform.unity

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Runs a block on the main thread for a caller on another thread and waits for its answer.
 *
 * Unity's activity pauses the engine from the main thread and then waits for the engine thread. An engine-thread caller
 * waiting here at that moment would wait for a main thread that waits for it, and both would sit out their timeouts. So
 * while the main thread [pausing] Unity, waiting callers are released and new ones get their fallback at once.
 *
 * A block whose caller already got the fallback, after a release or a timeout, never runs: a show that its caller heard
 * as "not shown" must not start later.
 */
internal class HdcMainQueries(
    private val post: (Runnable) -> Unit,
    private val timeoutMillis: Long,
) {
    @Volatile
    private var pausing = false

    private val waiting: MutableSet<Query<*>> = ConcurrentHashMap.newKeySet()

    /** Answers [block] run on the main thread, or [fallback] when the main thread pauses Unity or does not answer in time. */
    fun <T> query(fallback: T, block: () -> T): Answer<T> {
        if (pausing) {
            return Answer(fallback, Outcome.Pausing)
        }
        val query = Query(block)
        waiting.add(query)
        try {
            post(Runnable { query.run() })
            if (pausing) {
                query.cancel()
            }
            return when (query.await(timeoutMillis)) {
                Outcome.Answered -> Answer(query.result(), Outcome.Answered)
                Outcome.Pausing -> Answer(fallback, Outcome.Pausing)
                Outcome.TimedOut -> Answer(fallback, Outcome.TimedOut)
            }
        } finally {
            waiting.remove(query)
        }
    }

    /** Called on the main thread when it starts pausing Unity ([value] true) and once it is done ([value] false). */
    fun pausing(value: Boolean) {
        pausing = value
        if (value) {
            waiting.forEach { it.cancel() }
        }
    }

    internal enum class Outcome { Answered, Pausing, TimedOut }

    internal data class Answer<T>(val value: T, val outcome: Outcome)

    private class Query<T>(private val block: () -> T) {
        private val state = AtomicInteger(Pending)
        private val done = CountDownLatch(1)

        @Volatile
        private var value: T? = null

        @Volatile
        private var failure: Throwable? = null

        fun run() {
            if (!state.compareAndSet(Pending, Running)) {
                return
            }
            try {
                value = block()
            } catch (error: Throwable) {
                failure = error
            } finally {
                state.set(Finished)
                done.countDown()
            }
        }

        fun cancel() {
            if (state.compareAndSet(Pending, Released)) {
                done.countDown()
            }
        }

        fun await(timeoutMillis: Long): Outcome {
            if (!done.await(timeoutMillis, TimeUnit.MILLISECONDS)) {
                if (state.compareAndSet(Pending, TimedOut)) {
                    return Outcome.TimedOut
                }
                done.await()
            }
            return when (state.get()) {
                Finished -> Outcome.Answered
                Released -> Outcome.Pausing
                else -> Outcome.TimedOut
            }
        }

        @Suppress("UNCHECKED_CAST")
        fun result(): T {
            failure?.let { throw it }
            return value as T
        }
    }

    private companion object {
        const val Pending = 0
        const val Running = 1
        const val Finished = 2
        const val Released = 3
        const val TimedOut = 4
    }
}
