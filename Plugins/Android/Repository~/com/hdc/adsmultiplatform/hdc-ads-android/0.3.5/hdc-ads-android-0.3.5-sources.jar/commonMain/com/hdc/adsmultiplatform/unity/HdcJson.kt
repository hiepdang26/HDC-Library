package com.hdc.adsmultiplatform.unity

/**
 * Minimal JSON reader and writer for the Unity bridge protocol.
 *
 * Objects read as [Map], arrays as [List], integers as [Long] and other numbers as [Double].
 */
internal object HdcJson {
    fun parseObject(text: String): Map<String, Any?> {
        if (text.isBlank()) {
            return emptyMap()
        }
        val value = Reader(text).readDocument()
        require(value is Map<*, *>) { "JSON object expected" }
        @Suppress("UNCHECKED_CAST")
        return value as Map<String, Any?>
    }

    fun write(value: Any?): String = buildString { appendValue(value) }

    private fun StringBuilder.appendValue(value: Any?) {
        when (value) {
            null -> append("null")
            is String -> appendString(value)
            is Boolean -> append(value)
            is Double -> if (value.isFinite()) append(value) else append("null")
            is Float -> if (value.isFinite()) append(value) else append("null")
            is Number -> append(value)
            is Map<*, *> -> {
                append('{')
                var first = true
                value.forEach { (key, item) ->
                    if (!first) append(',')
                    first = false
                    appendString(key.toString())
                    append(':')
                    appendValue(item)
                }
                append('}')
            }
            is Iterable<*> -> {
                append('[')
                var first = true
                value.forEach { item ->
                    if (!first) append(',')
                    first = false
                    appendValue(item)
                }
                append(']')
            }
            is Array<*> -> appendValue(value.asList())
            else -> appendString(value.toString())
        }
    }

    private fun StringBuilder.appendString(value: String) {
        append('"')
        value.forEach { char ->
            when {
                char == '"' -> append("\\\"")
                char == '\\' -> append("\\\\")
                char == '\n' -> append("\\n")
                char == '\r' -> append("\\r")
                char == '\t' -> append("\\t")
                char < ' ' -> append("\\u").append(char.code.toString(16).padStart(4, '0'))
                else -> append(char)
            }
        }
        append('"')
    }

    private class Reader(private val text: String) {
        private var index = 0

        fun readDocument(): Any? {
            val value = readValue()
            skipWhitespace()
            if (index != text.length) fail("Unexpected content")
            return value
        }

        private fun readValue(): Any? {
            skipWhitespace()
            if (index >= text.length) fail("Unexpected end of JSON")
            return when (val char = text[index]) {
                '{' -> readObject()
                '[' -> readArray()
                '"' -> readString()
                't' -> readLiteral("true", true)
                'f' -> readLiteral("false", false)
                'n' -> readLiteral("null", null)
                else -> if (char == '-' || char in '0'..'9') readNumber() else fail("Unexpected character '$char'")
            }
        }

        private fun readObject(): Map<String, Any?> {
            index++
            val result = LinkedHashMap<String, Any?>()
            skipWhitespace()
            if (peek() == '}') {
                index++
                return result
            }
            while (true) {
                skipWhitespace()
                if (peek() != '"') fail("Object key expected")
                val key = readString()
                skipWhitespace()
                if (next() != ':') fail("':' expected")
                result[key] = readValue()
                skipWhitespace()
                when (next()) {
                    ',' -> continue
                    '}' -> return result
                    else -> fail("',' or '}' expected")
                }
            }
        }

        private fun readArray(): List<Any?> {
            index++
            val result = ArrayList<Any?>()
            skipWhitespace()
            if (peek() == ']') {
                index++
                return result
            }
            while (true) {
                result += readValue()
                skipWhitespace()
                when (next()) {
                    ',' -> continue
                    ']' -> return result
                    else -> fail("',' or ']' expected")
                }
            }
        }

        private fun readString(): String {
            index++
            val result = StringBuilder()
            while (true) {
                if (index >= text.length) fail("Unterminated string")
                when (val char = text[index++]) {
                    '"' -> return result.toString()
                    '\\' -> {
                        if (index >= text.length) fail("Unterminated escape")
                        when (val escaped = text[index++]) {
                            '"', '\\', '/' -> result.append(escaped)
                            'b' -> result.append('\b')
                            'f' -> result.append('\u000C')
                            'n' -> result.append('\n')
                            'r' -> result.append('\r')
                            't' -> result.append('\t')
                            'u' -> {
                                if (index + 4 > text.length) fail("Invalid unicode escape")
                                val code = text.substring(index, index + 4).toIntOrNull(16)
                                    ?: fail("Invalid unicode escape")
                                result.append(code.toChar())
                                index += 4
                            }
                            else -> fail("Invalid escape '\\$escaped'")
                        }
                    }
                    else -> result.append(char)
                }
            }
        }

        private fun readNumber(): Number {
            val start = index
            while (index < text.length && text[index] in NumberChars) index++
            val token = text.substring(start, index)
            val isInteger = token.none { it == '.' || it == 'e' || it == 'E' }
            val number: Number? = if (isInteger) token.toLongOrNull() ?: token.toDoubleOrNull() else token.toDoubleOrNull()
            return number ?: fail("Invalid number '$token'")
        }

        private fun readLiteral(literal: String, value: Any?): Any? {
            if (!text.startsWith(literal, index)) fail("'$literal' expected")
            index += literal.length
            return value
        }

        private fun skipWhitespace() {
            while (index < text.length && text[index].isWhitespace()) index++
        }

        private fun peek(): Char? = text.getOrNull(index)

        private fun next(): Char? = text.getOrNull(index++)

        private fun fail(message: String): Nothing = throw IllegalArgumentException("$message at $index")

        private companion object {
            const val NumberChars = "0123456789+-.eE"
        }
    }
}

/** Typed access to a command's JSON arguments. */
internal class HdcArgs(private val values: Map<String, Any?>) {
    fun string(name: String, default: String = ""): String = values[name] as? String ?: default

    fun int(name: String, default: Int): Int = (values[name] as? Number)?.toInt() ?: default

    fun double(name: String, default: Double): Double = (values[name] as? Number)?.toDouble() ?: default

    fun float(name: String, default: Float): Float = (values[name] as? Number)?.toFloat() ?: default

    fun boolean(name: String, default: Boolean): Boolean = values[name] as? Boolean ?: default

    /** A nested object; empty when missing, so every read falls back to its default. */
    fun obj(name: String): HdcArgs {
        @Suppress("UNCHECKED_CAST")
        val nested = values[name] as? Map<String, Any?>
        return HdcArgs(nested ?: emptyMap())
    }

    /** A list of nested objects; non-object items are skipped. */
    fun objList(name: String): List<HdcArgs> =
        (values[name] as? List<*>).orEmpty().mapNotNull { item ->
            @Suppress("UNCHECKED_CAST")
            (item as? Map<String, Any?>)?.let(::HdcArgs)
        }

    fun doubleList(name: String): List<Double> =
        (values[name] as? List<*>).orEmpty().mapNotNull { (it as? Number)?.toDouble() }

    /** A list of non-blank strings, from a JSON array or a string separated by `,` `;` or new lines. */
    fun stringList(name: String): List<String> =
        when (val value = values[name]) {
            is List<*> -> value.mapNotNull { (it as? String)?.trim() }
            is String -> value.split(',', ';', '\n')
            else -> emptyList()
        }.map { it.trim() }.filter { it.isNotEmpty() }

    /** The ad instance id every ad command needs. */
    fun id(): String = string("id").trim().also { require(it.isNotEmpty()) { "id is required" } }

    companion object {
        fun parse(json: String): HdcArgs = HdcArgs(HdcJson.parseObject(json))
    }
}
