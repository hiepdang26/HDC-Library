package com.hdc.adsmultiplatform.unity

import android.app.Activity
import android.app.Application
import android.os.Bundle

/**
 * Tells [HdcMainQueries] when the main thread pauses Unity.
 *
 * Unity's activity calls `super.onPause()` (or `super.onStop()`) before it pauses the engine and waits for it, so the
 * lifecycle callbacks of that activity run first, on Android 10 and later even before `onPause`. The pause ends once the
 * main thread is back to its message queue, which the posted reset reaches only then.
 */
internal class HdcUnityPauseWatch(
    private val queries: HdcMainQueries,
    private val unityActivity: () -> Activity?,
    private val postToMain: (Runnable) -> Unit,
) : Application.ActivityLifecycleCallbacks {
    @Volatile
    private var started = false

    fun ensureStarted() {
        if (started) {
            return
        }
        val activity = unityActivity() ?: return
        synchronized(this) {
            if (started) {
                return
            }
            activity.application.registerActivityLifecycleCallbacks(this)
            started = true
        }
    }

    override fun onActivityPrePaused(activity: Activity) = pausing(activity)

    override fun onActivityPaused(activity: Activity) = pausing(activity)

    override fun onActivityPreStopped(activity: Activity) = pausing(activity)

    override fun onActivityStopped(activity: Activity) = pausing(activity)

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit

    override fun onActivityStarted(activity: Activity) = Unit

    override fun onActivityResumed(activity: Activity) = Unit

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit

    override fun onActivityDestroyed(activity: Activity) = Unit

    private fun pausing(activity: Activity) {
        if (activity !== unityActivity()) {
            return
        }
        queries.pausing(true)
        postToMain(Runnable { queries.pausing(false) })
    }
}
