package com.hdc.adsmultiplatform.unity

import com.hdc.adsmultiplatform.NativeAdLoadFailures
import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.internal.core.AdTrackingEventNames
import com.hdc.adsmultiplatform.internal.core.AdTrackingEvents

internal object HdcFormat {
    const val Sdk = "sdk"
    const val Interstitial = "interstitial"
    const val Fullscreen = "fullscreen"
    const val Banner = "banner"
    const val Popup = "popup"
}

internal object HdcEventType {
    const val Initialized = "Initialized"
    const val Loaded = "Loaded"
    const val LoadFailed = "LoadFailed"
    const val Shown = "Shown"
    const val ShowFailed = "ShowFailed"
    const val Impression = "Impression"
    const val Clicked = "Clicked"
    const val Paid = "Paid"
    const val Closed = "Closed"
}

internal object HdcEvents {
    fun emit(
        id: String,
        format: String,
        type: String,
        fields: Map<String, Any?> = emptyMap(),
    ) {
        val event = LinkedHashMap<String, Any?>(fields.size + 3)
        event["id"] = id
        event["format"] = format
        event["type"] = type
        event.putAll(fields)
        HdcUnityBridge.emit(HdcJson.write(event))
    }

    fun error(code: Int, message: String): Map<String, Any?> =
        mapOf("code" to code, "message" to message)
}

/** Runs [block] on the main thread; a failure goes to [onError] instead of crashing the host app. */
internal fun hdcRunOnMainCatching(onError: (Throwable) -> Unit, block: () -> Unit) {
    hdcRunOnMain {
        try {
            block()
        } catch (error: Throwable) {
            HdcLog.warn("main thread task failed: ${error.message}")
            onError(error)
        }
    }
}

/** Forwards impression, click and paid events of every format to Unity. */
internal object HdcTracking {
    fun start() {
        AdTrackingEvents.listener = { event ->
            val fields = LinkedHashMap<String, Any?>()
            fields["adUnitId"] = event.adUnitId
            fields["adapter"] = event.mediationAdapter
            fields["adSource"] = event.adSourceName
            fields["responseId"] = event.responseId
            if (event.name == AdTrackingEventNames.Paid) {
                fields["valueMicros"] = event.valueMicros
                fields["currency"] = event.currencyCode
                fields["precision"] = event.precision
            }
            HdcEvents.emit(id = event.instanceId, format = event.format, type = event.name, fields = fields)
        }
    }
}

/**
 * Turns the state stream of a native banner or popup into events. Repeated states are dropped (a banner
 * reports its state on every countdown tick). A failure is reported one main loop later, and only if
 * nothing moved on in between: loading goes on to the next ad unit right after a failure.
 */
internal class HdcNativeStateEvents(
    private val id: String,
    private val format: String,
    private val shownFields: () -> Map<String, Any?> = { emptyMap() },
) {
    private var lastState: NativeAdState? = null
    private var failurePending = false
    private var showRequested = false

    fun onShowRequested() {
        showRequested = true
    }

    fun onState(state: NativeAdState) {
        if (state == lastState) {
            return
        }
        lastState = state
        when (state) {
            NativeAdState.Loading, NativeAdState.Idle -> failurePending = false
            NativeAdState.Loaded -> {
                failurePending = false
                emit(HdcEventType.Loaded)
            }
            NativeAdState.Shown -> {
                showRequested = false
                emit(HdcEventType.Shown, shownFields())
            }
            NativeAdState.onClosed -> {
                showRequested = false
                emit(HdcEventType.Closed)
            }
            NativeAdState.Failed -> onFailed()
        }
    }

    private fun onFailed() {
        if (showRequested) {
            showRequested = false
            emit(HdcEventType.ShowFailed, HdcEvents.error(NativeAdLoadResult.NoErrorCode, "Show failed"))
            return
        }
        failurePending = true
        hdcPostToMain {
            if (failurePending && lastState == NativeAdState.Failed) {
                failurePending = false
                val failure = NativeAdLoadFailures.take(id)
                val fields = if (failure == null) {
                    HdcEvents.error(NativeAdLoadResult.NoErrorCode, "No ad loaded")
                } else {
                    mapOf("adUnitId" to failure.adUnitId) + HdcEvents.error(failure.code, failure.message)
                }
                emit(HdcEventType.LoadFailed, fields)
            }
        }
    }

    private fun emit(type: String, fields: Map<String, Any?> = emptyMap()) {
        HdcEvents.emit(id = id, format = format, type = type, fields = fields)
    }
}
