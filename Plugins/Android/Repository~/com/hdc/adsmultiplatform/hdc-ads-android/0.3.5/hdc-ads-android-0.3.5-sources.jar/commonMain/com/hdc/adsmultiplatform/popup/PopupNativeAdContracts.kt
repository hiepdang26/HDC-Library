package com.hdc.adsmultiplatform.popup

import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.defaultNativeAdUnitId

const val DefaultPopupNativeAdInstanceId = "popup_native_default"

data class PopupNativeAdRequest(
    val instanceId: String = DefaultPopupNativeAdInstanceId,
    val adUnitIds: List<String>,
)

data class PopupNativeAdConfig(
    val ids: List<String>,
    val layoutName: String = PopupNativeAdLayoutCatalog.Default,
    val timeShowSeconds: Int = 5,
    val timeReloadSeconds: Int = 0,
    val xDp: Float = 16f,
    val yDp: Float = 96f,
    val adWidthDp: Float = 320f,
    val adHeightDp: Float = 280f,
    val autoClose: Boolean = false,
    val enableCtrOverlay: Boolean = false,
    /** Layouts for ads from given ad sources; an ad from any other source shows [layoutName]. */
    val adSourceLayouts: List<PopupNativeAdSourceLayout> = emptyList(),
)

data class PopupNativeAdSourceLayout(
    val adSourceIds: List<String>,
    val layoutName: String,
)

data class PopupNativeAdInfo(
    val alias: String,
    val instanceId: String,
    val adUnitId: String,
    val layoutName: String,
)

data class PopupNativeAdError(
    val alias: String,
    val adUnitId: String,
    val code: Int = -1,
    val message: String,
)

interface PopupNativeAdCallback {
    fun onLoaded(ad: PopupNativeAdInfo) = Unit
    fun onDisplayable(alias: String) = Unit
    fun onDisplayed(ad: PopupNativeAdInfo) = Unit
    fun onOpened(ad: PopupNativeAdInfo) = Unit
    fun onClosed(ad: PopupNativeAdInfo) = Unit
    fun onClicked(ad: PopupNativeAdInfo) = Unit
    fun onFailedToLoad(error: PopupNativeAdError) = Unit
}

fun interface PopupNativeAdLoader {
    fun load(
        request: PopupNativeAdRequest,
        onStateChanged: (NativeAdState) -> Unit,
    )

    fun loadWithResult(
        request: PopupNativeAdRequest,
        onResult: (NativeAdLoadResult) -> Unit,
    ) {
        val fallbackAdUnitId = request.adUnitIds.firstOrNull().orEmpty()
        load(request) { state ->
            onResult(NativeAdLoadResult(state = state, adUnitId = fallbackAdUnitId))
        }
    }

    fun destroy(instanceId: String) = Unit
}

object PopupNativeAdLayoutCatalog {
    const val PopupSingleManual01 = "popup_single_manual_01"
    const val PopupSingleManual02 = "popup_single_manual_02"
    const val PopupSingleManual03 = "popup_single_manual_03"
    const val PopupSingleManual04 = "popup_single_manual_04"
    const val PopupSingleManual05 = "popup_single_manual_05"
    const val PopupSingleManual06 = "popup_single_manual_06"
    const val PopupSingleManual07 = "popup_single_manual_07"
    const val PopupSingleManual08 = "popup_single_manual_08"
    const val PopupSingleManual09 = "popup_single_manual_09"
    const val PopupSingleManual10 = "popup_single_manual_10"
    const val PopupSingleManual11 = "popup_single_manual_11"
    const val PopupSingleManual12 = "popup_single_manual_12"
    const val PopupSingleManual13 = "popup_single_manual_13"
    const val PopupSingleManual14 = "popup_single_manual_14"
    const val PopupSingleManual15 = "popup_single_manual_15"
    const val Default = PopupSingleManual01
    const val MinWidthDp = 300f
    const val MinHeightDp = 250f
    const val MinCompactHeightDp = 66f

    val All: List<String> = listOf(
        PopupSingleManual01,
        PopupSingleManual02,
        PopupSingleManual03,
        PopupSingleManual04,
        PopupSingleManual05,
        PopupSingleManual06,
        PopupSingleManual07,
        PopupSingleManual08,
        PopupSingleManual09,
        PopupSingleManual10,
        PopupSingleManual11,
        PopupSingleManual12,
        PopupSingleManual13,
        PopupSingleManual14,
        PopupSingleManual15,
    )

    fun normalize(layoutName: String?): String {
        val key = layoutName?.trim()?.lowercase().orEmpty()
        return if (key in All) key else Default
    }

    fun usesMediaView(layoutName: String?): Boolean =
        when (normalize(layoutName)) {
            PopupSingleManual10,
            PopupSingleManual11,
            PopupSingleManual13,
            PopupSingleManual14,
            -> false
            else -> true
        }

    @Suppress("UNUSED_PARAMETER")
    fun usesAdChoicesView(layoutName: String?): Boolean = true

    fun minHeightDp(layoutName: String?): Float =
        if (usesMediaView(layoutName)) MinHeightDp else MinCompactHeightDp
}

internal fun PopupNativeAdConfig.normalizedForPopupRuntime(): PopupNativeAdConfig {
    val normalized = copy(
        ids = ids.map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty { listOf(defaultNativeAdUnitId()) },
        layoutName = PopupNativeAdLayoutCatalog.normalize(layoutName),
        timeShowSeconds = timeShowSeconds.coerceAtLeast(0),
        timeReloadSeconds = timeReloadSeconds.coerceAtLeast(0),
        adWidthDp = adWidthDp.coerceAtLeast(PopupNativeAdLayoutCatalog.MinWidthDp),
        adSourceLayouts = adSourceLayouts.mapNotNull { sourceLayout ->
            val adSourceIds = sourceLayout.adSourceIds.map { it.trim() }.filter { it.isNotEmpty() }
            if (adSourceIds.isEmpty() || sourceLayout.layoutName.isBlank()) {
                null
            } else {
                PopupNativeAdSourceLayout(adSourceIds, PopupNativeAdLayoutCatalog.normalize(sourceLayout.layoutName))
            }
        },
    )
    return normalized.copy(adHeightDp = adHeightDp.coerceAtLeast(normalized.minLayoutHeightDp()))
}

/** The layout an ad from [adSourceId] shows: the first ad source layout that lists the source, else [layoutName]. */
internal fun PopupNativeAdConfig.layoutFor(adSourceId: String): String =
    adSourceLayouts.firstOrNull { adSourceId.isNotEmpty() && adSourceId in it.adSourceIds }?.layoutName ?: layoutName

/** The tallest minimum height among the layouts this popup can show. */
internal fun PopupNativeAdConfig.minLayoutHeightDp(): Float =
    (listOf(layoutName) + adSourceLayouts.map { it.layoutName }).maxOf { PopupNativeAdLayoutCatalog.minHeightDp(it) }

/** A popup's frame inside its viewport, in dp (points on iOS). */
internal data class PopupPlacementFrame(
    val x: Double,
    val y: Double,
    val width: Double,
    val height: Double,
    val viewportWidth: Double,
    val viewportHeight: Double,
)

/**
 * Resolves where the popup goes in a [viewportWidth] x [viewportHeight] viewport. A position with both
 * values in 0..1 is a normalized center (y measured from the bottom); anything else is the top-left
 * corner. The size keeps the layout minimums and is clamped, like the position, to the viewport.
 * Null when the viewport or the config has no usable size.
 */
internal fun PopupNativeAdConfig.placementFrame(viewportWidth: Double, viewportHeight: Double): PopupPlacementFrame? {
    if (!viewportWidth.isFinite() || !viewportHeight.isFinite() || viewportWidth <= 0.0 || viewportHeight <= 0.0) {
        return null
    }
    if (!listOf(xDp, yDp, adWidthDp, adHeightDp).all { it.isFinite() }) {
        return null
    }

    val minWidth = PopupNativeAdLayoutCatalog.MinWidthDp.toDouble().coerceAtMost(viewportWidth)
    val minHeight = minLayoutHeightDp().toDouble().coerceAtMost(viewportHeight)
    val width = adWidthDp.toDouble().coerceAtLeast(minWidth).coerceAtMost(viewportWidth)
    val height = adHeightDp.toDouble().coerceAtLeast(minHeight).coerceAtMost(viewportHeight)
    val requestedX = xDp.toDouble()
    val requestedY = yDp.toDouble()
    val isNormalizedCenter = requestedX in 0.0..1.0 && requestedY in 0.0..1.0
    val rawX = if (isNormalizedCenter) requestedX * viewportWidth - width * 0.5 else requestedX
    val rawY = if (isNormalizedCenter) (1.0 - requestedY) * viewportHeight - height * 0.5 else requestedY
    return PopupPlacementFrame(
        x = rawX.coerceIn(0.0, (viewportWidth - width).coerceAtLeast(0.0)),
        y = rawY.coerceIn(0.0, (viewportHeight - height).coerceAtLeast(0.0)),
        width = width,
        height = height,
        viewportWidth = viewportWidth,
        viewportHeight = viewportHeight,
    )
}
