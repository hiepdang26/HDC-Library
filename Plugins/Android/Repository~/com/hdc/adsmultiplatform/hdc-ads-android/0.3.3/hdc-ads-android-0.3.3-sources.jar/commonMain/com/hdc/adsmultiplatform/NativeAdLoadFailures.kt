package com.hdc.adsmultiplatform

/**
 * The last load failure of each banner or popup alias, with the ad SDK's error code. Their state callbacks only
 * carry the state, so the Unity bridge reads the error from here when it reports the failure. Main thread only.
 */
internal object NativeAdLoadFailures {
    private val failures = mutableMapOf<String, NativeAdLoadResult>()

    fun record(alias: String, failure: NativeAdLoadResult) {
        failures[alias] = failure
    }

    /** The alias's last failure, removed so that a later failure is not reported with an old error. */
    fun take(alias: String): NativeAdLoadResult? = failures.remove(alias)
}
