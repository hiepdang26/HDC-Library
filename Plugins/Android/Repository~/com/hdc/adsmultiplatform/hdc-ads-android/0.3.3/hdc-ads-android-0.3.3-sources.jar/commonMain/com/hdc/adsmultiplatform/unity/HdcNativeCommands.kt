package com.hdc.adsmultiplatform.unity

import com.hdc.adsmultiplatform.NativeAdLoadResult
import com.hdc.adsmultiplatform.NativeAdState
import com.hdc.adsmultiplatform.banner.BannerNativeAdConfig
import com.hdc.adsmultiplatform.banner.BannerNativeAdLayoutCatalog
import com.hdc.adsmultiplatform.fullscreen.FullscreenLayoutCatalog
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdCallback
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdError
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdInfo
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdMode
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdRegistry
import com.hdc.adsmultiplatform.fullscreen.FullscreenNativeAdShowOptions
import com.hdc.adsmultiplatform.fullscreen.NativeAssetVisibilityOptions
import com.hdc.adsmultiplatform.fullscreen.NativeClickAssetOptions
import com.hdc.adsmultiplatform.popup.PopupNativeAdConfig
import com.hdc.adsmultiplatform.popup.PopupNativeAdLayoutCatalog

/**
 * `fullscreen.*` commands for native ads that cover the screen.
 *
 * - `load` `{id, adUnitIds:[…], reloadAfterShow?}`: ad units are tried in order.
 * - `show` `{id, mode?, layoutNames?, duration?, durations?, orientation?, autoClose?, pauseGameplay?,
 *   enableAdComeback?, showTCD?, delay?, timeUpC?, clickAssets?{…}, assetVisibility?{…}}` returns whether
 *   a loaded ad starts to show. A show that cannot start after all reports ShowFailed.
 * - `hide`, `isReady`, `destroy` `{id}`.
 */
internal object HdcFullscreenCommands {
    private val host: HdcFullscreenHost by lazy { hdcFullscreenHost() }

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val reloadAfterShow = args.boolean("reloadAfterShow", true)
        hdcRunOnMainCatching(onError = { error -> loadFailed(id, error) }) {
            FullscreenNativeAdRegistry.setCallback(id, HdcFullscreenEvents(id))
            host.load(id, adUnitIds, reloadAfterShow)
        }
        return true
    }

    fun show(args: HdcArgs): Boolean {
        val id = args.id()
        val options = HdcFullscreenOptions.parse(args)
        val ready = hdcQueryOnMain(fallback = false) {
            FullscreenNativeAdRegistry.isReady(id).also { ready ->
                if (!ready) showFailed(id, "Fullscreen native ad not ready. Load first")
            }
        }
        val notShown = { reason: String -> showFailed(id, "Fullscreen native ad did not show: $reason") }
        return ready && hdcStartShow(notShown) { host.show(id, options) }
    }

    fun hide(args: HdcArgs): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { host.hide(id) }
        return true
    }

    fun isReady(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { FullscreenNativeAdRegistry.isReady(id) }
    }

    fun destroy(args: HdcArgs): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { host.destroy(id) }
        return true
    }

    private fun loadFailed(id: String, error: Throwable) {
        HdcEvents.emit(
            id = id,
            format = HdcFormat.Fullscreen,
            type = HdcEventType.LoadFailed,
            fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
        )
    }

    private fun showFailed(id: String, message: String) {
        HdcEvents.emit(
            id = id,
            format = HdcFormat.Fullscreen,
            type = HdcEventType.ShowFailed,
            fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, message),
        )
    }
}

/** Show options with the same field names as the ads config JSON. */
internal object HdcFullscreenOptions {
    fun parse(args: HdcArgs): FullscreenNativeAdShowOptions {
        val defaults = FullscreenNativeAdShowOptions()
        val layoutNames = args.stringList("layoutNames")
        val click = args.obj("clickAssets")
        val visible = args.obj("assetVisibility")
        return FullscreenNativeAdShowOptions(
            layoutName = layoutNames.firstOrNull() ?: FullscreenLayoutCatalog.SingleDefault,
            durationSeconds = args.double("duration", defaults.durationSeconds),
            autoClose = args.boolean("autoClose", defaults.autoClose),
            pauseGameplay = args.boolean("pauseGameplay", defaults.pauseGameplay),
            mode = FullscreenNativeAdMode.fromName(args.string("mode")),
            layoutNames = layoutNames,
            durationsSeconds = args.doubleList("durations"),
            orientation = args.string("orientation").ifBlank { defaults.orientation },
            enableAdComeback = args.boolean("enableAdComeback", defaults.enableAdComeback),
            showTCD = args.boolean("showTCD", defaults.showTCD),
            delaySeconds = args.double("delay", defaults.delaySeconds),
            timeUpCSeconds = args.int("timeUpC", defaults.timeUpCSeconds),
            clickAssets = NativeClickAssetOptions(
                cta = click.boolean("cta", true),
                headline = click.boolean("headline", true),
                body = click.boolean("body", true),
                description = click.boolean("description", true),
                icon = click.boolean("icon", true),
                advertiser = click.boolean("advertiser", true),
                media = click.boolean("media", true),
                mediaImage = click.boolean("mediaImage", true),
                mediaVideo = click.boolean("mediaVideo", true),
            ),
            assetVisibility = NativeAssetVisibilityOptions(
                cta = visible.boolean("cta", true),
                headline = visible.boolean("headline", true),
                body = visible.boolean("body", true),
                description = visible.boolean("description", true),
                icon = visible.boolean("icon", true),
                advertiser = visible.boolean("advertiser", true),
                media = visible.boolean("media", true),
                mediaImage = visible.boolean("mediaImage", true),
                mediaVideo = visible.boolean("mediaVideo", true),
                price = visible.boolean("price", true),
                store = visible.boolean("store", true),
                starRating = visible.boolean("starRating", true),
            ),
        )
    }
}

/** Forwards one fullscreen instance's registry callbacks to Unity. */
internal class HdcFullscreenEvents(private val id: String) : FullscreenNativeAdCallback {
    override fun onLoaded(ad: FullscreenNativeAdInfo) = emit(HdcEventType.Loaded, mapOf("adUnitId" to ad.adUnitId))

    // Loading moves on to the next ad unit right after a failure: report it only if the ad is still failed
    // one main loop later.
    override fun onFailedToLoad(error: FullscreenNativeAdError) {
        hdcPostToMain {
            if (FullscreenNativeAdRegistry.stateFor(id) == NativeAdState.Failed) {
                emit(HdcEventType.LoadFailed, mapOf("adUnitId" to error.adUnitId) + HdcEvents.error(error.code, error.message))
            }
        }
    }

    override fun onDisplayed(ad: FullscreenNativeAdInfo) =
        emit(HdcEventType.Shown, mapOf("adUnitId" to ad.adUnitId, "layout" to ad.layoutName))

    override fun onClosed(ad: FullscreenNativeAdInfo) = emit(HdcEventType.Closed, mapOf("adUnitId" to ad.adUnitId))

    private fun emit(type: String, fields: Map<String, Any?>) {
        HdcEvents.emit(id = id, format = HdcFormat.Fullscreen, type = type, fields = fields)
    }
}

/**
 * `popup.*` commands for native popups placed over the game.
 *
 * - `load` `{id, adUnitIds:[…], layout?, timeShow?, timeReload?, x?, y?, width?, height?, autoClose?,
 *   enableCtrOverlay?}`. Sizes are dp. A position with both values in 0..1 is a normalized center
 *   (y from the bottom), otherwise the top-left corner.
 * - `updatePlacement` `{id, x, y, width, height}`.
 * - `show` returns whether the popup starts to show; one that cannot start after all reports ShowFailed.
 *   `close`, `hide`, `stop`, `destroy` `{id}`.
 * - `isReady`, `isDisplayable` return booleans; `state` returns the display state name.
 */
internal object HdcPopupCommands {
    private val host: HdcPopupHost by lazy { hdcPopupHost() }
    private val events = mutableMapOf<String, HdcNativeStateEvents>()

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val defaults = PopupNativeAdConfig(ids = adUnitIds)
        val config = defaults.copy(
            layoutName = args.string("layout").ifBlank { PopupNativeAdLayoutCatalog.Default },
            timeShowSeconds = args.int("timeShow", defaults.timeShowSeconds),
            timeReloadSeconds = args.int("timeReload", defaults.timeReloadSeconds),
            xDp = args.float("x", defaults.xDp),
            yDp = args.float("y", defaults.yDp),
            adWidthDp = args.float("width", defaults.adWidthDp),
            adHeightDp = args.float("height", defaults.adHeightDp),
            autoClose = args.boolean("autoClose", defaults.autoClose),
            enableCtrOverlay = args.boolean("enableCtrOverlay", defaults.enableCtrOverlay),
        )
        hdcRunOnMainCatching(onError = { error -> failed(id, HdcEventType.LoadFailed, error) }) {
            val stateEvents = HdcNativeStateEvents(id, HdcFormat.Popup)
            events[id] = stateEvents
            host.load(id, config) { state -> stateEvents.onState(state) }
        }
        return true
    }

    fun updatePlacement(args: HdcArgs): Boolean {
        val id = args.id()
        val x = args.float("x", Float.NaN)
        val y = args.float("y", Float.NaN)
        val width = args.float("width", Float.NaN)
        val height = args.float("height", Float.NaN)
        require(listOf(x, y, width, height).all { it.isFinite() }) { "x, y, width and height are required" }
        hdcRunOnMainCatching(onError = {}) { host.updatePlacement(id, x, y, width, height) }
        return true
    }

    fun show(args: HdcArgs): Boolean {
        val id = args.id()
        val displayable = hdcQueryOnMain(fallback = false) {
            host.isDisplayable(id).also { displayable ->
                if (!displayable) {
                    failed(id, HdcEventType.ShowFailed, IllegalStateException("Popup not displayable: ${host.state(id)}"))
                }
            }
        }
        val notShown = { reason: String ->
            failed(id, HdcEventType.ShowFailed, IllegalStateException("Popup did not show: $reason"))
        }
        return displayable && hdcStartShow(notShown) {
            events[id]?.onShowRequested()
            host.show(id)
            true
        }
    }

    fun close(args: HdcArgs): Boolean = run(args) { host.close(it) }

    fun hide(args: HdcArgs): Boolean = run(args) { host.hide(it) }

    fun stop(args: HdcArgs): Boolean = run(args) { host.stop(it) }

    fun destroy(args: HdcArgs): Boolean =
        run(args) { id ->
            host.destroy(id)
            events.remove(id)
        }

    fun isReady(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { host.isReady(id) }
    }

    fun isDisplayable(args: HdcArgs): Boolean {
        val id = args.id()
        return hdcQueryOnMain(fallback = false) { host.isDisplayable(id) }
    }

    fun state(args: HdcArgs): String {
        val id = args.id()
        return hdcQueryOnMain(fallback = "NotLoaded") { host.state(id) }
    }

    private fun run(args: HdcArgs, block: (String) -> Unit): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { block(id) }
        return true
    }

    private fun failed(id: String, type: String, error: Throwable) {
        HdcEvents.emit(
            id = id,
            format = HdcFormat.Popup,
            type = type,
            fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
        )
    }
}

/**
 * `banner.*` commands for the native banner at the bottom of the screen.
 *
 * - `load` `{id, adUnitIds:[…], layoutNames?, timeReload?, timeCountdown?, timeCollapse?}`.
 * - `show`, `hide`, `collapse`, `destroy` `{id}`; `expand` `{id, enableClick?}` returns whether it expanded.
 */
internal object HdcBannerCommands {
    private val host: HdcBannerHost by lazy { hdcBannerHost() }

    fun load(args: HdcArgs): Boolean {
        val id = args.id()
        val adUnitIds = args.stringList("adUnitIds")
        require(adUnitIds.isNotEmpty()) { "adUnitIds is empty" }
        val defaults = BannerNativeAdConfig(ids = adUnitIds)
        val config = defaults.copy(
            layoutNames = args.stringList("layoutNames").ifEmpty { BannerNativeAdLayoutCatalog.All },
            timeReloadSeconds = args.int("timeReload", defaults.timeReloadSeconds),
            timeCountdownSeconds = args.int("timeCountdown", defaults.timeCountdownSeconds),
            timeCollapseSeconds = args.int("timeCollapse", defaults.timeCollapseSeconds),
        )
        hdcRunOnMainCatching(
            onError = { error ->
                HdcEvents.emit(
                    id = id,
                    format = HdcFormat.Banner,
                    type = HdcEventType.LoadFailed,
                    fields = HdcEvents.error(NativeAdLoadResult.NoErrorCode, error.message.orEmpty()),
                )
            },
        ) {
            val stateEvents = HdcNativeStateEvents(id, HdcFormat.Banner)
            host.load(id, config) { state -> stateEvents.onState(state) }
        }
        return true
    }

    fun show(args: HdcArgs): Boolean = run(args) { host.show(it) }

    fun hide(args: HdcArgs): Boolean = run(args) { host.hide(it) }

    fun collapse(args: HdcArgs): Boolean = run(args) { host.collapse(it) }

    fun destroy(args: HdcArgs): Boolean = run(args) { host.destroy(it) }

    fun expand(args: HdcArgs): Boolean {
        val id = args.id()
        val enableClick = args.boolean("enableClick", true)
        return hdcQueryOnMain(fallback = false) { host.expand(id, enableClick) }
    }

    private fun run(args: HdcArgs, block: (String) -> Unit): Boolean {
        val id = args.id()
        hdcRunOnMainCatching(onError = {}) { block(id) }
        return true
    }
}

/**
 * `meta.*` commands for Meta Audience Network test ads. Call `enableTestMode` before ads load: ads loaded
 * earlier are not test ads. Meta keeps test devices across launches until `disableTestMode`.
 *
 * - `enableTestMode` `{deviceHashes?:[…], testAdType?}` returns whether it is on; `disableTestMode` `{}`.
 * - `isTestMode` returns a boolean; `deviceHash` returns this device's hash.
 */
internal object HdcMetaCommands {
    private val host: HdcMetaTestHost by lazy { hdcMetaTestHost() }

    fun enableTestMode(args: HdcArgs): Boolean {
        val deviceHashes = args.stringList("deviceHashes")
        val testAdType = args.int("testAdType", 0)
        return hdcQueryOnMain(fallback = false) { host.enable(deviceHashes, testAdType) }
    }

    fun disableTestMode(): Boolean {
        hdcRunOnMainCatching(onError = {}) { host.disable() }
        return true
    }

    fun isTestMode(): Boolean = hdcQueryOnMain(fallback = false) { host.isEnabled() }

    fun deviceHash(): String = hdcQueryOnMain(fallback = "") { host.deviceHash() }
}
